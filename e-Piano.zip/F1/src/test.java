
import java.sql.*;
import java.util.Vector;
import javax.swing.JOptionPane;

public class test {
    // 得到数据库表数据
    public static void change(String s, String sql){
        String sql_url = "jdbc:mysql://localhost:3306/e_piano_2";	//数据库路径（一般都是这样写），test是数据库名称
        String name = "root";		//用户名
        String password = "Extraord10";	//密码
        Connection conn;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");		//连接驱动
            conn = DriverManager.getConnection(sql_url, name, password);	//连接数据库
//			if(!conn.isClosed())
//				System.out.println("成功连接数据库");
            Statement preparedStatement = conn.prepareStatement(s);
            // preparedStatement.addBatch(sql);
            //preparedStatement.executeBatch();
            preparedStatement.execute(" SET FOREIGN_KEY_CHECKS = 0; ");
            preparedStatement.execute(sql);
            preparedStatement.execute(" SET FOREIGN_KEY_CHECKS = 1; ");
            conn.close();
            preparedStatement.close();

        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("未成功加载驱动。");
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("未成功打开数据库。");
            e.printStackTrace();
        }

    }
    public static Vector getRows(String s,String s1){
        String sql_url = "jdbc:mysql://localhost:3306/e_piano_2";	//数据库路径（一般都是这样写），test是数据库名称
        String name = "root";		//用户名
        String password = "Extraord10";	//密码
        Connection conn;
        PreparedStatement preparedStatement = null;

        Vector rows = null;
        Vector columnHeads = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");		//连接驱动
            conn = DriverManager.getConnection(sql_url, name, password);	//连接数据库
//			if(!conn.isClosed())
//				System.out.println("成功连接数据库");
            preparedStatement = conn.prepareStatement(s);
            ResultSet result1 = preparedStatement.executeQuery(s1);

            rows = new Vector();
            ResultSetMetaData rsmd = result1.getMetaData();

            while (result1.next()) {
                rows.addElement(getNextRow(result1, rsmd));
            }

            conn.close();
            preparedStatement.close();

        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("未成功加载驱动。");
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("未成功打开数据库。0000000000000");
            e.printStackTrace();
        }

        return rows;
    }
    public static int judgeif(String s,String s1){
        String sql_url = "jdbc:mysql://localhost:3306/e_piano_2";	//数据库路径（一般都是这样写），test是数据库名称
        String name = "root";		//用户名
        String password = "Extraord10";	//密码
        Connection conn;
        PreparedStatement preparedStatement = null;

        int resu=0;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");		//连接驱动
            conn = DriverManager.getConnection(sql_url, name, password);	//连接数据库
            preparedStatement = conn.prepareStatement(s);
            ResultSet result1 = preparedStatement.executeQuery(s1);


            ResultSetMetaData rsmd = result1.getMetaData();

            if (result1.next()) {
                resu=1;
            }
            conn.close();
            preparedStatement.close();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("未成功加载驱动。");
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("未成功打开数据库。");
            e.printStackTrace();
        }
        return resu;
    }

    // 得到数据库表头
    public static Vector getHead(String head, String s){
        String sql_url = "jdbc:mysql://localhost:3306/e_piano_2";	//数据库路径（一般都是这样写），test是数据库名称
        String name = "root";		//用户名
        String password = "Extraord10";	//密码
        Connection conn;
        PreparedStatement preparedStatement = null;

        Vector columnHeads = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");		//连接驱动
            conn = DriverManager.getConnection(sql_url, name, password);	//连接数据库
//			if(!conn.isClosed())
//				System.out.println("成功连接数据库");
            preparedStatement = conn.prepareStatement(s);
            ResultSet result1 = preparedStatement.executeQuery(head);

            boolean moreRecords = result1.next();
            if(!moreRecords)
                JOptionPane.showMessageDialog(null, "结果集中无记录");

            columnHeads = new Vector();
            ResultSetMetaData rsmd = result1.getMetaData();
            for(int i = 1; i <= rsmd.getColumnCount(); i++)
                columnHeads.addElement(rsmd.getColumnName(i));
            conn.close();
            preparedStatement.close();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("未成功加载驱动。");
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("未成功打开数据库!!!!!");
            e.printStackTrace();
        }

        return columnHeads;
    }

    // 得到数据库中下一行数据
    private static Vector getNextRow(ResultSet rs,ResultSetMetaData rsmd) throws SQLException{
        Vector currentRow = new Vector();
        for(int i = 1; i <= rsmd.getColumnCount(); i++){
            currentRow.addElement(rs.getString(i));
        }
        return currentRow;
    }

	/*//主函数
	 public static void main(String[] args){
		 getRows();
	}*/
}
