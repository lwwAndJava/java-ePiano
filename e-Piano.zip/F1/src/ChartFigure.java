import java.awt.Font;
import java.sql.*;


import org.jfree.chart.*;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;

public class ChartFigure extends ApplicationFrame {
    public ChartFigure(String title, String sql) {
        super(title);
        createChart(sql);

    }


    public static void createChart(String sql) //用数据集创建一个图表
    {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/e_piano_2",
                    "root",
                    "Extraord10");
            System.out.println("Connected successfully");


            PreparedStatement state = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = state.executeQuery();


            //执行更新操作
            int count = 0;
            while (rs.next()) {   //存到数组中
                count++;
            }
            int row= count;

            String comm[][] = new String[count][3];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("YEAR(dateAndTime)");
                comm[count][1] = rs.getString("MONTH(dateAndTime)");
                comm[count][2] = rs.getString("COUNT(oNo)");
                count++;
            }
            conn.close();

            int[][] co = new int[row][3];   //全部转化成整数
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < 3; j++) {
                    co[i][j] = Integer.parseInt(comm[i][j]);
                }
            }

            for (int m = 0; m < row; m++) {
                dataset.setValue(co[m][2], "order number", comm[m][0] + "." + comm[m][1]);
            }

        } catch (ClassNotFoundException ome1) {
            ome1.printStackTrace();
        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        JFreeChart chart = ChartFactory.createBarChart(
                "order chart of order number",
                "month",
                "order number",
                dataset, PlotOrientation.VERTICAL,
                true,
                true,
                false); //创建一个JFreeChart
        chart.setTitle(new TextTitle(
                "Statics of order quantity each month ",
                new Font("宋体", Font.BOLD + Font.ITALIC, 20)));//可以重新设置标题，替换“hi”标题
        CategoryPlot plot = (CategoryPlot) chart.getPlot();//获得图标中间部分，即plot
        CategoryAxis categoryAxis = plot.getDomainAxis();//获得横坐标
        categoryAxis.setLabelFont(new Font("微软雅黑", Font.BOLD, 12));//设置横坐标字体
        CategoryPlot plot1 = chart.getCategoryPlot();//设置图的高级属性

        BarRenderer barRenderer = (BarRenderer) plot.getRenderer();
        barRenderer.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
        barRenderer.setBaseItemLabelsVisible(true);
        plot.setRenderer(barRenderer);
        ChartFrame frame=new ChartFrame("Statics of order quantity each month",chart);
        frame.setVisible(true);
        frame.pack();

    }

}