import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
public class Orders extends JFrame {
    DefaultTableModel tableModel;   //jp1   订单管理选项卡上的 tableModel
    JTable jTable;      //   jp1  订单管理上的表格
    public Orders() {
        JFrame frame = new JFrame("Text");
        try{    //将数据库信息放到JTable中
            Class.forName("com.mysql.cj.jdbc.Driver");
            // 建立数据库连接
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/e_piano_2",
                    "root",
                    "Extraord10");
            System.out.println("Connected successfully");

            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet res = stmt.executeQuery("SELECT* FROM orders");
            System.out.println("Query successfully!");

            int count=0;
            while(res.next()){
                count++;
            }

            String comm[][] = new String[count][7];
            count = 0;
            res.beforeFirst();
            while(res.next()){
                comm[count][0]=res.getString("oNo");
                comm[count][1]=res.getString("dateAndTime");
                comm[count][2]=res.getString("Amount");
                comm[count][3]=res.getString("state");
                comm[count][4]=res.getString("Manager_mNo");
                comm[count][5]=res.getString("Customer_cNo");
                comm[count][6]=res.getString("Store_storeNo");
                count++;
            }
            conn.close();

            String[] title = {"oNo", "dataAndTime", "Amount", "state","Manager_mNo","Customer_cNo","Store_storeNo"};
            //使表格不可编辑
            tableModel = new DefaultTableModel(comm,title){
                public boolean isCellEditable(int row, int column){
                    return false;
                }
            };

            jTable= new JTable(tableModel);
            jTable.setPreferredScrollableViewportSize(new Dimension(800,200));
            JScrollPane jScrollPane = new JScrollPane(jTable,
                    ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
            frame.add(jScrollPane);
            //add JTabbedPane on JFrame
            frame.setSize(840,340);
            frame.setLocation(300,200);
            frame.setVisible(true);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        }catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }
}

