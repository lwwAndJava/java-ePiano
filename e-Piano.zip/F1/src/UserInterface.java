
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.event.*;

public class UserInterface extends JFrame implements ActionListener {
    //登陆界面上的组件
    JTextField filed1,filed2;
    JRadioButton button1,button2;
    ButtonGroup btnGroup;
    String merchant;
    JLabel jlbTop,jlbImg,jlbReg,jlbPsw;
    JPanel jp; //用于界面底部区域
    JTextField jtf;
    JPasswordField jpf;
    JCheckBox box1,box2;
    JButton jbLogin;//登陆按钮
    JFrame login;

    //订单管理上的组件
    JRadioButton odel,omod,osea,osho,figure;
    ButtonGroup oservice;
    JButton osButton; //选择服务的确认按钮

    DefaultTableModel tableModel;   // 订单管理选项卡上的 tableModel
    JTable jTable;      //    订单管理上的表格

    JTextField opnText3,opqText3,oprText3,opcText3,ocnText3,onoText3,otiText3,oteText3,oadText3;   //订单管理  修改版面上的
    JComboBox<String> oStateCmb3,ofunCmb3,opartCmb3,otypCmb3;  //订单状态，产品功能，产品零件
    String omValue;   //要修改的订单编号

    JTextField opnText,opqText,oplText,ophText,opcText,ocnText,onoText,oteText,oadText;   //订单管理  搜索版面上的
    //产品名字，产品数量，最低价，最高价，颜色，顾客昵称，订单编号，开始时间，结束时间，顾客电话，顾客地址
    JComboBox<String> sTaY, sTaM, sTaD,eTaY,eTaM, eTaD;
    JComboBox<String> oStateCmb2,ofunCmb,opartCmb,otypCmb;  //订单状态，产品功能，产品零件



    JButton osy,oscan,omy,omcan;    //订单 搜索确认、搜索取消； 修改确认、修改取消；
    JFrame os,om;   //搜索、修改、添加的GUI



    //jp2  产品管理上的组件
    JRadioButton pdel,padd,pmod,psea,psho;   // 删除、添加、修改、搜索、show all
    ButtonGroup pservice;
    JButton itemButton;  //Process button

    DefaultTableModel  tableModel1;  //商品管理上的 tableModel
    JTable pmTable;

    JTextField pnoText1,pnaText1,priText1,pcoText1,pstText1,psoText1,phoText1,pbrText1,psiText1;   //   商品管理 修改版面上的组件
    JComboBox<String> typCmb1,funCmb1, parCmb1;

    JTextField pnoText,pnaText,prlText,prhText,pcoText,pstText,psoText,phoText,pbrText,psiText;   //   商品管理  搜索版面上的组件
    JComboBox<String> typCmb,funCmb, parCmb;



    JButton psyes,pscan,pmyes,pmcan,payes,pacan;    //产品  搜索确认、搜索取消; 修改确认，修改取消；添加确认、添加取消
    JFrame ps,pm,pa;   //搜索、修改、添加的GUI
    String pmValue;



    //jp3上的组件
    JTextField storeNo4;
    JButton ensure;
    JComboBox<String> operation,bigType,funCmb4,parCmb4;
    JComboBox<String> sTaY2, sTaM2, sTaD2, eTaY2,eTaM2, eTaD2;  //开始、结束的年月日


    JPanel oStatics;
    JTable sTable;
    JScrollPane stampt;

    //type,color,function,parts的值
    String[] typValue,funValue,parValue ; //无All
    String[] typValue2,funValue2,parValue2 ;  //有All



    public UserInterface() {
        //login=new JFrame();
        JPanel imPanel = (JPanel) getContentPane();
        imPanel.setOpaque(false);
        imPanel.setLayout(new GridLayout(4, 1));
        imPanel.setSize(500, 300);


        JPanel panel1 = new JPanel(null);
        JPanel panel2 = new JPanel(null);
        JPanel panel3 = new JPanel();
        JPanel panel4 = new JPanel(null);

        // ImageIcon icon = new ImageIcon(("src/image/2.jpg"));//背景图
        ImageIcon icon = new ImageIcon(this.getClass().getResource("/image/2.jpg"));//背景图
        JLabel label = new JLabel(icon);//往一个标签中加入图片
        label.setBounds(0, 0, imPanel.getWidth(), imPanel.getHeight());//设置标签位置大小为图片大小
        this.getLayeredPane().add(label, Integer.valueOf(Integer.MIN_VALUE));//标签添加到第二层面板


        JButton logInButton = new JButton("OK");
        logInButton.setSize(60, 30);
        logInButton.setLocation(210, 0);
        logInButton.addActionListener(this);
        panel4.add(logInButton);

        JLabel label1 = new JLabel("User No:");
        label1.setSize(80, 30);
        label1.setLocation(100, 30);
        panel1.add(label1);

        filed1 = new JTextField();
        filed1.setSize(200, 25);
        filed1.setLocation(170, 35);

        panel1.add(filed1);

        JLabel label2 = new JLabel("Password:");
        label2.setSize(80, 30);
        label2.setLocation(100, 30);
        panel2.add(label2);

        filed2 = new JPasswordField();
        filed2.setSize(200, 25);
        filed2.setLocation(170, 35);
        panel2.add(filed2);

        button1 = new JRadioButton("Manager");
        button1.setForeground(Color.WHITE);
        button2 = new JRadioButton("Merchant");
        button2.setForeground(Color.WHITE);
        btnGroup = new ButtonGroup();
        btnGroup.add(button1);
        btnGroup.add(button2);
        panel3.add(button1);
        panel3.add(button2);

        //将组件面板加至顶层容器
        imPanel.add(panel1);
        imPanel.add(panel2);
        imPanel.add(panel3);
        imPanel.add(panel4);

        //设置其它面板为透明
        panel1.setOpaque(false);
        panel2.setOpaque(false);
        panel3.setOpaque(false);
        panel4.setOpaque(false);
        button1.setOpaque(false);
        button2.setOpaque(false);



        //设置窗口为图片大小且不可调整
        setSize(imPanel.getWidth(), imPanel.getHeight());
        setResizable(false);
        //设置窗口可见
        setTitle("Login");
        setVisible(true);
        setLocation(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            System.out.println("class not found");
        } catch (InstantiationException ex) {
            System.out.println("Instantiation exception");
        } catch (IllegalAccessException ex) {
            System.out.println("IllegalAccess Exceptio");
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            System.out.println("UnsupportedLookAndFeel Exception");
        }
    }


    /**
     * 连接数据库
     * @return
     */
    public Connection connect(){
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException classNotFoundException) {
            System.out.println("Failed to load driver package.");
        }
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/e_piano_2", "root", "Extraord10");
            return conn;
        } catch (SQLException throwables) {
            System.out.println("Failed to connect to database.");
        }
        return conn;
    }
    /**
     * 判断是否含有字母
     * @param str  待检验的字符串
     * @return   返回是否包含
     * true  包含字母
     */
    public boolean judgeContainsStr(String str) {
        String regex=".*[a-zA-Z]+.*";
        Matcher m= Pattern.compile(regex).matcher(str);
        return m.matches();
    }
    /**
     * 判断订单中是否包含这个编号
     * @param str  从对话框中获取的编号字符串
     * @return    是否存在
     * true:exist
     */
    public boolean checkExist(String str){
        boolean flag = false;
        try{
            int oInt = Integer.parseInt(str);
            Connection check = connect();
            String csql = "SELECT * FROM Orders WHERE oNo = ?";
            PreparedStatement cstate = check.prepareStatement(csql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            cstate.setInt(1,oInt);
            ResultSet crs = cstate.executeQuery();
            if ( ! crs.isBeforeFirst()){
                flag= false;
            }else{
                flag =  true;
            }
        }catch (SQLException c1) {
            c1.printStackTrace();
        }
        return flag;
    }

    /**
     * 判断商品中是否包含这个编号
     * @param str  从对话框中获取的编号字符串
     * @return   返回是否存在
     * true 存在
     */
    public boolean checkPExist(String str){
        boolean flag = false;
        try{
            int pInt = Integer.parseInt(str);
            Connection check = connect();
            String csql = "SELECT * FROM Product WHERE pianoNo = ?";
            PreparedStatement cstate = check.prepareStatement(csql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            cstate.setInt(1,pInt);
            ResultSet crs = cstate.executeQuery();
            if ( ! crs.isBeforeFirst()){
                flag= false;
            }else{
                flag =  true;
            }
        }catch (SQLException c1) {
            c1.printStackTrace();
        }
        return flag;
    }

    public void actionPerformed(ActionEvent e) {

        PreparedStatement state;
        ResultSet re;
        String sql;
        String user = filed1.getText();
        String password = filed2.getText();

        Connection conn = connect();
        if(button1.isSelected()) {
            sql = "SELECT * FROM Manager WHERE mPassword = ? AND mNo = ?";
            try {
                state = conn.prepareStatement(sql);
                state.setString(1, password);
                state.setString(2, user);
                re = state.executeQuery();
                if (re.next()) {
                    System.out.println("Login Successfully" + re.getString(3) + "，Welcome");
                    new Manager();
                    this.setVisible(false);
                } else {
                    JFrame errorFrame = new JFrame();
                    errorFrame.setLayout(null);
                    errorFrame.setSize(450, 150);
                    errorFrame.setLocation(650, 400);

                    JLabel label3 = new JLabel("The user No or password is incorrect");
                    label3.setSize(350, 30);
                    label3.setLocation(50, 20);
                    errorFrame.add(label3);

                    JButton button = new JButton("OK");
                    button.setSize(60, 30);
                    button.setLocation(190, 60);

                    button.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            errorFrame.dispose();
                        }
                    });
                    errorFrame.add(button);
                    errorFrame.setVisible(true);
                }
                conn.close();
            } catch (SQLException throwables) {
                System.out.println("Closing connection failed.");
            }
        }
        else if(button2.isSelected()){
            sql = "SELECT * FROM Store WHERE sPassword = ? AND storeNo= ?";
            try {
                state = conn.prepareStatement(sql);
                state.setString(1, password);
                state.setString(2, user);
                re = state.executeQuery();
                if (re.next()) {
                    System.out.println("Login Successfully" + re.getString(3) + "，Welcome");
                    merchant=filed1.getText();
                    Business(merchant);
                    this.setVisible(false);
                } else {
                    JFrame errorFrame = new JFrame();
                    errorFrame.setLayout(null);
                    errorFrame.setSize(450, 150);
                    errorFrame.setLocation(650, 400);

                    JLabel label3 = new JLabel("The user No or password is incorrect");
                    label3.setSize(350, 30);
                    label3.setLocation(50, 20);
                    errorFrame.add(label3);

                    JButton button = new JButton("OK");
                    button.setSize(60, 30);
                    button.setLocation(190, 60);

                    button.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            errorFrame.dispose();
                        }
                    });
                    errorFrame.add(button);
                    errorFrame.setVisible(true);
                }
                conn.close();
            } catch (SQLException throwables) {
                System.out.println("Closing connection failed.");
            }
        }

    }

    public static void main(String[] args){

        UserInterface UI = new UserInterface();
    }


    public void Business(String merchant){   //3 个选项卡
        Category c = new Category(1);
        typValue=c.getTypENUM(1);
        funValue=c.getFunENUM(1);
        parValue=c.getParENUM(1);
        typValue2 = c.getTypENUM(2);
        funValue2=c.getFunENUM(2);
        parValue2=c.getParENUM(2);

        JFrame f = new JFrame("Business");
        String sNo= merchant;
        JTabbedPane jtp = new JTabbedPane();
        JPanel jp1 = jp1GUI();
        JPanel jp2 = jp2GUI();

        jtp.add("Order Manage",jp1);
        jtp.add("Product Manage",jp2);  //Create 1 JTabbedPane with 3 pages


        f.add(jtp);                              //add JTabbedPane on JFrame
        f.setSize(840,340);
        f.setLocation(300,200);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


    }      //3个选项卡的GUI



    public JPanel jp1GUI(){
        //order management on jp1  (order management)
        JPanel jp1= new JPanel();
        JPanel osPanel = new JPanel();         //service column + button
        JPanel orderLeft = new JPanel();        //space + service column + button (leftside)


        JLabel olb = new JLabel("Please select the operation");
        odel = new JRadioButton("Delete order");
        omod = new JRadioButton("Modify order");
        osea = new JRadioButton("Search order");
        figure = new JRadioButton("Show order statistics");
        osho = new JRadioButton("Show all orders");
        oservice = new ButtonGroup();
        oservice.add(odel);
        oservice.add(omod);
        oservice.add(osea);
        oservice.add(figure);
        oservice.add(osho);



        JPanel osButtonPanel = new JPanel();      //order service button
        osButton = new JButton("Process");
        osButton.addActionListener(new jp1ButtonListener());   //add buttonlistener
        osButtonPanel.add(osButton);


        osPanel.setLayout(new GridLayout(7,1));
        osPanel.add(olb);
        osPanel.add(odel);
        osPanel.add(omod);
        osPanel.add(osea);
        osPanel.add(figure);
        osPanel.add(osho);
        osPanel.add(osButtonPanel);

        orderLeft.setLayout(new BorderLayout());
        orderLeft.add(osPanel,BorderLayout.CENTER);



        /**
         * 订单管理  订单展示表
         */
        try{    //将数据库信息放到JTable中

            Connection conn = connect();

            int om = Integer.parseInt(merchant);
            String ooosql = "SELECT p.pname, ohp.Num, p.price*ohp.Num AS tprice, p.ptype,ohp.color,p.pfunction,p.parts,c.cName, o.state, ohp.Orders_oNo, o.dateAndTime,o.oTeleNo,o.oAddress" +
                    " FROM orders o, Orders_has_Product ohp,Product p,Customer c " +
                    " WHERE p.pianoNo = ohp.Product_pianoNo AND c.cNo =o.Customer_cNo AND ohp.Orders_oNo = o.oNo AND p.Store_storeNo = ?";
            ooosql = ooosql +" ORDER BY o.oNo";
            PreparedStatement stmt = conn.prepareStatement(ooosql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            stmt.setInt(1,om);
            ResultSet res = stmt.executeQuery();



            jTable= new JTable(jp1setTable(res,conn,jTable));
            jTable.setPreferredScrollableViewportSize(new Dimension(800,200));
            JScrollPane jScrollPane = new JScrollPane(jTable,
                    ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

            jp1.setLayout(new BorderLayout(20,15));    //add component on jp1
            jp1.add(orderLeft,BorderLayout.WEST);
            jp1.add(jScrollPane,BorderLayout.CENTER);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jp1;
    }
    public DefaultTableModel jp1setTable(ResultSet rs, Connection conn, JTable table){
        try{
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][13];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("pname");
                comm[count][1] = rs.getString("Num");
                comm[count][2] = rs.getString("tprice");
                comm[count][3] = rs.getString("p.ptype");
                comm[count][4] = rs.getString("ohp.color");
                comm[count][5] = rs.getString("p.pfunction");
                comm[count][6] = rs.getString("p.parts");
                comm[count][7] = rs.getString("c.cName");
                comm[count][8] = rs.getString("o.state");
                comm[count][9] = rs.getString("Orders_oNo");
                comm[count][10] = rs.getString("dateAndTime");
                comm[count][11] = rs.getString("o.oTeleNo");
                comm[count][12] = rs.getString("o.oAddress");
                count++;
            }
            conn.close();

            String[] title = {"Product name", "Quantity", "Total price","Type","Color","Function","Parts","Customer name","State","Order No","Date","Phone number","Address"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            return tableModel;

        }catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;
    }


    public JPanel oModifyGUI(){


        JPanel oINFO = new JPanel();

        JLabel opn = new JLabel("Product name");
        JLabel opq = new JLabel("Quantity");
        JLabel opr= new JLabel("Price");
        JLabel opt= new JLabel("Type");
        JLabel opc = new JLabel("Color");
        JLabel opf = new JLabel("Function");
        JLabel opp = new JLabel("Part");
        JLabel ocn = new JLabel("Customer Name");
        JLabel ostate= new JLabel("State");
        JLabel ono = new JLabel("Order No");
        JLabel oti= new JLabel("Transaction Time");
        JLabel ote = new JLabel("Phone number");
        JLabel oad = new JLabel("Address");



        opnText3= new JTextField();  //产品名字
        opqText3= new JTextField();  //产品数量
        oprText3= new JTextField();  //最低
        opcText3= new JTextField();  //产品颜色
        ocnText3= new JTextField();  //顾客昵称
        onoText3= new JTextField();  //订单编号
        otiText3= new JTextField();  //开始时间
        String[] stateValue = {"ordered","delivered","completed","canceled"};   //commodity service column
        oStateCmb3 = new JComboBox<String>(stateValue);   //订单状态
        otypCmb3 = new JComboBox<String>(typValue);       //产品类型
        ofunCmb3 = new JComboBox<String>(funValue);       //产品功能
        opartCmb3 = new JComboBox<String>(parValue);     //产品零件
        oteText3 = new JTextField();  //电话号码
        oadText3 = new JTextField(); //地址


        opnText3.setMaximumSize(new Dimension(500,opnText3.getMinimumSize().height));
        opqText3.setMaximumSize(new Dimension(500,opqText3.getMinimumSize().height));
        oprText3.setMaximumSize(new Dimension(500,oprText3.getMinimumSize().height));
        opcText3.setMaximumSize(new Dimension(500,opcText3.getMinimumSize().height));
        ocnText3.setMaximumSize(new Dimension(500,ocnText3.getMinimumSize().height));
        onoText3.setMaximumSize(new Dimension(500,onoText3.getMinimumSize().height));
        otiText3.setMaximumSize(new Dimension(500,otiText3.getMinimumSize().height));
        oStateCmb3.setMaximumSize(new Dimension(Integer.MAX_VALUE,oStateCmb3.getMinimumSize().height));//unit size
        otypCmb3.setMaximumSize(new Dimension(Integer.MAX_VALUE,otypCmb3.getMinimumSize().height));
        ofunCmb3.setMaximumSize(new Dimension(Integer.MAX_VALUE,ofunCmb3.getMinimumSize().height));
        opartCmb3.setMaximumSize(new Dimension(Integer.MAX_VALUE,opartCmb3.getMinimumSize().height));//unit size
        oteText3.setMaximumSize(new Dimension(500,oteText3.getMinimumSize().height));
        oadText3.setMaximumSize(new Dimension(500,oadText3.getMinimumSize().height));




        JPanel  opnPanel= new JPanel();    //添加复选框和文本框
        JPanel  opqPanel= new JPanel();
        JPanel  oprPanel= new JPanel();
        JPanel  optPanel= new JPanel();
        JPanel  opcPanel= new JPanel();
        JPanel  opfPanel= new JPanel();
        JPanel  oppPanel= new JPanel();
        JPanel  ocnPanel= new JPanel();
        JPanel  onoPanel= new JPanel();
        JPanel  otiPanel= new JPanel();
        JPanel  ostatePanel= new JPanel();
        JPanel  otePanel= new JPanel();
        JPanel  oadPanel= new JPanel();




        opnPanel.setLayout(new BoxLayout(opnPanel, BoxLayout.X_AXIS));
        opqPanel.setLayout(new BoxLayout(opqPanel, BoxLayout.X_AXIS));
        oprPanel.setLayout(new BoxLayout(oprPanel, BoxLayout.X_AXIS));
        optPanel.setLayout(new BoxLayout(optPanel, BoxLayout.X_AXIS));
        opcPanel.setLayout(new BoxLayout(opcPanel, BoxLayout.X_AXIS));
        opfPanel.setLayout(new BoxLayout(opfPanel, BoxLayout.X_AXIS));
        oppPanel.setLayout(new BoxLayout(oppPanel, BoxLayout.X_AXIS));
        ocnPanel.setLayout(new BoxLayout(ocnPanel, BoxLayout.X_AXIS));
        onoPanel.setLayout(new BoxLayout(onoPanel, BoxLayout.X_AXIS));
        otiPanel.setLayout(new BoxLayout(otiPanel, BoxLayout.X_AXIS));
        ostatePanel.setLayout(new BoxLayout(ostatePanel, BoxLayout.X_AXIS));
        otePanel.setLayout(new BoxLayout(otePanel, BoxLayout.X_AXIS));
        oadPanel.setLayout(new BoxLayout(oadPanel, BoxLayout.X_AXIS));



        opnPanel.add(opn);
        opqPanel.add(opq);
        oprPanel.add(opr);
        optPanel.add(opt);
        opcPanel.add(opc);
        opfPanel.add(opf);
        oppPanel.add(opp);
        ocnPanel.add(ocn);
        ostatePanel.add(ostate);
        onoPanel.add(ono);
        otiPanel.add( oti);
        otePanel.add(ote);
        oadPanel.add(oad);
        opnPanel.add(Box.createHorizontalStrut(5));
        opqPanel.add(Box.createHorizontalStrut(5));
        oprPanel.add(Box.createHorizontalStrut(5));
        optPanel.add(Box.createHorizontalStrut(5));
        opcPanel.add(Box.createHorizontalStrut(5));
        opfPanel.add(Box.createHorizontalStrut(5));
        oppPanel.add(Box.createHorizontalStrut(5));
        ocnPanel.add(Box.createHorizontalStrut(5));
        ostatePanel.add(Box.createHorizontalStrut(5));
        onoPanel.add(Box.createHorizontalStrut(5));
        otiPanel.add(Box.createHorizontalStrut(5));
        otePanel.add(Box.createHorizontalStrut(5));
        oadPanel.add(Box.createHorizontalStrut(5));
        opnPanel.add(opnText3);
        opqPanel.add(opqText3);
        oprPanel.add(oprText3);
        opcPanel.add(opcText3);
        optPanel.add(otypCmb3);
        opfPanel.add(ofunCmb3);
        oppPanel.add(opartCmb3);
        ocnPanel.add(ocnText3);
        ostatePanel.add(oStateCmb3);
        onoPanel.add(onoText3);
        otiPanel.add(otiText3);
        otePanel.add(oteText3);
        oadPanel.add(oadText3);



        oINFO.setLayout(new GridLayout(7,2));
        oINFO.add(opnPanel);
        oINFO.add(opqPanel);
        oINFO.add(oprPanel);
        oINFO.add(opcPanel);
        oINFO.add(optPanel);
        oINFO.add(opfPanel);
        oINFO.add(oppPanel);
        oINFO.add(ocnPanel);
        oINFO.add(ostatePanel);
        oINFO.add(onoPanel);
        oINFO.add(otiPanel);
        oINFO.add(otePanel);
        oINFO.add(oadPanel);

        return oINFO;

    }
    public void oModify(String oNo){
        int orderInt = Integer.parseInt(oNo);

        int index2 = ofunCmb3.getSelectedIndex();
        int index3 = opartCmb3.getSelectedIndex();
        int index1 = oStateCmb3.getSelectedIndex();
        int index4 = otypCmb3.getSelectedIndex();
        String ofuStr = ofunCmb3.getItemAt(index2);   //获得功能
        String opaStr = opartCmb3.getItemAt(index3);   //获得零件
        String stateStr = oStateCmb3.getItemAt(index1);   //获得状态
        String typStr = otypCmb3.getItemAt(index4);

        String opnStr = opnText3.getText();
        String opqStr = opqText3.getText();
        String oprStr = oprText3.getText();
        String opcStr = opcText3.getText();
        String ocnStr = ocnText3.getText();
        String oteStr = oteText3.getText();
        String oadStr = oadText3.getText();
        String onoStr = onoText3.getText();
        String otiStr = otiText3.getText();


        int opqInt=0,onoInt=0;
        double oprDou=0;
        if (opqStr != null && opqStr.trim().length() != 0){   //既不是空指针也不为0
            opqInt= Integer.parseInt(opqStr);  //数量
        }
        if (oprStr != null && oprStr.trim().length() != 0 ) {
            oprDou = Double.parseDouble(oprStr);  //最低价
        }
        if(onoStr != null && onoStr.trim().length() != 0){
            onoInt = Integer.parseInt(onoStr.trim()); //订单编号
        }




        try{
            Connection conn = connect();
            String sq1 = "UPDATE Product SET ptype = ?, pfunction=?, parts=? WHERE pname = ?";
            PreparedStatement state1 = conn.prepareStatement(sq1,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
            state1.setString(1,typStr);
            state1.setString(2,ofuStr);
            state1.setString(3,opaStr);
            state1.setString(4,opnStr);
            state1.executeUpdate();   //执行更新操作

            String sq2 = "UPDATE orders SET oTeleNo =?, oAddress=?,state=? WHERE oNo=? ";
            PreparedStatement state2 = conn.prepareStatement(sq2,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
            state2.setString(1,oteStr);
            state2.setString(2,oadStr);
            state2.setString(3,stateStr);
            state2.setInt(4,orderInt);
            state2.executeUpdate();   //执行更新操作

            String sq3 = "UPDATE Orders_has_Product SET Num=?, color=? WHERE Orders_oNo = ?";
            PreparedStatement state3 = conn.prepareStatement(sq3,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
            state3.setInt(1,opqInt);
            state3.setString(2,opcStr);
            state3.setInt(3,orderInt);
            state3.executeUpdate();   //执行更新操作


            int om = Integer.parseInt(merchant);

            String newsql = "SELECT p.pname, ohp.Num, p.price*ohp.Num AS tprice, p.ptype,ohp.color,p.pfunction,p.parts,c.cName,  o.state, ohp.Orders_oNo, o.dateAndTime,o.oTeleNo,o.oAddress" +
                    " FROM orders o, Orders_has_Product ohp,Product p,Customer c " +
                    " WHERE p.pianoNo = ohp.Product_pianoNo AND c.cNo =o.Customer_cNo AND ohp.Orders_oNo = o.oNo " +
                    "AND p.Store_storeNo = ?";   //展示新的数据内容

            newsql =newsql +" ORDER BY o.oNo";
            PreparedStatement newstate = conn.prepareStatement(newsql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            newstate.setInt(1,om);
            ResultSet omrs = newstate.executeQuery();

            jTable.setModel(jp1setTable(omrs,conn,jTable));  //重新展示表格


        } catch (SQLException ome2) {
            ome2.printStackTrace();
        }

    }
    public void INFO (String oNo){      // 显示此订单现有的信息
        int  oNoInt = Integer.parseInt(oNo);
        try{
            Connection psconn = connect();

            int storeNo = Integer.parseInt(merchant);

            String INFOsql = "SELECT p.pname, ohp.Num, p.price*ohp.Num AS tprice, ptype, ohp.color, p.pfunction,p.parts, c.cName, o.state, ohp.Orders_oNo, o.dateAndTime,o.oTeleNo,o.oAddress" +
                    " FROM orders o, Orders_has_Product ohp,Product p, Customer c" +
                    " WHERE p.pianoNo = ohp.Product_pianoNo AND c.cNo =o.Customer_cNo AND ohp.Orders_oNo = o.oNo"+
                    " AND p.Store_storeNo = ? AND o.oNo =? ";
            PreparedStatement ostate = psconn.prepareStatement(INFOsql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            ostate.setInt(1,storeNo);
            ostate.setInt(2,oNoInt);
            ResultSet ors = ostate.executeQuery();

            int count = 0;   //更新JTable
            while (ors.next()) {
                count++;
            }
            //rs.last();
            String comm[][] = new String[count][13];
            count = 0;
            ors.beforeFirst();
            while (ors.next()) {
                comm[count][0] = ors.getString("pname");
                comm[count][1] = ors.getString("ohp.Num");
                comm[count][2] = ors.getString("tprice");
                comm[count][3] = ors.getString("ptype");
                comm[count][4] = ors.getString("ohp.color");
                comm[count][5] = ors.getString("p.pfunction");
                comm[count][6] = ors.getString("p.parts");
                comm[count][7] = ors.getString("c.cName");
                comm[count][8] = ors.getString("o.state");
                comm[count][9] = ors.getString("ohp.Orders_oNo");
                comm[count][10] = ors.getString("o.dateAndTime");
                comm[count][11] = ors.getString("o.oTeleNo");
                comm[count][12] = ors.getString("o.oAddress");

                count++;
            }
            psconn.close();

            opnText3.setText(comm[0][0]);
            opqText3.setText(comm[0][1]);
            oprText3.setText(comm[0][2]);
            String fun,part,state,typ;
            int j=0;
            for (int i=0;i<otypCmb3.getItemCount();i++){
                typ = otypCmb3.getItemAt(i);
                if ( typ.equals(comm[0][3])){
                    j=i;
                    break;
                }
            }
            opcText3.setText(comm[0][4]);
            j=0;
            for (int i=0;i<ofunCmb3.getItemCount();i++){
                fun = ofunCmb3.getItemAt(i);
                if ( fun.equals(comm[0][5])){
                    j=i;
                    break;
                }
            }
            ofunCmb3.setSelectedIndex(j);
            j=0;
            for (int i=0;i<opartCmb3.getItemCount();i++){
                part = opartCmb3.getItemAt(i);
                if ( part.equals(comm[0][6])){
                    j=i;
                    break;
                }
            }
            opartCmb3.setSelectedIndex(j);
            ocnText3.setText(comm[0][7]);
            j=0;
            for (int i=0;i<oStateCmb3.getItemCount();i++){
                state = oStateCmb3.getItemAt(i);
                if (state.equals(comm[0][8])){
                    j=i;
                    break;
                }
            }
            oStateCmb3.setSelectedIndex(j);
            onoText3.setText(comm[0][9]);
            otiText3.setText(comm[0][10]);
            oteText3.setText(comm[0][11]);
            oadText3.setText(comm[0][12]);

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
    }
    public JPanel oSearchGUI(){

        JPanel oINFO = new JPanel();

        JLabel opn = new JLabel("Product name");
        JLabel opq = new JLabel("Quantity");
        JLabel opl= new JLabel("Minimum price");
        JLabel oph= new JLabel("Maximum price");
        JLabel opt = new JLabel("Type");
        JLabel opc = new JLabel("Color");
        JLabel opf = new JLabel("Function");
        JLabel opp = new JLabel("Part");
        JLabel ocn = new JLabel("Customer name");
        JLabel ostate= new JLabel("State");
        JLabel ono = new JLabel("Order No");
        JLabel ost= new JLabel("Start time");
        JLabel oen= new JLabel("End time");
        JLabel ote = new JLabel("Phone number");
        JLabel oad = new JLabel("Address");


        opnText= new JTextField();  //产品名字
        opqText= new JTextField();  //产品数量
        oplText= new JTextField();  //最低
        ophText= new JTextField();  //最高
        opcText= new JTextField();  //产品颜色
        ocnText= new JTextField();  //顾客昵称
        onoText= new JTextField();  //订单编号
        oteText = new JTextField();
        oadText = new JTextField();
        String[] stateValue = {"All","ordered","delivered","completed","canceled"};   //commodity service column
        oStateCmb2 = new JComboBox<String>(stateValue);   //订单状态
        otypCmb = new JComboBox<String>(typValue2);
        ofunCmb = new JComboBox<String>(funValue2);       //产品功能
        opartCmb = new JComboBox<String>(parValue2);     //产品零件
        String[] year = new String[50];
        int j = 0;
        for (int i = 2013; i <2013 + year.length; i++) {
            year[j] = String.valueOf(i);
            j++;
        }
        sTaY = new JComboBox<String>(year);
        eTaY = new JComboBox<String>(year);
        eTaY.setSelectedIndex(49);

        String[] mon = new String[12];
        j = 0;
        for (int i = 1; i <= 12; i++) {
            mon[j] = String.valueOf(i);
            j++;
        }
        sTaM = new JComboBox<String>(mon);
        eTaM = new JComboBox<String>(mon);

        String[] day = new String[31];
        j = 0;
        for (int i = 1; i <= 31; i++) {
            day[j] = String.valueOf(i);
            j++;
        }
        sTaD = new JComboBox<String>(day);
        eTaD = new JComboBox<String>(day);



        opnText.setMaximumSize(new Dimension(500,opnText.getMinimumSize().height));
        opqText.setMaximumSize(new Dimension(500,opqText.getMinimumSize().height));
        oplText.setMaximumSize(new Dimension(500,oplText.getMinimumSize().height));
        ophText.setMaximumSize(new Dimension(500,ophText.getMinimumSize().height));
        opcText.setMaximumSize(new Dimension(500,opcText.getMinimumSize().height));
        ocnText.setMaximumSize(new Dimension(500,ocnText.getMinimumSize().height));
        onoText.setMaximumSize(new Dimension(500,onoText.getMinimumSize().height));
        oteText.setMaximumSize(new Dimension(500,oteText.getMinimumSize().height));
        oadText.setMaximumSize(new Dimension(500,oadText.getMinimumSize().height));
        oStateCmb2.setMaximumSize(new Dimension(Integer.MAX_VALUE,oStateCmb2.getMinimumSize().height));//unit size
        otypCmb.setMaximumSize(new Dimension(Integer.MAX_VALUE,otypCmb.getMinimumSize().height));
        ofunCmb.setMaximumSize(new Dimension(Integer.MAX_VALUE,ofunCmb.getMinimumSize().height));
        opartCmb.setMaximumSize(new Dimension(Integer.MAX_VALUE,opartCmb.getMinimumSize().height));//unit size
        sTaY.setMaximumSize(new Dimension(Integer.MAX_VALUE, sTaY.getMinimumSize().height));//unit size
        sTaM.setMaximumSize(new Dimension(Integer.MAX_VALUE, sTaM.getMinimumSize().height));
        sTaD.setMaximumSize(new Dimension(Integer.MAX_VALUE, sTaD.getMinimumSize().height));//unit size
        eTaY.setMaximumSize(new Dimension(Integer.MAX_VALUE, eTaY.getMinimumSize().height));//unit size
        eTaM.setMaximumSize(new Dimension(Integer.MAX_VALUE, eTaM.getMinimumSize().height));
        eTaD.setMaximumSize(new Dimension(Integer.MAX_VALUE, eTaD.getMinimumSize().height));//unit size




        JPanel  opnPanel= new JPanel();    //添加复选框和文本框
        JPanel  opqPanel= new JPanel();
        JPanel  oplPanel= new JPanel();
        JPanel  ophPanel= new JPanel();
        JPanel  optPanel= new JPanel();
        JPanel  opcPanel= new JPanel();
        JPanel  opfPanel= new JPanel();
        JPanel  oppPanel= new JPanel();
        JPanel  ocnPanel= new JPanel();
        JPanel  onoPanel= new JPanel();
        JPanel st = new JPanel();
        JPanel et = new JPanel();
        JPanel  ostatePanel= new JPanel();
        JPanel  otePanel= new JPanel();
        JPanel  oadPanel= new JPanel();




        opnPanel.setLayout(new BoxLayout(opnPanel, BoxLayout.X_AXIS));
        opqPanel.setLayout(new BoxLayout(opqPanel, BoxLayout.X_AXIS));
        oplPanel.setLayout(new BoxLayout(oplPanel, BoxLayout.X_AXIS));
        ophPanel.setLayout(new BoxLayout(ophPanel, BoxLayout.X_AXIS));
        optPanel.setLayout(new BoxLayout(optPanel, BoxLayout.X_AXIS));
        opcPanel.setLayout(new BoxLayout(opcPanel, BoxLayout.X_AXIS));
        opfPanel.setLayout(new BoxLayout(opfPanel, BoxLayout.X_AXIS));
        oppPanel.setLayout(new BoxLayout(oppPanel, BoxLayout.X_AXIS));
        ocnPanel.setLayout(new BoxLayout(ocnPanel, BoxLayout.X_AXIS));
        onoPanel.setLayout(new BoxLayout(onoPanel, BoxLayout.X_AXIS));
        st.setLayout(new BoxLayout(st, BoxLayout.X_AXIS));
        et.setLayout(new BoxLayout(et, BoxLayout.X_AXIS));
        otePanel.setLayout(new BoxLayout(otePanel, BoxLayout.X_AXIS));
        oadPanel.setLayout(new BoxLayout(oadPanel, BoxLayout.X_AXIS));
        ostatePanel.setLayout(new BoxLayout(ostatePanel, BoxLayout.X_AXIS));



        opnPanel.add(opn);
        opqPanel.add(opq);
        oplPanel.add(opl);
        ophPanel.add(oph);
        optPanel.add(opt);
        opcPanel.add(opc);
        opfPanel.add(opf);
        oppPanel.add(opp);
        ocnPanel.add(ocn);
        ostatePanel.add(ostate);
        onoPanel.add(ono);
        st.add(ost);
        et.add(oen);
        otePanel.add( ote);
        oadPanel.add( oad);
        opnPanel.add(Box.createHorizontalStrut(5));
        opqPanel.add(Box.createHorizontalStrut(5));
        oplPanel.add(Box.createHorizontalStrut(5));
        ophPanel.add(Box.createHorizontalStrut(5));
        optPanel.add(Box.createHorizontalStrut(5));
        opcPanel.add(Box.createHorizontalStrut(5));
        opfPanel.add(Box.createHorizontalStrut(5));
        oppPanel.add(Box.createHorizontalStrut(5));
        ocnPanel.add(Box.createHorizontalStrut(5));
        ostatePanel.add(Box.createHorizontalStrut(5));
        onoPanel.add(Box.createHorizontalStrut(5));
        st.add(Box.createHorizontalStrut(5));
        et.add(Box.createHorizontalStrut(5));
        oadPanel.add(Box.createHorizontalStrut(5));
        opnPanel.add(opnText);
        opqPanel.add(opqText);
        oplPanel.add(oplText);
        ophPanel.add(ophText);
        optPanel.add(otypCmb);
        opcPanel.add(opcText);
        opfPanel.add(ofunCmb);
        oppPanel.add(opartCmb);
        ocnPanel.add(ocnText);
        ostatePanel.add(oStateCmb2);
        onoPanel.add(onoText);
        st.add(sTaY);
        st.add(Box.createHorizontalStrut(5));
        st.add(sTaM);
        st.add(Box.createHorizontalStrut(5));
        st.add(sTaD);
        et.add(eTaY);
        et.add(Box.createHorizontalStrut(5));
        et.add(eTaM);
        et.add(Box.createHorizontalStrut(5));
        et.add(eTaD);
        otePanel.add(oteText);
        oadPanel.add(oadText);



        oINFO.setLayout(new GridLayout(8,2));
        oINFO.add(opnPanel);
        oINFO.add(opqPanel);
        oINFO.add(oplPanel);
        oINFO.add(ophPanel);
        oINFO.add(opcPanel);
        oINFO.add(ocnPanel);
        oINFO.add(optPanel);
        oINFO.add(opfPanel);
        oINFO.add(oppPanel);
        oINFO.add(ostatePanel);
        oINFO.add(onoPanel);
        oINFO.add(otePanel);
        oINFO.add(st);
        oINFO.add(et);
        oINFO.add(oadPanel);


        return oINFO;
    }
    public void oSearch(){

        int index2 = ofunCmb.getSelectedIndex();
        int index3 = opartCmb.getSelectedIndex();
        int index1 = oStateCmb2.getSelectedIndex();
        int index10 = otypCmb.getSelectedIndex();
        int index4 = sTaY.getSelectedIndex();
        int index5 = sTaM.getSelectedIndex();
        int index6 = sTaD.getSelectedIndex();
        int index7 = eTaY.getSelectedIndex();
        int index8 = eTaM.getSelectedIndex();
        int index9 = eTaD.getSelectedIndex();
        String ofuStr = ofunCmb.getItemAt(index2);   //获得功能
        String opaStr = opartCmb.getItemAt(index3);   //获得零件
        String stateStr = oStateCmb2.getItemAt(index1);   //获得状态
        String typStr = otypCmb.getItemAt(index10);    //获得类型
        String syStr = sTaY.getItemAt(index4);   //获得状态
        String smStr = sTaM.getItemAt(index5);
        String sdStr = sTaD.getItemAt(index6);
        String eyStr = eTaY.getItemAt(index7);
        String emStr = eTaM.getItemAt(index8);
        String edStr = eTaD.getItemAt(index9);

        String ostStr = syStr + "-" + smStr + "-" + sdStr;
        String oenStr = eyStr + "-" + emStr + "-" + edStr;

        String opnStr = opnText.getText();
        String opqStr = opqText.getText();
        String oplStr = oplText.getText();
        String ophStr = ophText.getText();
        String opcStr = opcText.getText();
        String ocnStr = ocnText.getText();
        String onoStr = onoText.getText();
        String oteStr = oteText.getText();
        String oadStr = oadText.getText();

        int opqInt=0,onoInt=0;
        double oplDou=0,ophDou=0;
        if (judgeContainsStr(opqStr)){
            JOptionPane.showMessageDialog(null, "Invalid input, please enter a number!", "Tips",
                    JOptionPane.ERROR_MESSAGE);
        }else if (opqStr != null && opqStr.trim().length() != 0 ){   //既不是空指针也不为0
            opqInt= Integer.parseInt(opqStr);  //数量
        }
        if (oplStr != null && oplStr.trim().length() != 0 ){
            oplDou = Double.parseDouble(oplStr);  //最低价
        }
        if (ophStr != null && ophStr.trim().length() != 0 ){
            ophDou = Double.parseDouble(ophStr);  //最高价
        }
        if ( judgeContainsStr(onoStr)){
            JOptionPane.showMessageDialog(null, "Invalid input, please enter a number!", "Tips",
                    JOptionPane.ERROR_MESSAGE);
        }else if(onoStr != null && onoStr.trim().length() != 0 ) {
            onoInt = Integer.parseInt(onoStr.trim()); //订单编号
        }

        String[] sql ={"","","","","","","","","","","","","","",""};
        sql[0] = " AND pname LIKE \"%\"?\"%\" ";
        sql[1] = " AND ohp.Num=?";
        sql[2] = " AND p.price*ohp.Num  > ? ";
        sql[3] = " AND p.price*ohp.Num  < ?";
        sql[4] = " AND p.ptype  = ?";
        sql[5] = " AND ohp.color =?";
        sql[6] = " AND p.pfunction=?";
        sql[7] = " AND p.parts = ?";
        sql[8] = " AND c.cName LIKE \"%\"?\"%\" ";
        sql[9] = " AND o.state =?";
        sql[10] = " AND o.oNo =?";
        sql[11] = " AND o.dateAndTime > ? ";
        sql[12] = " AND o.dateAndTime < ?";
        sql[13] = " AND o.oTeleNo = ?";
        sql[14] = " AND o.oAddress LIKE \"%\"?\"%\" ";

        try{

            Connection osconn = connect();

            int om = Integer.parseInt(merchant);
            String osq1 = "SELECT p.pname, ohp.Num, p.price*ohp.Num AS tprice, p.ptype,ohp.color,p.pfunction,p.parts,c.cName, o.state, ohp.Orders_oNo, o.dateAndTime,o.oTeleNo,o.oAddress" +
                    " FROM orders o, Orders_has_Product ohp,Product p,Customer c " +
                    " WHERE p.pianoNo = ohp.Product_pianoNo  AND ohp.Orders_oNo = o.oNo AND c.cNo = o.Customer_cNo ";
            osq1 = osq1 + " AND p.Store_storeNo = ?";


            //添加筛选条件
            int[] pos ={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
            int pos2 =1;  //计算被选中的信息要插入的sql的位置
            if( opnStr != null && opnStr.trim().length() != 0){   //如果输入了产品名称
                osq1 = osq1 + sql[0];
                pos2++;
                pos[0]=pos2;   //pos[0]=2
            }
            if( opqStr != null && opqStr.trim().length() != 0){
                osq1 = osq1 + sql[1];
                pos2++;
                pos[1]=pos2;     //pos[1]=3
            }
            if( oplStr != null && oplStr.trim().length() != 0 && (! oplStr.equals("Minimum")) ){
                osq1 = osq1 + sql[2];
                pos2 ++ ;
                pos[2]=pos2;   //pos[2]=5
            }
            if(  ophStr != null && ophStr.trim().length() != 0 && (! ophStr.equals("Maximum"))){
                osq1 = osq1 + sql[3];    //最低价、最高价必须都有有效输入
                pos2 ++ ;
                pos[3]=pos2;
            }
            if(  typStr != null && typStr.trim().length() != 0){
                osq1 = osq1 + sql[4];     //产品颜色
                pos2++;
                pos[4]=pos2;
            }
            if(  opcStr != null && opcStr.trim().length() != 0){
                osq1 = osq1 + sql[5];     //产品颜色
                pos2++;
                pos[5]=pos2;
            }
            if( ofuStr != null && ofuStr.trim().length() != 0 && (! ofuStr.equals("All"))){     //产品功能
                osq1 = osq1 + sql[6];
                pos2++;
                pos[6]= pos2;
            }
            if( opaStr != null && opaStr.trim().length() != 0 && (! opaStr.equals("All"))){    //产品零件
                osq1 = osq1 + sql[7];
                pos2++;
                pos[7]=pos2;
            }
            if( ocnStr != null && ocnStr.trim().length() != 0){   //顾客昵称
                osq1 = osq1 + sql[8];
                pos2++;
                pos[8]=pos2;
            }
            if(stateStr!= null && stateStr.trim().length() != 0 && (! stateStr.equals("All"))){    //订单状态
                osq1 = osq1 + sql[9];
                pos2++;
                pos[9]=pos2;
            }
            if( onoStr != null && onoStr.trim().length() != 0){   //订单编号
                osq1 = osq1 + sql[10];
                pos2++;
                pos[10]=pos2;
            }
            if(  ostStr != null && ostStr.trim().length() != 0  ){   //起止时间，两个都必须输入
                osq1 = osq1 + sql[11];   //开始日期
                pos2++;
                pos[11]=pos2;
            }
            if(  oenStr != null  && oenStr.trim().length() != 0 ){   //起止时间，两个都必须输入
                osq1 = osq1 + sql[12];   //结束日期
                pos2++;
                pos[12]=pos2;
            }
            if ( oteStr != null && oteStr.trim().length() != 0){     //顾客电话
                osq1 = osq1 + sql[13];
                pos2++;
                pos[13]=pos2;
            }
            if ( oadStr != null && oadStr.trim().length() != 0){   //顾客地址
                osq1 = osq1 + sql[14];
                pos2++;
                pos[14]=pos2;
            }


            osq1 = osq1 + " GROUP BY o.oNo";
            PreparedStatement ostate = osconn.prepareStatement(osq1,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            ostate.setInt(1,om);
            for ( int j=0;j<15;j++){
                if (pos[j]!=0){
                    if (j==0){
                        ostate.setString(pos[j],opnStr);   //2
                    }
                    if(j==1){
                        ostate.setInt(pos[j],opqInt);  //3
                    }
                    if(j==2){
                        ostate.setDouble(pos[j],oplDou);  //4
                    }
                    if(j==3){
                        ostate.setDouble(pos[j],ophDou);   //5
                    }
                    if(j==4){
                        ostate.setString(pos[j],typStr);       //产品类型
                    }
                    if(j==5){
                        ostate.setString(pos[j],opcStr);       //产品颜色
                    }
                    if(j==6){
                        ostate.setString(pos[j],ofuStr);      //产品功能
                    }
                    if(j==7){
                        ostate.setString(pos[j],opaStr);
                    }
                    if(j==8){
                        ostate.setString(pos[j],ocnStr);
                    }
                    if(j==9){
                        ostate.setString(pos[j],stateStr);
                    }
                    if(j==10){
                        ostate.setInt(pos[j], onoInt );
                    }
                    if(j==11){
                        ostate.setString(pos[j],ostStr);
                    }
                    if(j==12){
                        ostate.setString(pos[j],oenStr);
                    }
                    if(j==13){
                        ostate.setString(pos[j], oteStr  );
                    }
                    if(j==14){
                        ostate.setString(pos[j],oadStr );
                    }
                }else{

                }
            }
            ResultSet ors = ostate.executeQuery();
            if (  ors.isBeforeFirst()){
                jTable.setModel(jp1setTable(ors,osconn,jTable));
            }else if ( (!judgeContainsStr(onoStr) )&& (! judgeContainsStr(opqStr))){
                JOptionPane.showMessageDialog(null, "Order not found!", "Tips",
                        JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
    }
    class jp1ButtonListener implements ActionListener{
        public void actionPerformed(ActionEvent e){

            //获取按钮信息，如果是修改，生成修改界面。然后更新数据

            if (odel.isSelected()){

                String odNo = JOptionPane.showInputDialog("Please enter the order number");
                if (odNo != null && odNo.trim().length() != 0 ){
                    if(! judgeContainsStr(odNo)){
                        int odInt = Integer.parseInt(odNo);
                        if(!checkExist(odNo)){
                            JOptionPane.showMessageDialog(null, "Order not found!", "Tips",
                                    JOptionPane.ERROR_MESSAGE);
                        }else{
                            try{

                                Connection delconn = connect();

                                String delsq2 = "DELETE FROM Orders_has_Product WHERE Orders_oNo =?";
                                PreparedStatement delstate2 = delconn.prepareStatement(delsq2,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
                                delstate2.setInt(1,odInt);
                                delstate2.executeUpdate();

                                String delsq1 = "DELETE FROM Orders WHERE oNo=?";
                                PreparedStatement delstate = delconn.prepareStatement(delsq1,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
                                delstate.setInt(1,odInt);
                                delstate.executeUpdate();



                                int omm = Integer.parseInt(merchant);
                                String delsq3 = "SELECT p.pname, ohp.Num, p.price*ohp.Num AS tprice, p.ptype, ohp.color,p.pfunction,p.parts,c.cName, o.state, ohp.Orders_oNo, o.dateAndTime,o.oTeleNo,o.oAddress" +
                                        " FROM orders o, Orders_has_Product ohp,Product p,Customer c " +
                                        " WHERE p.pianoNo = ohp.Product_pianoNo AND c.cNo =o.Customer_cNo AND ohp.Orders_oNo = o.oNo " +
                                        "AND p.Store_storeNo = ?";
                                delsq3 = delsq3 +" ORDER BY o.oNo";
                                PreparedStatement delstate3 = delconn.prepareStatement(delsq3, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                                delstate3.setInt(1,omm);
                                ResultSet delrs = delstate3.executeQuery();
                                jTable.setModel(jp1setTable(delrs,delconn,jTable));

                            } catch (SQLException e2) {
                                e2.printStackTrace();
                            }
                        }
                    }else{
                        JOptionPane.showMessageDialog(null, "Please enter a number!", "Tips",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }

            }else if (omod.isSelected() ){

                omValue = JOptionPane.showInputDialog("Please enter order number");

                if (omValue != null && omValue.trim().length() != 0 ){
                    if(! judgeContainsStr(omValue)){
                        if(!checkExist(omValue)){
                            JOptionPane.showMessageDialog(null, "Order not found!", "Tips",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                        else{
                            om = new JFrame("Modify");
                            omy = new JButton("Yes");                          //确定取消按钮
                            omcan = new JButton("Canacel");
                            omy.addActionListener(new oMButtonListener());
                            omcan.addActionListener(new oMButtonListener());
                            JPanel yp = new JPanel();
                            JPanel cp = new JPanel();
                            JPanel biop = new JPanel();
                            yp.add(omy);
                            cp.add(omcan);
                            biop.setLayout(new GridLayout(1,2));
                            biop.add(yp);
                            biop.add(cp);

                            JPanel content = new JPanel();
                            content.setLayout(new BorderLayout(5,10));
                            content.add(oModifyGUI(),BorderLayout.CENTER);
                            content.add(biop,BorderLayout.SOUTH);
                            INFO(omValue);
                            opnText3.setEnabled(false);
                            onoText3.setEditable(false);
                            onoText3.setEnabled(false);
                            oprText3.setEnabled(false);
                            ocnText3.setEnabled(false);
                            otiText3.setEnabled(false);
                        /*
                        ofunCmb3.setEnabled(false);
                        opartCmb3.setEnabled(false);

                         */

                            JLabel space0 = new JLabel("                    ");
                            JLabel space1 = new JLabel("                    ");
                            om.setLayout(new BorderLayout(5,10));
                            om.add(space0,BorderLayout.WEST);
                            om.add(content,BorderLayout.CENTER);
                            om.add(space1,BorderLayout.EAST);


                            om.setSize(650,350);
                            om.setLocation(300,200);
                            om.setVisible(true);
                        }
                    }else{
                        JOptionPane.showMessageDialog(null, "Please enter a number!", "Tips",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }

            }else if (osea.isSelected()){

                os = new JFrame("Search");

                osy = new JButton("Yes");                          //确定取消按钮
                oscan = new JButton("Canacel");
                osy.addActionListener(new oSButtonListener());
                oscan.addActionListener(new oSButtonListener());
                JPanel yesp = new JPanel();
                JPanel canp = new JPanel();
                JPanel bio = new JPanel();
                yesp.add(osy);
                canp.add(oscan);
                bio.setLayout(new GridLayout(1,2));
                bio.add(yesp);
                bio.add(canp);

                JPanel content = new JPanel();
                content.setLayout(new BorderLayout(5,10));
                content.add(oSearchGUI(),BorderLayout.CENTER);
                content.add(bio,BorderLayout.SOUTH);

                JLabel space0 = new JLabel("                    ");
                JLabel space1 = new JLabel("                    ");
                os.setLayout(new BorderLayout(5,10));
                os.add(space0,BorderLayout.WEST);
                os.add(content,BorderLayout.CENTER);
                os.add(space1,BorderLayout.EAST);

                os.setSize(650,350);
                os.setLocation(300,200);
                os.setVisible(true);

            }else if(figure.isSelected()){

                JFrame f  = new JFrame("Statistics");
                String sNo= merchant;
                f .add(jp3GUI(sNo));
                f .setSize(650,350);
                f .setLocation(300,200);
                f .setVisible(true);


            } else if(osho.isSelected()){
                try{
                    Connection sconn = connect();
                    int om = Integer.parseInt(merchant);
                    String ssql = "SELECT p.pname, ohp.Num, p.price*ohp.Num AS tprice, p.ptype, ohp.color,p.pfunction,p.parts,c.cName, o.state, ohp.Orders_oNo, o.dateAndTime,o.oTeleNo,o.oAddress" +
                            " FROM orders o, Orders_has_Product ohp,Product p,Customer c " +
                            " WHERE p.pianoNo = ohp.Product_pianoNo AND c.cNo =o.Customer_cNo AND ohp.Orders_oNo = o.oNo AND p.Store_storeNo = ?";
                    ssql = ssql +" ORDER BY o.oNo";
                    PreparedStatement s = sconn.prepareStatement(ssql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    s.setInt(1,om);
                    ResultSet ses = s.executeQuery();
                    System.out.println("Query successfully!");
                    jTable.setModel(jp1setTable(ses,sconn,jTable));

                } catch (SQLException e2) {
                    e2.printStackTrace();
                }

            }
        }
    }
    class oMButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent ome){
            if ( ome.getSource() == omy){    //modify the state of the item
                oModify(omValue);
                om.dispose();
            }else{
                om.dispose();
            }

        }
    }
    //jp1 订单管理     订单修改GUI的事件响应
    class oSButtonListener implements  ActionListener{
        public void actionPerformed(ActionEvent oa){
            if ( oa.getSource() == osy){    //modify the state of the item
                oSearch();
                os.dispose();
            }else{
                os.dispose();
            }
        }
    }




    class jp2ButtonListener implements ActionListener{    //商品管理      服务选择项的事件响应
        public void actionPerformed(ActionEvent e){

            if (pdel.isSelected()){                             //删除服务
                String delOut = JOptionPane.showInputDialog("Please enter the product number");
                if (delOut!=null && delOut.trim().length()!=0 ){
                    if(! judgeContainsStr(delOut)){
                        int delInt = Integer.parseInt(delOut);
                        if(!checkPExist(delOut)){
                            JOptionPane.showMessageDialog(null, "Product not found!", "Tips",
                                    JOptionPane.ERROR_MESSAGE);
                        }else{
                            try{
                                Connection delconn = connect();

                                String s = "SELECT * FROM product";
                                String delsq1 = "DELETE FROM product WHERE pianoNo= ?";
                                PreparedStatement delstate = delconn.prepareStatement(delsq1,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
                                delstate.setInt(1,delInt);
                                delstate.execute(s);
                                delstate.execute(" SET FOREIGN_KEY_CHECKS = 0;");
                                delstate.executeUpdate();
                                delstate.execute("SET FOREIGN_KEY_CHECKS = 1; ");

                                int cm = Integer.parseInt(merchant);
                                String delsql = "SELECT pianoNo, pname, price, pcomment,statement,ptype, pfunction,parts,Store_storeNo, photo,brand,size FROM product WHERE Store_storeNo=? ";   //展示新的数据内容
                                PreparedStatement delstate2 = delconn.prepareStatement(delsql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                                delstate2.setInt(1,cm);
                                ResultSet delrs = delstate2.executeQuery();
                                pmTable.setModel(jp2setTable(delrs,delconn,pmTable));

                            } catch (SQLException e2) {
                                e2.printStackTrace();
                            }
                        }
                    }else{
                        JOptionPane.showMessageDialog(null, "Please enter a number!", "Tips",
                                JOptionPane.ERROR_MESSAGE);
                    }

                }

            }else if (padd.isSelected()){                             //添加服务

                pa = new JFrame("Add");


                payes = new JButton("Yes");
                pacan = new JButton("Cancel");
                payes.addActionListener(new pAButtonListener());
                pacan.addActionListener(new pAButtonListener());
                JPanel pyes = new JPanel();
                JPanel pcan = new JPanel();
                JPanel bio = new JPanel();
                pyes.add(payes);
                pcan.add(pacan);
                bio.setLayout(new GridLayout(1,2));
                bio.add(pyes);
                bio.add(pcan);


                JPanel content = new JPanel();
                content.setLayout(new BorderLayout(5,10));
                content.add(pINFOGUI(),BorderLayout.CENTER);
                content.add(bio,BorderLayout.SOUTH);
                psoText1.setText("301");
                psoText1.setEnabled(false);


                JLabel space0 = new JLabel("                    ");
                JLabel space1 = new JLabel("                    ");
                pa.setLayout(new BorderLayout(5,10));
                pa.add(space0,BorderLayout.WEST);
                pa.add(content,BorderLayout.CENTER);
                pa.add(space1,BorderLayout.EAST);

                pa.setSize(650,350);
                pa.setLocation(300,200);
                pa.setVisible(true);

            }else if(pmod.isSelected()){
                pmValue = JOptionPane.showInputDialog("Please enter product number");
                if (pmValue!= null && pmValue.trim().length() != 0 ){
                    if(! judgeContainsStr(pmValue)){
                        if(!checkPExist(pmValue)){
                            JOptionPane.showMessageDialog(null, "Product not found!", "Tips",
                                    JOptionPane.ERROR_MESSAGE);
                        }else{
                            pm = new JFrame("Modify");

                            pmyes = new JButton("Yes");                          //确定取消按钮
                            pmcan = new JButton("Canacel");
                            pmyes.addActionListener(new pMButtonListener());
                            pmcan.addActionListener(new pMButtonListener());
                            JPanel yp = new JPanel();
                            JPanel cp = new JPanel();
                            JPanel biop = new JPanel();
                            yp.add(pmyes);
                            cp.add(pmcan);
                            biop.setLayout(new GridLayout(1,2));
                            biop.add(yp);
                            biop.add(cp);

                            JPanel content = new JPanel();
                            content.setLayout(new BorderLayout(5,10));
                            content.add(pINFOGUI(),BorderLayout.CENTER);
                            content.add(biop,BorderLayout.SOUTH);
                            pINFO(pmValue);
                            pnoText1.setEnabled(false);


                            JLabel space0 = new JLabel("                    ");
                            JLabel space1 = new JLabel("                    ");
                            pm.setLayout(new BorderLayout(5,10));
                            pm.add(space0,BorderLayout.WEST);
                            pm.add(content,BorderLayout.CENTER);
                            pm.add(space1,BorderLayout.EAST);


                            pm.setSize(650,350);
                            pm.setLocation(300,200);
                            pm.setVisible(true);
                        }
                    }else{
                        JOptionPane.showMessageDialog(null, "Please enter a number!", "Tips",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }

            }else if(psea.isSelected()){


                ps = new JFrame("Search");


                psyes = new JButton("Yes");
                pscan = new JButton("Cancel");
                psyes.addActionListener(new pSButtonListener());
                pscan.addActionListener(new pSButtonListener());
                JPanel pyes = new JPanel();
                JPanel pcan = new JPanel();
                JPanel bio = new JPanel();
                pyes.add(psyes);
                pcan.add(pscan);
                bio.setLayout(new GridLayout(1,2));
                bio.add(pyes);
                bio.add(pcan);


                JPanel content = new JPanel();
                content.setLayout(new BorderLayout(5,10));
                content.add(pSearchGUI(),BorderLayout.CENTER);
                content.add(bio,BorderLayout.SOUTH);

                JLabel space0 = new JLabel("                    ");
                JLabel space1 = new JLabel("                    ");
                ps.setLayout(new BorderLayout(5,10));
                ps.add(space0,BorderLayout.WEST);
                ps.add(content,BorderLayout.CENTER);
                ps.add(space1,BorderLayout.EAST);


                ps.setSize(650,350);
                ps.setLocation(300,200);
                ps.setVisible(true);

            }
            else if (psho.isSelected()){
                try{    //将数据库信息放到JTable中
                    Connection pmdconn = connect();
                    int cm4 = Integer.parseInt(merchant);
                    String sql2222 = "SELECT pianoNo, pname, price, pcomment,statement,ptype, pfunction,parts,Store_storeNo, photo,brand,size FROM product WHERE Store_storeNo=?";
                    PreparedStatement pmdstmt = pmdconn.prepareStatement(sql2222,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    pmdstmt.setInt(1,cm4);
                    ResultSet pmdres = pmdstmt.executeQuery();

                    pmTable.setModel(jp2setTable(pmdres,pmdconn,pmTable));

                } catch (SQLException e2) {
                    e2.printStackTrace();
                }
            }
        }
    }   //商品管理      服务选择项的事件响应
    class pAButtonListener implements ActionListener{    //商品管理 添加确认按钮的事件响应
        public void actionPerformed(ActionEvent pme){
            if( pme.getSource() == payes ){
                pAdd();
                pa.dispose();
            }else{
                pa.dispose();
            }
        }
    }
    class pMButtonListener implements ActionListener{
        public void actionPerformed(ActionEvent pme){
            if ( pme.getSource() == pmyes){
                pModify(pmValue);
                pm.dispose();
            }else{
                pm.dispose();
            }
        }
    }
    class pSButtonListener implements ActionListener{
        public void actionPerformed(ActionEvent p){
            if ( p.getSource() == psyes){    //modify the state of the item
                pSearch();
                ps.dispose();
            }else{
                ps.dispose();
            }
        }
    }
    public JPanel jp2GUI(){
        //item management on jp2   (item management)
        JPanel jp2 = new JPanel();
        JPanel itemPanel = new JPanel();
        JPanel itemLeft = new JPanel();
        itemPanel.setLayout(new BoxLayout(itemPanel, BoxLayout.Y_AXIS));
        itemLeft.setLayout(new GridLayout(3,1,50,20));

        JLabel plb = new JLabel("Please select the operation");
        pdel = new JRadioButton("Delete product");
        padd = new JRadioButton("Add product");
        pmod = new JRadioButton("Modify product");
        psea = new JRadioButton("Search product");
        psho = new JRadioButton("Show all products");
        pservice = new ButtonGroup();
        pservice.add(pdel);
        pservice.add(padd);
        pservice.add(pmod);
        pservice.add( psea);
        pservice.add(psho);



        JPanel itemButtonPanel = new JPanel();               //commodity service button
        itemButton = new JButton("Process");
        itemButton.addActionListener(new jp2ButtonListener()); //item button listener
        itemButtonPanel.add(itemButton);

        itemPanel.setLayout(new GridLayout(7,1));
        itemPanel.add(plb);
        itemPanel.add(pdel);
        itemPanel.add(padd);
        itemPanel.add(pmod);
        itemPanel.add(psea);
        itemPanel.add(psho);
        itemPanel.add(itemButtonPanel);   //space + service column + button (leftside)


        /**
         * 商品管理结果展示表
         */
        try{    //将数据库信息放到JTable中
            Connection pmdconn = connect();
            int cm4 = Integer.parseInt(merchant);
            String sql2222 = "SELECT pianoNo, pname, price, pcomment,statement,ptype, pfunction,parts,Store_storeNo, photo,brand,size FROM product WHERE Store_storeNo=?";
            PreparedStatement pmdstmt = pmdconn.prepareStatement(sql2222,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            pmdstmt.setInt(1,cm4);
            ResultSet pmdres = pmdstmt.executeQuery();


            System.out.println("Query successfully!");

            pmTable= new JTable(jp2setTable(pmdres,pmdconn,pmTable));
            pmTable.setPreferredScrollableViewportSize(new Dimension(800,200));
            JScrollPane pmScroll = new JScrollPane(pmTable,
                    ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

            jp2.setLayout(new BorderLayout(20,15));   //add component on jp2
            jp2.add(itemPanel,BorderLayout.WEST);
            jp2.add(pmScroll,BorderLayout.CENTER);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jp2;
    }
    public JPanel pINFOGUI(){
        JLabel pnoLabel1 = new JLabel("Product No");
        JLabel pnaLabel1 = new JLabel("Product Name");
        JLabel priLabel1= new JLabel("Price");
        JLabel pcoLabel1= new JLabel("Comment");
        JLabel pstLabel1= new JLabel("Statement");
        JLabel typLabel1= new JLabel("Type");
        JLabel funLabel1= new JLabel("Function");
        JLabel parLabel1= new JLabel("Part");
        JLabel psoLabel1= new JLabel("StoreNo");
        JLabel phoLabel1= new JLabel("Photo");
        JLabel pbrLabel1= new JLabel("Brand");
        JLabel psiLabel1= new JLabel("Size");


        pnoText1 = new JTextField();
        pnaText1 = new JTextField();
        priText1 = new JTextField();  //最低价格
        pcoText1 = new JTextField();
        pstText1= new JTextField();
        psoText1= new JTextField();
        phoText1= new JTextField();
        pbrText1= new JTextField();
        psiText1= new JTextField();
        typCmb1 = new JComboBox<String>(typValue);
        funCmb1= new JComboBox<String>(funValue);
        parCmb1= new JComboBox<String>(parValue);
        typCmb1.setSelectedIndex(0);
        funCmb1.setSelectedIndex(0);
        parCmb1.setSelectedIndex(0);


        pnoText1.setMaximumSize(new Dimension(500, pnoText1.getMinimumSize().height));
        pnaText1.setMaximumSize(new Dimension(500,pnaText1.getMinimumSize().height));
        priText1.setMaximumSize(new Dimension(500,priText1.getMinimumSize().height));
        pcoText1.setMaximumSize(new Dimension(500,pcoText1.getMinimumSize().height));
        pstText1.setMaximumSize(new Dimension(500,pstText1.getMinimumSize().height));
        psoText1.setMaximumSize(new Dimension(500,psoText1.getMinimumSize().height));
        phoText1.setMaximumSize(new Dimension(500,phoText1.getMinimumSize().height));
        pbrText1.setMaximumSize(new Dimension(500,pbrText1.getMinimumSize().height));
        psiText1.setMaximumSize(new Dimension(500,psiText1.getMinimumSize().height));
        typCmb1.setMaximumSize(new Dimension(Integer.MAX_VALUE,typCmb1.getMinimumSize().height));//unit size
        funCmb1.setMaximumSize(new Dimension(Integer.MAX_VALUE, funCmb1.getMinimumSize().height));//unit size
        parCmb1.setMaximumSize(new Dimension(Integer.MAX_VALUE, parCmb1.getMinimumSize().height));//unit size


        JPanel  pnoPanel1 = new JPanel();
        JPanel  pnaPanel1= new JPanel();
        JPanel  priPanel1= new JPanel();
        JPanel  pcoPanel1= new JPanel();
        JPanel  pstPanel1= new JPanel();
        JPanel  typPanel1= new JPanel();
        JPanel  funPanel1= new JPanel();
        JPanel  parPanel1= new JPanel();
        JPanel  psoPanel1= new JPanel();
        JPanel  phoPanel1= new JPanel();
        JPanel  pbrPanel1= new JPanel();
        JPanel  psiPanel1= new JPanel();

        pnoPanel1.setLayout(new BoxLayout( pnoPanel1, BoxLayout.X_AXIS));
        pnaPanel1.setLayout(new BoxLayout(pnaPanel1, BoxLayout.X_AXIS));
        priPanel1.setLayout(new BoxLayout(priPanel1, BoxLayout.X_AXIS));
        pcoPanel1.setLayout(new BoxLayout(pcoPanel1, BoxLayout.X_AXIS));
        pstPanel1.setLayout(new BoxLayout(pstPanel1, BoxLayout.X_AXIS));
        typPanel1.setLayout(new BoxLayout(typPanel1, BoxLayout.X_AXIS));
        funPanel1.setLayout(new BoxLayout(funPanel1, BoxLayout.X_AXIS));
        parPanel1.setLayout(new BoxLayout(parPanel1, BoxLayout.X_AXIS));
        psoPanel1.setLayout(new BoxLayout(psoPanel1, BoxLayout.X_AXIS));
        phoPanel1.setLayout(new BoxLayout(phoPanel1, BoxLayout.X_AXIS));
        pbrPanel1.setLayout(new BoxLayout(pbrPanel1, BoxLayout.X_AXIS));
        psiPanel1.setLayout(new BoxLayout(psiPanel1, BoxLayout.X_AXIS));

        pnoPanel1.add(pnoLabel1);
        pnaPanel1.add( pnaLabel1);
        priPanel1.add(priLabel1);
        pcoPanel1.add(pcoLabel1);
        pstPanel1.add(pstLabel1);
        typPanel1.add(typLabel1);
        funPanel1.add(funLabel1);
        parPanel1.add(parLabel1);
        psoPanel1.add(psoLabel1);
        phoPanel1.add(phoLabel1);
        pbrPanel1.add(pbrLabel1);
        psiPanel1.add(psiLabel1);
        pnaPanel1.add(Box.createHorizontalStrut(5));
        pnoPanel1.add(Box.createHorizontalStrut(5));
        priPanel1.add(Box.createHorizontalStrut(5));
        pcoPanel1.add(Box.createHorizontalStrut(5));
        pstPanel1.add(Box.createHorizontalStrut(5));
        typPanel1.add(Box.createHorizontalStrut(5));
        funPanel1.add(Box.createHorizontalStrut(5));
        parPanel1.add(Box.createHorizontalStrut(5));
        psoPanel1.add(Box.createHorizontalStrut(5));
        phoPanel1.add(Box.createHorizontalStrut(5));
        pbrPanel1.add(Box.createHorizontalStrut(5));
        psiPanel1.add(Box.createHorizontalStrut(5));
        pnaPanel1.add( pnaText1);
        pnoPanel1.add(pnoText1);
        priPanel1.add(priText1);
        pcoPanel1.add(pcoText1);
        pstPanel1.add(pstText1);
        typPanel1.add(typCmb1);
        funPanel1.add(funCmb1);
        parPanel1.add(parCmb1);
        psoPanel1.add(psoText1);
        phoPanel1.add(phoText1);
        pbrPanel1.add(pbrText1);
        psiPanel1.add(psiText1);


        JPanel pcontent = new JPanel();
        pcontent.setLayout(new GridLayout(6,2)); //component in center
        pcontent.add(pnoPanel1);
        pcontent.add(pnaPanel1);
        pcontent.add(priPanel1);
        pcontent.add(pcoPanel1);
        pcontent.add(pstPanel1);
        pcontent.add(typPanel1);
        pcontent.add(funPanel1);
        pcontent.add(parPanel1);
        pcontent.add(psoPanel1);
        pcontent.add(phoPanel1);
        pcontent.add(pbrPanel1);
        pcontent.add(psiPanel1);
        return pcontent;
    }
    public void pINFO(String pNo){
        int  pNoInt = Integer.parseInt(pNo);
        try{
            Connection pconn = connect();

            int storeNo = Integer.parseInt(merchant);

            String INFOsql = "SELECT pianoNo, pname, price, pcomment,statement,ptype, pfunction,parts,Store_storeNo, photo,brand,size " +
                    "FROM product WHERE Store_storeNo=? AND pianoNo =?";
            PreparedStatement pstate = pconn.prepareStatement(INFOsql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            pstate.setInt(1,storeNo);
            pstate.setInt(2,pNoInt);
            ResultSet prs = pstate.executeQuery();

            int count = 0;   //更新JTable
            while (prs.next()) {
                count++;
            }
            //rs.last();
            String comm[][] = new String[count][12];
            count = 0;
            prs.beforeFirst();
            while (prs.next()) {
                comm[count][0] = prs.getString("pianoNo");
                comm[count][1] = prs.getString("pname");
                comm[count][2] = prs.getString("price");
                comm[count][3] = prs.getString("pcomment");
                comm[count][4] = prs.getString("statement");
                comm[count][5] = prs.getString("ptype");
                comm[count][6] = prs.getString("pfunction");
                comm[count][7] = prs.getString("parts");
                comm[count][8] = prs.getString("Store_storeNo");
                comm[count][9] = prs.getString("photo");
                comm[count][10] = prs.getString("brand");
                comm[count][11] = prs.getString("size");
                count++;
            }
            pconn.close();

            pnoText1.setText(comm[0][0]);
            pnaText1.setText(comm[0][1]);
            priText1.setText(comm[0][2]);
            pcoText1.setText(comm[0][3]);
            pstText1.setText(comm[0][4]);
            String typ,fun,par;
            int j=0;
            for (int i=0;i<3;i++){
                typ = typCmb1.getItemAt(i);
                if ( typ.equals(comm[0][5])){
                    j=i;
                    break;
                }
            }
            typCmb1.setSelectedIndex(j);
            j=0;
            for (int i=0;i<3;i++){
                fun = funCmb1.getItemAt(i);
                if ( fun.equals(comm[0][6])){
                    j=i;
                    break;
                }
            }
            funCmb1.setSelectedIndex(j);
            j=0;
            for (int i=0;i<2;i++){
                par = parCmb1.getItemAt(i);
                if (par.equals(comm[0][7])){
                    j=i;
                    break;
                }
            }
            parCmb1.setSelectedIndex(j);
            psoText1.setText(comm[0][8]);
            phoText1.setText(comm[0][9]);
            pbrText1.setText(comm[0][10]);
            psiText1.setText(comm[0][11]);


        } catch (SQLException e2) {
            e2.printStackTrace();
        }
    }
    public void pAdd(){   //sql

        int index1 = typCmb1.getSelectedIndex();
        int index2 = funCmb1.getSelectedIndex();
        int index3 = parCmb1.getSelectedIndex();
        String typStr = typCmb1.getItemAt(index1);   //获得类型
        String funStr = funCmb1.getItemAt(index2);   //获得功能
        String parStr = parCmb1.getItemAt(index3);   //获得零件


        String pnoStr = pnoText1.getText();
        String pnaStr = pnaText1.getText();
        String priStr = priText1.getText();
        String pcoStr = pcoText1.getText();
        String pstStr = pstText1.getText();
        String psoStr = psoText1.getText();
        String phoStr = phoText1.getText();
        String pbrStr = pbrText1.getText();
        String psiStr = psiText1.getText();

        double priDou=0;
        int pnoInt=0, psoInt=0;
        if(pnoStr != null && pnoStr.trim().length() != 0){
            pnoInt = Integer.parseInt(pnoStr);
        }
        if (priStr != null && priStr.trim().length() != 0 ) {
            priDou = Double.parseDouble(priStr);  //价格
        }if (psoStr != null && psoStr.trim().length() != 0){   //既不是空指针也不为0
            psoInt= Integer.parseInt(psoStr);  //商店编号
        }
        if (checkPExist(pnoStr)){
            JOptionPane.showMessageDialog(null, "Duplicate product number, please enter again!", "Tips",
                    JOptionPane.ERROR_MESSAGE);
        }else{
            try{
                Connection addconn = connect();
                String s = "SELECT * FROM product";
                String addsq1 = "INSERT INTO product VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ";
                PreparedStatement state1 = addconn.prepareStatement(addsq1,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                state1.setInt(1,pnoInt);
                state1.setString(2,pnaStr);
                state1.setDouble(3,priDou);
                state1.setString(4,pcoStr);
                state1.setString(5,pstStr);
                state1.setString(6,typStr);
                state1.setString(7,funStr);
                state1.setString(8,parStr);
                state1.setInt(9,101);
                state1.setInt(10,psoInt);
                state1.setString(11,phoStr);
                state1.setString(12,pbrStr);
                state1.setString(13,psiStr);
                state1.execute(s);
                state1.execute(" SET FOREIGN_KEY_CHECKS = 0; ");
                state1.executeUpdate();
                state1.execute(" SET FOREIGN_KEY_CHECKS = 1; ");


                //展示新的数据内容
                int cm4 = Integer.parseInt(merchant);
                String sql2222 = "SELECT pianoNo, pname, price, pcomment,statement,ptype, pfunction,parts,Store_storeNo, photo,brand,size FROM product WHERE Store_storeNo=?";
                PreparedStatement pmdstmt = addconn .prepareStatement(sql2222,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                pmdstmt.setInt(1,cm4);
                ResultSet pmdres = pmdstmt.executeQuery();
                pmTable.setModel(jp2setTable(pmdres,addconn ,pmTable));

            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
    }
    public void pModify(String pNo){
        int pNoInt = Integer.parseInt(pNo);
        int index1 = typCmb1.getSelectedIndex();
        int index2 = funCmb1.getSelectedIndex();
        int index3 = parCmb1.getSelectedIndex();
        String typStr = typCmb1.getItemAt(index1);   //获得类型
        String funStr = funCmb1.getItemAt(index2);   //获得功能
        String parStr = parCmb1.getItemAt(index3);   //获得零件


        String pnaStr = pnaText1.getText();
        String priStr = priText1.getText();
        String pcoStr = pcoText1.getText();
        String pstStr = pstText1.getText();
        String psoStr = psoText1.getText();
        String phoStr = phoText1.getText();
        String pbrStr = pbrText1.getText();
        String psiStr = psiText1.getText();

        double priDou=0;
        int psoInt=0;

        if (priStr != null && priStr.trim().length() != 0 ) {
            priDou = Double.parseDouble(priStr);  //价格
        }if (psoStr != null && psoStr.trim().length() != 0){   //既不是空指针也不为0
            psoInt= Integer.parseInt(psoStr);  //商店编号
        }

        try{
            Connection conn = connect();

            String sq1 = "UPDATE Product SET pname =?, price=?, pcomment=?,statement=?,ptype=?,pfunction=?, parts=?,Store_storeNo=?, photo=?,brand=?,size=? WHERE pianoNo = ?";
            PreparedStatement state1 = conn.prepareStatement(sq1,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
            state1.setString(1,pnaStr);
            state1.setDouble(2,priDou);
            state1.setString(3,pcoStr);
            state1.setString(4,pstStr);
            state1.setString(5,typStr);
            state1.setString(6,funStr);
            state1.setString(7,parStr);
            state1.setInt(8,psoInt);
            state1.setString(9,phoStr);
            state1.setString(10,pbrStr);
            state1.setString(11,psiStr);
            state1.setInt(12,pNoInt);
            state1.executeUpdate();   //执行更新操作



            int cm4 = Integer.parseInt(merchant);
            String sql2222 = "SELECT pianoNo, pname, price, pcomment,statement,ptype, pfunction,parts,Store_storeNo, photo,brand,size FROM product WHERE Store_storeNo=?";
            PreparedStatement pmdstmt = conn.prepareStatement(sql2222,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            pmdstmt.setInt(1,cm4);
            ResultSet pmdres = pmdstmt.executeQuery();
            pmTable.setModel(jp2setTable(pmdres,conn,pmTable));


        } catch (SQLException ome2) {
            ome2.printStackTrace();
        }
    }
    public JPanel pSearchGUI(){


        JLabel pnoLabel = new JLabel("Product No");
        JLabel pnaLabel = new JLabel("Product Name");
        JLabel priLabel= new JLabel("Price");
        JLabel pcoLabel= new JLabel("Comment");
        JLabel pstLabel= new JLabel("Statement");
        JLabel typLabel= new JLabel("Type");
        JLabel funLabel= new JLabel("Function");
        JLabel parLabel= new JLabel("Part");
        JLabel psoLabel= new JLabel("StoreNo");
        JLabel phoLabel= new JLabel("Photo");
        JLabel pbrLabel= new JLabel("Brand");
        JLabel psiLabel= new JLabel("Size");


        pnoText = new JTextField();
        pnaText = new JTextField();
        prlText = new JTextField("Minimum");  //最低价格
        prhText = new JTextField("Maximum");  //最高价格
        prlText.addMouseListener(new Mouse2());
        prhText.addMouseListener(new Mouse2());
        pcoText = new JTextField();
        pstText= new JTextField();
        psoText= new JTextField();
        phoText= new JTextField();
        pbrText= new JTextField();
        psiText= new JTextField();
        typCmb = new JComboBox<String>(typValue2);
        funCmb= new JComboBox<String>(funValue2);
        parCmb= new JComboBox<String>(parValue2);
        typCmb.setSelectedIndex(0);
        funCmb.setSelectedIndex(0);
        parCmb.setSelectedIndex(0);


        pnoText.setMaximumSize(new Dimension(500, pnoText.getMinimumSize().height));
        pnaText.setMaximumSize(new Dimension(500,pnaText.getMinimumSize().height));
        prlText.setMaximumSize(new Dimension(500,prlText.getMinimumSize().height));
        prhText.setMaximumSize(new Dimension(500,prhText.getMinimumSize().height));
        pcoText.setMaximumSize(new Dimension(500,pcoText.getMinimumSize().height));
        pstText.setMaximumSize(new Dimension(500,pstText.getMinimumSize().height));
        psoText.setMaximumSize(new Dimension(500,psoText.getMinimumSize().height));
        phoText.setMaximumSize(new Dimension(500,phoText.getMinimumSize().height));
        pbrText.setMaximumSize(new Dimension(500,pbrText.getMinimumSize().height));
        psiText.setMaximumSize(new Dimension(500,psiText.getMinimumSize().height));
        typCmb.setMaximumSize(new Dimension(Integer.MAX_VALUE,typCmb.getMinimumSize().height));//unit size
        funCmb.setMaximumSize(new Dimension(Integer.MAX_VALUE, funCmb.getMinimumSize().height));//unit size
        parCmb.setMaximumSize(new Dimension(Integer.MAX_VALUE, parCmb.getMinimumSize().height));//unit size


        JPanel  pnoPanel = new JPanel();
        JPanel  pnaPanel= new JPanel();
        JPanel  priPanel= new JPanel();
        JPanel  pcoPanel= new JPanel();
        JPanel  pstPanel= new JPanel();
        JPanel  typPanel= new JPanel();
        JPanel  funPanel= new JPanel();
        JPanel  parPanel= new JPanel();
        JPanel  psoPanel= new JPanel();
        JPanel  phoPanel= new JPanel();
        JPanel  pbrPanel= new JPanel();
        JPanel  psiPanel= new JPanel();

        pnoPanel.setLayout(new BoxLayout( pnoPanel, BoxLayout.X_AXIS));
        pnaPanel.setLayout(new BoxLayout(pnaPanel, BoxLayout.X_AXIS));
        priPanel.setLayout(new BoxLayout(priPanel, BoxLayout.X_AXIS));
        pcoPanel.setLayout(new BoxLayout(pcoPanel, BoxLayout.X_AXIS));
        pstPanel.setLayout(new BoxLayout(pstPanel, BoxLayout.X_AXIS));
        typPanel.setLayout(new BoxLayout(typPanel, BoxLayout.X_AXIS));
        funPanel.setLayout(new BoxLayout(funPanel, BoxLayout.X_AXIS));
        parPanel.setLayout(new BoxLayout(parPanel, BoxLayout.X_AXIS));
        psoPanel.setLayout(new BoxLayout(psoPanel, BoxLayout.X_AXIS));
        phoPanel.setLayout(new BoxLayout(phoPanel, BoxLayout.X_AXIS));
        pbrPanel.setLayout(new BoxLayout(pbrPanel, BoxLayout.X_AXIS));
        psiPanel.setLayout(new BoxLayout(psiPanel, BoxLayout.X_AXIS));

        pnoPanel.add(pnoLabel);
        pnaPanel.add( pnaLabel);
        priPanel.add(priLabel);
        pcoPanel.add(pcoLabel);
        pstPanel.add(pstLabel);
        typPanel.add(typLabel);
        funPanel.add(funLabel);
        parPanel.add(parLabel);
        psoPanel.add(psoLabel);
        phoPanel.add(phoLabel);
        pbrPanel.add(pbrLabel);
        psiPanel.add(psiLabel);
        pnaPanel.add(Box.createHorizontalStrut(5));
        pnoPanel.add(Box.createHorizontalStrut(5));
        priPanel.add(Box.createHorizontalStrut(5));
        pcoPanel.add(Box.createHorizontalStrut(5));
        pstPanel.add(Box.createHorizontalStrut(5));
        typPanel.add(Box.createHorizontalStrut(5));
        funPanel.add(Box.createHorizontalStrut(5));
        parPanel.add(Box.createHorizontalStrut(5));
        psoPanel.add(Box.createHorizontalStrut(5));
        phoPanel.add(Box.createHorizontalStrut(5));
        pbrPanel.add(Box.createHorizontalStrut(5));
        psiPanel.add(Box.createHorizontalStrut(5));
        pnaPanel.add( pnaText);
        pnoPanel.add(pnoText);
        priPanel.add(prlText);
        priPanel.add(prhText);
        pcoPanel.add(pcoText);
        pstPanel.add(pstText);
        typPanel.add(typCmb);
        funPanel.add(funCmb);
        parPanel.add(parCmb);
        psoPanel.add(psoText);
        phoPanel.add(phoText);
        pbrPanel.add(pbrText);
        psiPanel.add(psiText);


        JPanel pcontent = new JPanel();
        pcontent.setLayout(new GridLayout(6,2)); //component in center
        pcontent.add(pnoPanel);
        pcontent.add(pnaPanel);
        pcontent.add(priPanel);
        pcontent.add(pcoPanel);
        pcontent.add(pstPanel);
        pcontent.add(typPanel);
        pcontent.add(funPanel);
        pcontent.add(parPanel);
        pcontent.add(psoPanel);
        pcontent.add(phoPanel);
        pcontent.add(pbrPanel);
        pcontent.add(psiPanel);


        return pcontent;

    }


    public void pSearch(){
        int index1 = typCmb.getSelectedIndex();
        int index2 = funCmb.getSelectedIndex();
        int index3 = parCmb.getSelectedIndex();
        String typStr = typCmb.getItemAt(index1);   //获得类型
        String funStr = funCmb.getItemAt(index2);   //获得功能
        String parStr = parCmb.getItemAt(index3);   //获得零件


        String pnoStr = pnoText.getText();
        String pnaStr = pnaText.getText();
        String prlStr = prlText.getText();
        String prhStr = prhText.getText();
        String pcoStr = pcoText.getText();
        String pstStr = pstText.getText();
        String psoStr = psoText.getText();
        String phoStr = phoText.getText();
        String pbrStr = pbrText.getText();
        String psiStr = psiText.getText();


        int pnoInt=0,psoInt=0;
        double prlDou=0,prhDou=0;
        if ( judgeContainsStr(pnoStr)){
            JOptionPane.showMessageDialog(null, "Invalid input, please enter a number!", "Tips",
                    JOptionPane.ERROR_MESSAGE);

        }else if (pnoStr != null && pnoStr.trim().length() != 0 ){   //既不是空指针也不为0
            pnoInt= Integer.parseInt(pnoStr);  //产品编号
        }else{

        }
        if (prlStr != null && prlStr.trim().length() != 0 && (! prlStr.equals("Minimum"))) {
            prlDou = Double.parseDouble(prlStr);  //最低价
        }
        if (prhStr != null && prhStr.trim().length() != 0 && (! prhStr.equals("Maximum"))){
            prhDou = Double.parseDouble(prhStr);  //最高价
        }
        if (judgeContainsStr(psoStr)) {
            JOptionPane.showMessageDialog(null, "Invalid input, please enter a number!", "Tips",
                    JOptionPane.ERROR_MESSAGE);

        }else if(psoStr != null && psoStr.trim().length() != 0){
            psoInt = Integer.parseInt(psoStr.trim()); //订单编号
        }


        String[] sql ={"","","","","","","","","","","","",""};
        //sql[0] = " AND pname LIKE \"%\"?\"%\" ";
        sql[0] = " AND pianoNo = ? ";
        sql[1] = " AND pname LIKE \"%\"?\"%\" ";
        sql[2] = " AND price  > ? ";
        sql[3] = " AND price  < ?";
        sql[4] = " AND pcomment LIKE \"%\"?\"%\"";
        sql[5] = " AND statement LIKE \"%\"?\"%\" ";
        sql[6] = " AND ptype = ?";
        sql[7] = " AND pfunction = ? ";
        sql[8] = " AND parts =?";
        sql[9] = " AND Store_storeNo =?";
        sql[10] = " AND photo= ? ";
        sql[11] = " AND brand LIKE \"%\"?\"%\"";
        sql[12] = " AND size LIKE \"%\"?\"%\"";

        try{

            Connection pconn = connect();

            int om = Integer.parseInt(merchant);
            String psql = "SELECT pianoNo, pname, price, pcomment,statement,ptype, pfunction,parts,Store_storeNo, photo,brand,size " +
                    "FROM product " +
                    "WHERE Store_storeNo=?";

            //添加筛选条件
            int[] pos ={0,0,0,0,0,0,0,0,0,0,0,0,0};
            int pos2 =1;  //计算被选中的信息要插入的sql的位置
            if( pnoStr != null && pnoStr.trim().length() != 0){   //如果输入了产品名称
                psql = psql + sql[0];
                pos2++;
                pos[0]=pos2;   //pos[0]=2
            }
            if( pnaStr != null && pnaStr.trim().length() != 0){
                psql = psql + sql[1];
                pos2++;
                pos[1]=pos2;     //pos[1]=3
            }
            if( prlStr != null && prlStr.trim().length() != 0 && (! prlStr.equals("Minimum")) ){
                psql = psql + sql[2];
                pos2 ++ ;
                pos[2]=pos2;   //pos[2]=5
            }
            if(  prhStr != null && prhStr.trim().length() != 0 && (! prhStr.equals("Maximum"))){
                psql = psql + sql[3];    //最低价、最高价必须都有有效输入
                pos2 ++ ;
                pos[3]=pos2;
            }
            if(  pcoStr != null && pcoStr.trim().length() != 0){
                psql = psql + sql[4];     //产品颜色
                pos2++;
                pos[4]=pos2;
            }
            if( pstStr != null && pstStr.trim().length() != 0){     //产品功能
                psql = psql + sql[5];
                pos2++;
                pos[5]= pos2;
            }
            if( typStr != null && typStr.trim().length() != 0 && (! typStr.equals("All"))){    //产品零件
                psql = psql + sql[6];
                pos2++;
                pos[6]=pos2;
            }
            if( funStr != null && funStr.trim().length() != 0 && (! funStr.equals("All"))){   //顾客昵称
                psql = psql + sql[7];
                pos2++;
                pos[7]=pos2;
            }
            if(parStr!= null && parStr.trim().length() != 0 && (! parStr.equals("All"))){    //订单状态
                psql = psql + sql[8];
                pos2++;
                pos[8]=pos2;
            }
            if( psoStr != null && psoStr.trim().length() != 0){   //订单编号
                psql = psql + sql[9];
                pos2++;
                pos[9]=pos2;
            }
            if( phoStr != null &&  phoStr.trim().length() != 0  ){   //起止时间，两个都必须输入
                psql = psql + sql[10];   //开始日期
                pos2++;
                pos[10]=pos2;
            }
            if( pbrStr != null  && pbrStr.trim().length() != 0 ){   //起止时间，两个都必须输入
                psql = psql + sql[11];   //结束日期
                pos2++;
                pos[11]=pos2;
            }
            if ( psiStr != null && psiStr.trim().length() != 0){     //顾客电话
                psql = psql + sql[12];
                pos2++;
                pos[12]=pos2;
            }



            psql = psql + " ORDER BY  pianoNo ";
            PreparedStatement pstate = pconn.prepareStatement(psql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            pstate.setInt(1,om);
            for ( int j=0;j<13;j++){
                if (pos[j]!=0){
                    if (j==0){
                        pstate.setInt(pos[j],pnoInt);   //2
                    }
                    if(j==1){
                        pstate.setString(pos[j],pnaStr);  //3
                    }
                    if(j==2){
                        pstate.setDouble(pos[j],prlDou);  //4
                    }
                    if(j==3){
                        pstate.setDouble(pos[j],prhDou);   //5
                    }
                    if(j==4){
                        pstate.setString(pos[j],pcoStr);       //产品颜色
                    }
                    if(j==5){
                        pstate.setString(pos[j],pstStr);      //产品功能
                    }
                    if(j==6){
                        pstate.setString(pos[j],typStr);
                    }
                    if(j==7){
                        pstate.setString(pos[j],funStr);
                    }
                    if(j==8){
                        pstate.setString(pos[j],parStr);
                    }
                    if(j==9){
                        pstate.setInt(pos[j], psoInt );
                    }
                    if(j==10){
                        pstate.setString(pos[j],phoStr);
                    }
                    if(j==11){
                        pstate.setString(pos[j],pbrStr);
                    }
                    if(j==12){
                        pstate.setString(pos[j], psiStr  );
                    }

                }else{

                }
            }
            ResultSet prs = pstate.executeQuery();
            if (  prs.isBeforeFirst() ){
                pmTable.setModel(jp2setTable(prs,pconn,pmTable));
            }else if (! judgeContainsStr(pnoStr) && (! judgeContainsStr(psoStr))){
                JOptionPane.showMessageDialog(null, "Product not found!", "Tips",
                        JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e2) {
            e2.printStackTrace();
        }

    }
    public DefaultTableModel jp2setTable(ResultSet rs, Connection conn, JTable table) {
        DefaultTableModel Model = null;
        try {
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }
            //rs.last();

            String comm[][] = new String[count][12];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("pianoNo");
                comm[count][1] = rs.getString("pname");
                comm[count][2] = rs.getString("price");
                comm[count][3] = rs.getString("pcomment");
                comm[count][4] = rs.getString("statement");
                comm[count][5] = rs.getString("ptype");
                comm[count][6] = rs.getString("pfunction");
                comm[count][7] = rs.getString("parts");
                comm[count][8] = rs.getString("Store_storeNo");
                comm[count][9] = rs.getString("photo");
                comm[count][10] = rs.getString("brand");
                comm[count][11] = rs.getString("size");

                count++;
            }
            conn.close();

            String[] title = {"Product No", "Product Name", "Unit Price", "Comment", "Statement", "Type", "Function","Part", "Store No","Photo","Brand","Size"};
            //使表格不可编辑
            Model = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            return Model;
        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        return Model;

    }



    public JPanel jp3GUI(String s){

        oStatics = new JPanel();

        JLabel opelb = new JLabel ("Please select one operation and fill in the information");
        JLabel sNolb = new JLabel("Store No");
        JLabel startLabel = new JLabel("Start time");   //INFO scnner
        JLabel endLabel = new JLabel("End time");
        JLabel typeSelect = new JLabel("Type");
        JLabel funlb = new JLabel("Function");
        JLabel parlb = new JLabel("Parts");

        String[] opeValue = {"Total amount of orders in a certain period","Total amount of orders in a category","Top ten hot product in a certain period"};
        String[] year = new String[50];
        String[] mon = new String[12];
        String[] day = new String[31];
        int j = 0;
        for (int i = 2013; i <2013 + year.length; i++) {
            year[j] = String.valueOf(i);
            j++;
        }
        j = 0;
        for (int i = 1; i <= 12; i++) {
            mon[j] = String.valueOf(i);
            j++;
        }
        j = 0;
        for (int i = 1; i <= 31; i++) {
            day[j] = String.valueOf(i);
            j++;
        }

        operation = new JComboBox<String>(opeValue);
        ensure = new JButton("Process");
        ensure.addActionListener(new StatisticsBL());
        storeNo4 = new JTextField();
        storeNo4.setText(merchant);
        storeNo4.setEnabled(false);
        sTaY2 = new JComboBox<String>(year);
        eTaY2 = new JComboBox<String>(year);
        sTaM2 = new JComboBox<String>(mon);
        eTaM2 = new JComboBox<String>(mon);
        sTaD2 = new JComboBox<String>(day);
        eTaD2 = new JComboBox<String>(day);
        bigType = new JComboBox<String>(typValue2);
        funCmb4 = new JComboBox<String>(funValue2);
        parCmb4 = new JComboBox<String>(parValue2);
        bigType.addMouseListener(new Mouse());
        funCmb4.addMouseListener(new Mouse());
        parCmb4.addMouseListener(new Mouse());

        operation.setMaximumSize(new Dimension(Integer.MAX_VALUE, operation.getMinimumSize().height));//unit size
        storeNo4.setMaximumSize(new Dimension(500, storeNo4.getMinimumSize().height));
        sTaY2.setMaximumSize(new Dimension(Integer.MAX_VALUE, sTaY2.getMinimumSize().height));//unit size
        sTaM2.setMaximumSize(new Dimension(Integer.MAX_VALUE, sTaM2.getMinimumSize().height));
        sTaD2.setMaximumSize(new Dimension(Integer.MAX_VALUE, sTaD2.getMinimumSize().height));//unit size
        eTaY2.setMaximumSize(new Dimension(Integer.MAX_VALUE, eTaY2.getMinimumSize().height));//unit size
        eTaM2.setMaximumSize(new Dimension(Integer.MAX_VALUE, eTaM2.getMinimumSize().height));
        eTaD2.setMaximumSize(new Dimension(Integer.MAX_VALUE, eTaD2.getMinimumSize().height));//unit size
        bigType.setMaximumSize(new Dimension(Integer.MAX_VALUE,bigType.getMinimumSize().height));
        funCmb4.setMaximumSize(new Dimension(Integer.MAX_VALUE,funCmb4.getMinimumSize().height));
        parCmb4.setMaximumSize(new Dimension(Integer.MAX_VALUE,parCmb4.getMinimumSize().height));

        JPanel Statistics = new JPanel();
        JPanel sNopl = new JPanel();
        JPanel startPanel = new JPanel();
        JPanel endPanel = new JPanel();
        JPanel tsPanel = new JPanel();
        JPanel funpl = new JPanel();
        JPanel parpl = new JPanel();

        Statistics.setLayout(new BoxLayout(Statistics,BoxLayout.X_AXIS));
        sNopl.setLayout(new BoxLayout(sNopl,BoxLayout.X_AXIS));
        startPanel.setLayout(new BoxLayout(startPanel,BoxLayout.X_AXIS));
        endPanel.setLayout(new BoxLayout(endPanel,BoxLayout.X_AXIS));
        tsPanel.setLayout(new BoxLayout(tsPanel,BoxLayout.X_AXIS));
        funpl.setLayout(new BoxLayout(funpl,BoxLayout.X_AXIS));
        parpl.setLayout(new BoxLayout(parpl,BoxLayout.X_AXIS));



        Statistics.add(operation);
        sNopl.add(sNolb);
        startPanel.add(startLabel);
        endPanel.add(endLabel);
        tsPanel.add(typeSelect);
        funpl.add(funlb);
        parpl.add(parlb);
        Statistics.add(Box.createHorizontalStrut(5));
        sNopl.add(Box.createHorizontalStrut(5));
        startPanel.add(Box.createHorizontalStrut(5));
        endPanel.add(Box.createHorizontalStrut(5));
        tsPanel.add(Box.createHorizontalStrut(5));
        funpl.add(Box.createHorizontalStrut(5));
        parpl.add(Box.createHorizontalStrut(5));
        Statistics.add(ensure);
        sNopl.add(storeNo4);
        startPanel.add(sTaY2);
        startPanel.add(sTaM2);
        startPanel.add(sTaD2);
        endPanel.add(eTaY2);
        endPanel.add(eTaM2);
        endPanel.add(eTaD2);
        tsPanel.add(bigType);
        funpl.add(funCmb4);
        parpl.add(parCmb4);



        JPanel stServiec = new JPanel();
        JPanel select = new JPanel();
        JPanel Q = new JPanel();
        stServiec.setLayout(new BorderLayout());
        select.setLayout(new GridLayout(2,3));
        Q.setLayout(new BorderLayout());
        stServiec.add(opelb,BorderLayout.CENTER);
        stServiec.add(Statistics,BorderLayout.SOUTH);
        select.add(sNopl);
        select.add(startPanel);
        select.add(endPanel);
        select.add(tsPanel);
        select.add(funpl);
        select.add(parpl);
        Q.add(stServiec,BorderLayout.CENTER);
        Q.add(select,BorderLayout.SOUTH);

        try{

            Connection conn = connect();

            int om = Integer.parseInt(merchant);
            String sql = "SELECT p.pname, ohp.Num, p.price*ohp.Num AS tprice, p.ptype, ohp.color,p.pfunction,p.parts,c.cName, o.state, ohp.Orders_oNo, o.dateAndTime,o.oTeleNo,o.oAddress" +
                    " FROM orders o, Orders_has_Product ohp,Product p,Customer c " +
                    " WHERE p.pianoNo = ohp.Product_pianoNo AND c.cNo =o.Customer_cNo AND ohp.Orders_oNo = o.oNo AND p.Store_storeNo = ?";
            sql = sql +" ORDER BY o.oNo";
            PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            stmt.setInt(1,om);
            ResultSet res = stmt.executeQuery();


            sTable= new JTable(jp1setTable(res,conn,sTable));
            sTable.setPreferredScrollableViewportSize(new Dimension(800,200));

            stampt = new JScrollPane(sTable,
                    ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);


            oStatics.setLayout(new BorderLayout(5,10));
            oStatics.add(Q,BorderLayout.NORTH);
            oStatics.add(stampt,BorderLayout.CENTER);


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return oStatics;
    }

    public DefaultTableModel Statics1(ResultSet rs, Connection conn){
        try{
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][2];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("SUM");
                comm[count][1] = rs.getString("OderNo");
                count++;
            }
            conn.close();

            String[] title = {"SUM", "Quantity"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            String c = comm[0][1];
            if (  c.equals("0") ) {
                JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                        JOptionPane.ERROR_MESSAGE);
                tableModel.setRowCount( 0 );
            }
            return tableModel;

        }catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;
    }
    public DefaultTableModel Statics2(ResultSet rs, Connection conn,int[] flag){
        String typ = "p.ptype";
        String fun = "p.pfunction";
        String par = "p.parts";
        String typtl = "Type";
        String funtl = "Function";
        String partl = "Parts";
        String str = "";
        String stitle = "";
        if (flag[0] ==1){
            str =typ;
            stitle = typtl;
        }else if(flag[1] ==1){
            str = fun;
            stitle=funtl;
        }else if(flag[2]==1){
            str = par;
            stitle=partl;
        }

        try{
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][3];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString(str);
                comm[count][1] = rs.getString("SUM");
                comm[count][2] = rs.getString("OderNumber");

                count++;
            }
            conn.close();
            String[] title ;

            title = new String[]{stitle,"SUM", "Quantity"};
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            String c = comm[0][2];
            if (  c.equals("0") ) {
                JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                        JOptionPane.ERROR_MESSAGE);
                tableModel.setRowCount( 0 );
            }
            return tableModel;

        }catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;
    }
    public DefaultTableModel Statics3(ResultSet rs, Connection conn){
        try{
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }
            String comm[][] = new String[count][4];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("p.pianoNo");
                comm[count][1] = rs.getString("p.pname");
                comm[count][2] = rs.getString("totalNo");
                comm[count][3] = rs.getString("totalAmount");
                count++;
            }
            conn.close();

            String[] title = {"No","Name", "TotalNo","TotalAmount"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            return tableModel;

        }catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;
    }

    class StatisticsBL implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent ome){
            bigType.setEnabled(true);
            funCmb4.setEnabled(true);
            parCmb4.setEnabled(true);
            int index = operation.getSelectedIndex();
            if (index==0){

                int index1 = sTaY2.getSelectedIndex();
                int index2 = sTaM2.getSelectedIndex();
                int index3 = sTaD2.getSelectedIndex();
                int index4 = eTaY2.getSelectedIndex();
                int index5 = eTaM2.getSelectedIndex();
                int index6 = eTaD2.getSelectedIndex();
                String syStr2 = sTaY2.getItemAt(index1);   //获得状态
                String smStr2 = sTaM2.getItemAt(index2);
                String sdStr2 = sTaD2.getItemAt(index3);
                String eyStr2 = eTaY2.getItemAt(index4);
                String emStr2 = eTaM2.getItemAt(index5);
                String edStr2 = eTaD2.getItemAt(index6);
                String sTime=syStr2 + "-" + smStr2 + "-" + sdStr2;
                String eTime=eyStr2 + "-" + emStr2 + "-" + edStr2;

                try{

                    Connection conn = connect();

                    int om = Integer.parseInt(merchant);
                    String sql = "SELECT ROUND(SUM(ohp.num*p.price),2) AS SUM,COUNT(oNo) AS OderNo" +
                            " FROM Orders o, Orders_has_Product ohp,Product p" +
                            " WHERE p.pianoNo = ohp.Product_pianoNo AND ohp.Orders_oNo=o.oNo AND p.Store_storeNo = ?" +
                            " AND o.dateAndTime BETWEEN ? AND ?";
                    sql = sql +" ORDER BY o.oNo";
                    PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    stmt.setInt(1,om);
                    stmt.setString(2,sTime);
                    stmt.setString(3,eTime);
                    ResultSet res = stmt.executeQuery();

                    sTable.setModel(Statics1(res,conn));



                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }else if(index ==1){

                int index2 = bigType.getSelectedIndex();
                int index3 = funCmb4.getSelectedIndex();
                int index4 = parCmb4.getSelectedIndex();
                String type = bigType.getItemAt(index2);
                String fun = funCmb4.getItemAt(index3);
                String par = parCmb4.getItemAt(index4);
                int[] flag = {0,0,0};
                if (!type.equals("All")){
                    flag[0] =1;
                    flag[1] =0;
                    flag[2] =0;
                }else if (!fun.equals("All")){
                    flag[0] =0;
                    flag[1] =1;
                    flag[2] =0;
                }else if(!par.equals("All")){
                    flag[0] =0;
                    flag[1] =0;
                    flag[2] =1;
                }

                try{

                    Connection conn = connect();

                    int om = Integer.parseInt(merchant);
                    String sql = "SELECT p.ptype, ROUND(SUM(ohp.num*p.price),2) AS SUM, COUNT(o.oNo) AS OderNumber " +
                            " FROM Orders o, Product p, Orders_has_Product ohp" +
                            " Where p.pianoNo = ohp.Product_pianoNo AND ohp.Orders_oNo=o.oNo AND p.Store_storeNo= ? ";
                    sql = sql + " AND p.ptype = ?";

                    String sql2 = "SELECT p.pfunction, ROUND(SUM(ohp.num*p.price),2) AS SUM, COUNT(o.oNo) AS OderNumber " +
                            " FROM Orders o, Product p, Orders_has_Product ohp" +
                            " Where p.pianoNo = ohp.Product_pianoNo AND ohp.Orders_oNo=o.oNo AND p.Store_storeNo= ? ";
                    sql2 = sql2 + " AND p.pfunction= ?";

                    String sql3 = "SELECT p.parts, ROUND(SUM(ohp.num*p.price),2) AS SUM, COUNT(o.oNo) AS OderNumber " +
                            " FROM Orders o, Product p, Orders_has_Product ohp" +
                            " Where p.pianoNo = ohp.Product_pianoNo AND ohp.Orders_oNo=o.oNo AND p.Store_storeNo= ? ";
                    sql3 = sql3 + " AND p.parts= ?";

                    if (flag[0]==1){
                        PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                        stmt.setInt(1,om);
                        stmt.setString(2,type);
                        ResultSet res = stmt.executeQuery();
                        if (  res.isBeforeFirst() ){
                            sTable.setModel(Statics2(res,conn, flag));
                        }else {
                            JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                    }else if(flag[1]==1){
                        PreparedStatement stmt2 = conn.prepareStatement(sql2,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                        stmt2.setInt(1,om);
                        stmt2.setString(2,fun);
                        ResultSet res2 = stmt2.executeQuery();
                        if (  res2.isBeforeFirst() ){
                            sTable.setModel(Statics2(res2, conn, flag));
                        }else {
                            JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                    }else if(flag[2]==1){
                        PreparedStatement stmt3 = conn.prepareStatement(sql3,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                        stmt3.setInt(1,om);
                        stmt3.setString(2,par);
                        ResultSet res3 = stmt3.executeQuery();
                        if (  res3.isBeforeFirst() ){
                            sTable.setModel(Statics2(res3,conn, flag));
                        }else {
                            JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }else if (index ==2){

                int index1 = sTaY2.getSelectedIndex();
                int index2 = sTaM2.getSelectedIndex();
                int index3 = sTaD2.getSelectedIndex();
                int index4 = eTaY2.getSelectedIndex();
                int index5 = eTaM2.getSelectedIndex();
                int index6 = eTaD2.getSelectedIndex();
                String syStr2 = sTaY2.getItemAt(index1);   //获得状态
                String smStr2 = sTaM2.getItemAt(index2);
                String sdStr2 = sTaD2.getItemAt(index3);
                String eyStr2 = eTaY2.getItemAt(index4);
                String emStr2 = eTaM2.getItemAt(index5);
                String edStr2 = eTaD2.getItemAt(index6);
                String sTime=syStr2 + "-" + smStr2 + "-" + sdStr2;
                String eTime=eyStr2 + "-" + emStr2 + "-" + edStr2;
                int om = Integer.parseInt(merchant);
                String sql="SELECT p.pianoNo, p.pname, COUNT(o.oNO) AS totalNo, ROUND(SUM(ohp.num*p.price),2) AS totalAmount "+
                        " FROM Product p, Orders o, Orders_has_Product ohp"+
                        " WHERE p.pianoNo = ohp.Product_pianoNo AND ohp.Orders_oNo=o.oNo AND p.Store_storeNo= "+om+
                        " AND o.dateAndTime BETWEEN '"+sTime+"' AND '" +eTime+
                        "' GROUP BY p.pianoNo " +
                        " ORDER BY COUNT(o.oNO) DESC, ROUND(SUM(ohp.num*p.price),2) DESC  LIMIT 10 ";
                System.out.println(sql);
                try{
                    Connection conn = connect();
                    PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    ResultSet res = stmt.executeQuery();

                    if (  res.isBeforeFirst() ){
                        sTable.setModel(Statics3(res,conn));
                    }else {
                        JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                JOptionPane.ERROR_MESSAGE);
                    }
                    new TopStore("Order Statics of the Top10 Product ",sql,"p.pianoNo","totalNo");
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }else{
                JFrame errorFrame = new JFrame();
                errorFrame.setLayout(null);
                errorFrame.setSize(350,150);
                errorFrame.setLocation(650,400);

                JLabel label3 = new JLabel("Please select the content you want to query");
                label3.setSize(350,30);
                label3.setLocation(50,20);
                errorFrame.add(label3);

                JButton button = new JButton("OK");
                button.setSize(60,30);
                button.setLocation(140,60);

                button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        errorFrame.dispose();
                    }
                });
                errorFrame.add(button);
                errorFrame.setVisible(true);
            }
        }
    }
    class Mouse implements MouseListener{
        public void mouseEntered(MouseEvent e){

        }
        public void mouseExited(MouseEvent e){

        }
        public void mouseClicked(MouseEvent e){ }
        public void mousePressed(MouseEvent e){

            //点击其中一个其它两个为“All"（e.g.点击type,fun & par为“All")
            if(e.getSource()==bigType){

                funCmb4.setSelectedIndex(0);
                parCmb4.setSelectedIndex(0);
            }else if (e.getSource() == funCmb4){

                bigType.setSelectedIndex(0);
                parCmb4.setSelectedIndex(0);
            } else {

                bigType.setSelectedIndex(0);
                funCmb4.setSelectedIndex(0);
            }


        }
        public void mouseDragged(MouseEvent e){}
        public void mouseReleased(MouseEvent e){

        }

    }
    class Mouse2 implements MouseListener{
        public void mouseEntered(MouseEvent e){

        }
        public void mouseExited(MouseEvent e){
            String l = prlText.getText();
            String h = prhText.getText();
            if (l == null || l.trim().length()==0){
                prlText.setText("Minimum");
            }
            if (h == null || h.trim().length()==0){
                prhText.setText("Maximum");
            }

        }
        public void mouseClicked(MouseEvent e){ }
        public void mousePressed(MouseEvent e){

            //点击其中一个其它两个为“All"（e.g.点击type,fun & par为“All")
            if(e.getSource()==prlText){
                prlText.setText("");
            }else if(e.getSource()==prhText){
                prhText.setText("");
            }


        }
        public void mouseDragged(MouseEvent e){}
        public void mouseReleased(MouseEvent e){

        }

    }
}
