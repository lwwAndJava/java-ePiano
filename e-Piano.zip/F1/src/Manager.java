import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Manager extends JFrame {
    DefaultTableModel tableModel, tableModel1, tableModel2, tableModel3, tableModel5;
    JTabbedPane jtp;
    JButton process, process1, process2, process3, umy, umcan, uay, uacan, say, sacan, smy, smcan, qmy, usy, ssy;
    JButton pmy, pmcan, pay, pacan, prmy, prmcan, show;
    JPanel jp1, jp2, jp3, jp4, content1,jp5;
    JTable table1, table2, table3, table4, table5;
    JScrollPane s, sc1, sc2, sc3, sc5;
    JFrame um, ua, sa, sm, pa, pm, prm, qm, uS, ss;
    JRadioButton ucn, scn, qu1, qu2, qu3, qu4, qu5, qu6, qu7, startPur, endPur, sUser, eUser, uSex;
    JRadioButton cS1, cS2, cS3, cS4;
    JComboBox<String> DaY, DaM, DaD, TaY, TaM, TaD, TaH, TaI, TaS, SEX, stateBox, oStateCmb2, ofunCmb, opartCmb;
    JComboBox<String> EaY, EaM, EaD, EaH, EaI, EaS, ptype1, pfunction1, parts1, ptype, qtype, qfunc, qparts, stat;
    JComboBox<String> BaY, BaM, BaD, colorM, colorP, colorO;
    JTextField opnText3, opqText3, opfText3, oppText3, ua1, ua2, ua3, ua4, ua5;
    JTextField opnText, opqText, oplText, ophText, opcText, ocnText, onoText, oteText, oadText, sNoText, sNameText;
    JTextField us1, us2, us3, us4, ss1, ss2, ss3, ss4;
    JTextField pa1, pa2, pa3, pa4, pa5, pa6, pa7, pa8, pa9, sname;
    JTextField pr1, pr2, pr3, pr4, pr5, pr6, pr7, pr8, pr9, pr10, pr11;

    String omValue, sValue;
    //type,color,function,parts的值
    String[] typValue,colValue,funValue,parValue ; //无All
    String[] typValue2,colValue2,funValue2,parValue2 ;  //有All
    Category c2;
    JRadioButton cadd,cmod,csee,call;   //添加、修改、查找、展示所有
    ButtonGroup cbg;
    JButton cButton;       //确认
    DefaultTableModel cModel;
    JTable cTable;

    //cAddGUI上的组件
    JTextField typText1,colText1,funText1,parText1;   //   商品管理 修改版面上的组件

    //cModifyGUI上的组件
    JTextField cnoText2,cnaText2,typText2,colText2,funText2,parText2;   //   商品管理 修改版面上的组件
    JComboBox<String> typCb2,colCb2,funCb2, parCb2;  //无All

    //cSeekGUI上的组件

    JComboBox<String> typCb3,colCb3,funCb3, parCb3;   //有All

    //添加、修改、查找弹出框的JFrame
    JFrame ca,cm,cs;

    //添加、修改、查找弹出框的确认与取消按钮
    JButton cayes,cmyes,csyes,cacan,cmcan,cscan;

    //type,color,function,parts的值
    ArrayList<String> typList, colList,funList,parList;      //无All
    ArrayList<String> typList2, colList2,funList2,parList2;  //有All


    public Manager() {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            System.out.println("class not found");
        } catch (InstantiationException ex) {
            System.out.println("Instantiation exception");
        } catch (IllegalAccessException ex) {
            System.out.println("IllegalAccess Exceptio");
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            System.out.println("UnsupportedLookAndFeel Exception");
        }


        setLayout();
    }

    public void setLayout() {
        //设置选项卡
        jtp = new JTabbedPane();
        jp1 = new JPanel();
        jp1.setLayout(new BorderLayout());
        jp2 = new JPanel();
        jp2.setLayout(new BorderLayout());
        jp3 = new JPanel();
        jp3.setLayout(new BorderLayout());
        jp4 = new JPanel();
        jp4.setLayout(new BorderLayout());
        jp5 = cGUI();
        jtp.add("Produce Manage", jp1);
        jtp.add("Customer Manage", jp2);
        jtp.add("Store Manage", jp3);
        jtp.add("Purchase Manage", jp4);
        jtp.add("Category Manage", jp5);
        this.add(jtp);

//设置整体面板
        this.setTitle("Manager");
        this.setBounds(200, 400, 1300, 340);
        this.setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setProduct();
        setUser();
        setStore();
        setPurchase();
        setCategory();
    }
    public void setCategory(){
        Initialize();
    }
    public JPanel defineDate() {
        String[] year = new String[50];
        int j = 0;
        for (int i = 1970; i < 2020; i++) {
            year[j] = String.valueOf(i);
            j++;
        }
        DaY = new JComboBox<>(year);

        String[] mon = new String[12];
        j = 0;
        for (int i = 1; i <= 12; i++) {
            mon[j] = String.valueOf(i);
            j++;
        }
        DaM = new JComboBox<>(mon);

        String[] day = new String[31];
        j = 0;
        for (int i = 1; i <= 31; i++) {
            day[j] = String.valueOf(i);
            j++;
        }
        DaD = new JComboBox<>(day);

        String[] hour = new String[24];
        j = 0;
        for (int i = 0; i < 24; i++) {
            hour[j] = String.valueOf(i);
            j++;
        }
        DaY.setMaximumSize(new Dimension(Integer.MAX_VALUE, DaY.getMinimumSize().height));//unit size
        DaM.setMaximumSize(new Dimension(Integer.MAX_VALUE, DaM.getMinimumSize().height));
        DaD.setMaximumSize(new Dimension(Integer.MAX_VALUE, DaD.getMinimumSize().height));//unit size
        JPanel dPanel = new JPanel(new GridLayout(1, 0));
        dPanel.add(DaY);
        dPanel.add(DaM);
        dPanel.add(DaD);
        return dPanel;
    }


    public JPanel defineEndDate() {
        String[] year = new String[50];
        int j = 0;
        for (int i = 1970; i < 2020; i++) {
            year[j] = String.valueOf(i);
            j++;
        }
        BaY = new JComboBox<>(year);

        String[] mon = new String[12];
        j = 0;
        for (int i = 1; i <= 12; i++) {
            mon[j] = String.valueOf(i);
            j++;
        }
        BaM = new JComboBox<>(mon);

        String[] day = new String[31];
        j = 0;
        for (int i = 1; i <= 31; i++) {
            day[j] = String.valueOf(i);
            j++;
        }
        BaD = new JComboBox<>(day);

        String[] hour = new String[24];
        j = 0;
        for (int i = 0; i < 24; i++) {
            hour[j] = String.valueOf(i);
            j++;
        }
        BaY.setMaximumSize(new Dimension(Integer.MAX_VALUE, BaY.getMinimumSize().height));//unit size
        BaM.setMaximumSize(new Dimension(Integer.MAX_VALUE, BaM.getMinimumSize().height));
        BaD.setMaximumSize(new Dimension(Integer.MAX_VALUE, BaD.getMinimumSize().height));//unit size
        JPanel dPanel = new JPanel(new GridLayout(1, 0));
        dPanel.add(BaY);
        dPanel.add(BaM);
        dPanel.add(BaD);
        return dPanel;
    }


    public JPanel defineTime() {
        String[] year = new String[50];
        int j = 0;
        for (int i = 2013; i < 2013+year.length; i++) {
            year[j] = String.valueOf(i);
            j++;
        }
        TaY = new JComboBox<>(year);

        String[] mon = new String[12];
        j = 0;
        for (int i = 1; i <= 12; i++) {
            mon[j] = String.valueOf(i);
            j++;
        }
        TaM = new JComboBox<>(mon);

        String[] day = new String[31];
        j = 0;
        for (int i = 1; i <= 31; i++) {
            day[j] = String.valueOf(i);
            j++;
        }
        TaD = new JComboBox<>(day);

        String[] hour = new String[24];
        j = 0;
        for (int i = 0; i < 24; i++) {
            hour[j] = String.valueOf(i);
            j++;
        }
        TaH = new JComboBox<>(hour);

        String[] minute = new String[60];
        j = 0;
        for (int i = 0; i < 60; i++) {
            minute[j] = String.valueOf(i);
            j++;
        }
        TaI = new JComboBox<>(minute);

        String[] second = new String[60];
        j = 0;
        for (int i = 0; i < 60; i++) {
            second[j] = String.valueOf(i);
            j++;
        }
        TaS = new JComboBox<>(second);
        //Dimension dim2 = new Dimension(5, 20);
        //TaY.setPreferredSize(dim2);
        TaY.setMaximumSize(new Dimension(Integer.MAX_VALUE, TaY.getMinimumSize().height));//unit size
        TaM.setMaximumSize(new Dimension(Integer.MAX_VALUE, TaM.getMinimumSize().height));
        TaD.setMaximumSize(new Dimension(Integer.MAX_VALUE, TaD.getMinimumSize().height));//unit size
        TaH.setMaximumSize(new Dimension(Integer.MAX_VALUE, TaH.getMinimumSize().height));//unit size
        TaI.setMaximumSize(new Dimension(Integer.MAX_VALUE, TaI.getMinimumSize().height));
        TaS.setMaximumSize(new Dimension(Integer.MAX_VALUE, TaS.getMinimumSize().height));//unit size


        JPanel tPanel = new JPanel(new GridLayout(1, 0));

        tPanel.add(TaY);
        tPanel.add(TaM);
        tPanel.add(TaD);
        tPanel.add(TaH);
        tPanel.add(TaI);
        tPanel.add(TaS);
        return tPanel;
    }

    public JPanel defineEndTime() {
        String[] year = new String[50];
        int j = 0;
        for (int i = 2013; i < 2013+year.length; i++) {
            year[j] = String.valueOf(i);
            j++;
        }
        EaY = new JComboBox<>(year);

        String[] mon = new String[12];
        j = 0;
        for (int i = 1; i <= 12; i++) {
            mon[j] = String.valueOf(i);
            j++;
        }
        EaM = new JComboBox<>(mon);

        String[] day = new String[31];
        j = 0;
        for (int i = 1; i <= 31; i++) {
            day[j] = String.valueOf(i);
            j++;
        }
        EaD = new JComboBox<>(day);

        String[] hour = new String[24];
        j = 0;
        for (int i = 0; i < 24; i++) {
            hour[j] = String.valueOf(i);
            j++;
        }
        EaH = new JComboBox<>(hour);

        String[] minute = new String[60];
        j = 0;
        for (int i = 0; i < 60; i++) {
            minute[j] = String.valueOf(i);
            j++;
        }
        EaI = new JComboBox<>(minute);

        String[] second = new String[60];
        j = 0;
        for (int i = 0; i < 60; i++) {
            second[j] = String.valueOf(i);
            j++;
        }
        EaS = new JComboBox<>(second);

        EaY.setMaximumSize(new Dimension(Integer.MAX_VALUE, EaY.getMinimumSize().height));//unit size
        EaM.setMaximumSize(new Dimension(Integer.MAX_VALUE, EaM.getMinimumSize().height));
        EaD.setMaximumSize(new Dimension(Integer.MAX_VALUE, EaD.getMinimumSize().height));//unit size
        EaH.setMaximumSize(new Dimension(Integer.MAX_VALUE, EaH.getMinimumSize().height));//unit size
        EaI.setMaximumSize(new Dimension(Integer.MAX_VALUE, EaI.getMinimumSize().height));
        EaS.setMaximumSize(new Dimension(Integer.MAX_VALUE, EaS.getMinimumSize().height));//unit size


        JPanel tPanel = new JPanel(new GridLayout(1, 0));

        tPanel.add(EaY);
        tPanel.add(EaM);
        tPanel.add(EaD);
        tPanel.add(EaH);
        tPanel.add(EaI);
        tPanel.add(EaS);
        return tPanel;
    }

    public JPanel defineSex() {
        String[] sex = {"M", "F"};
        SEX = new JComboBox<>(sex);
        Dimension di=new Dimension(15,15);
        SEX.setPreferredSize(di);
        JPanel sexPanel = new JPanel(new GridLayout(1, 0));
        sexPanel.add(SEX);
        return sexPanel;
    }


    public void setProduct() {
        JScrollPane s = new JScrollPane();

//设置产品管理选项卡

//右边商品信息展示栏目
        String st = "SELECT p.pianoNo, p.pname AS name, p.price, p.pcomment AS comment, p.statement, p.ptype AS type, "
                +"p.pfunction , p.parts, p.Store_storeNo AS storeNo, p.brand, p.size, n.color, SUM(n.productNum) AS productNum "
                +"FROM Product p, productNo n WHERE p.pianoNo=n.Product_pianoNo GROUP BY n.color, p.pianoNo";
        System.out.println(st);

//左边信息编辑框
        process = new JButton("Search");
        Dimension dim2 = new Dimension(150, 30);
        process.setPreferredSize(dim2);
        show = new JButton("Show all product");
        show.setPreferredSize(dim2);
        JLabel note = new JLabel("Process to select");

        JPanel fin = new JPanel();
        fin.setLayout(new GridLayout(0,1));
        fin.add(note);

        JPanel tam1=new JPanel();
        tam1.add(process);
        JPanel tam2=new JPanel();
        tam2.add(show);

        fin.add(tam1);
        fin.add(tam2);
        fin.setPreferredSize(new Dimension(200, 0));
        JPanel orderLeft=new JPanel();
        orderLeft.setLayout(new BorderLayout());
        orderLeft.add(fin,BorderLayout.CENTER);
        Vector rowData = test.getRows(st, st);
        // 取得haha数据库的aa表的表头数据
        Vector columnNames = test.getHead(st, st);
        tableModel1 = new DefaultTableModel(rowData, columnNames){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table1 = new JTable(tableModel1);
        sc1 = new JScrollPane(table1);
        sc1.setPreferredSize(new Dimension(1000, 0));
        jp1.add(BorderLayout.WEST, orderLeft);
        jp1.add(BorderLayout.EAST, sc1);
        process.addActionListener(new prButtonListener());
        show.addActionListener(new showListener());
    }

    class showListener implements ActionListener{
        public void actionPerformed(ActionEvent o){
            if(o.getSource() == show) {
                String osq1 = "SELECT p.pianoNo, p.pname AS name, p.price, p.pcomment AS comment, p.statement, p.ptype AS type, "
                        +"p.pfunction , p.parts, p.Store_storeNo AS storeNo, p.brand, p.size, n.color, SUM(n.productNum) AS productNum "
                        +"FROM Product p, productNo n WHERE p.pianoNo=n.Product_pianoNo GROUP BY n.color, p.pianoNo";
                jp1.remove(sc1);
                Vector rowData1 = test.getRows(osq1, osq1);
                // 取得haha数据库的aa表的表头数据
                Vector columnNames1 = test.getHead(osq1, osq1);
                tableModel1 = new DefaultTableModel(rowData1, columnNames1){
                    public boolean isCellEditable(int row, int column) {
                        return false;
                    }
                };
                table1 = new JTable(tableModel1);
                sc1 = new JScrollPane(table1);
                sc1.setPreferredSize(new Dimension(1000, 0));
                jp1.add(BorderLayout.EAST, sc1);
            }
        }
    }
    class prButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent ome){
            prm = new JFrame("Purchase Search");

            prmy = new JButton("Yes");
            prmcan = new JButton("Cancel");
            prmy.addActionListener(new prSButtonListener());
            prmcan.addActionListener(new prSButtonListener());
            JPanel pyes = new JPanel();
            JPanel pcan = new JPanel();
            JPanel bio = new JPanel();
            pyes.add(prmy);
            pcan.add(prmcan);
            bio.setLayout(new GridLayout(1,2));
            bio.add(pyes);
            bio.add(pcan);


            JPanel content = new JPanel();
            content.setLayout(new BoxLayout(content,BoxLayout.Y_AXIS));
            content.add(pSearchGUI());
            content.add(bio);

            JLabel space0 = new JLabel("                    ");
            JLabel space1 = new JLabel("                    ");
            prm.setLayout(new BorderLayout(5,10));
            prm.add(space0,BorderLayout.WEST);
            prm.add(content,BorderLayout.CENTER);
            prm.add(space1,BorderLayout.EAST);

            prm.setSize(800,400);
            prm.setLocation(300,200);
            prm.setVisible(true);
            prm.setResizable(false);

        }
    }
    class prSButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent ome){
            if ( ome.getSource() == prmy){    //modify the state of the item
                pSearch();
                prm.dispose();
            }else{
                prm.dispose();
            }

        }
    }

    public void pSearch() {

        int index2 = pfunction1.getSelectedIndex();
        int index3 = parts1.getSelectedIndex();
        int index1 = ptype1.getSelectedIndex();
        int index4 = colorM.getSelectedIndex();
        String ofuStr = pfunction1.getItemAt(index2);   //获得功能
        String opaStr = parts1.getItemAt(index3);   //获得零件
        String stateStr = ptype1.getItemAt(index1); //获得种类
        String col=colorM.getItemAt(index4);


        String opnStr = pr1.getText();//产品号
        String opqStr = pr2.getText();// 产品名字
        String oplStr = pr3.getText();//最小价格
        String ophStr = pr4.getText();//最大价格
        String opcStr = pr5.getText();//评价
        String ocnStr = pr6.getText();//描述
        String onoStr = pr7.getText();//商家号
        String oteStr = pr8.getText();//品牌
        String oadStr = pr9.getText();//大小



        String[] sql = {"", "", "", "", "", "", "", "", "", "", "", "","",""};
        sql[0] = " AND p.pianoNo = \'" + opnStr + "\' ";
        sql[1] = " AND p.pname LIKE \'%" + opqStr + "%\'";
        sql[2] = " AND p.price > \'" + oplStr + "\'";
        sql[3] = " AND p.price < \'" + ophStr + "\'";
        sql[4] = " AND p.pcomment LIKE \'%" + opcStr + "%\'";
        sql[5] = " AND p.pfunction= \'" + ofuStr + "\'";
        sql[6] = " AND p.parts = \'" + opaStr + "\'";
        sql[7] = " AND p.statement LIKE \'%" + ocnStr + "%\' ";
        sql[8] = " AND p.ptype = \'" + stateStr + "\'";
        sql[9] = " AND p.Store_storeNo = \'" + onoStr + "\'";
        sql[10] = " AND p.brand LIKE \'%" + oteStr + "%\'";
        sql[11] = " AND p.size LIKE \'%" + oadStr + "%\' ";
        sql[12] =" AND n.color = \'" + col+ "\' ";


        String osq1 = "SELECT p.pianoNo, p.pname AS name, ROUND(p.price,2), p.pcomment AS comment, p.statement, p.ptype AS type, "
                +"p.pfunction , p.parts, p.Store_storeNo AS storeNo, p.brand, p.size, n.color, SUM(n.productNum) AS productNum "
                +"FROM Product p, productNo n WHERE p.pianoNo=n.Product_pianoNo ";

        //添加筛选条件
        if (opnStr != null && opnStr.trim().length() != 0) {   //输入了产品号
            osq1 = osq1 + sql[0];
        }
        if (opqStr != null && opqStr.trim().length() != 0) {  //产品名
            osq1 = osq1 + sql[1];
        }
        if (oplStr != null && oplStr.trim().length() != 0 && (!oplStr.equals("Minimum"))) { //最小价格
            osq1 = osq1 + sql[2];
        }
        if (ophStr != null && ophStr.trim().length() != 0 && (!ophStr.equals("Maximum"))) { //最大价格
            osq1 = osq1 + sql[3];    //最低价、最高价必须都有有效输入
        }
        if (opcStr != null && opcStr.trim().length() != 0) {
            osq1 = osq1 + sql[4];     //产品评价
        }
        if (ofuStr != null && ofuStr.trim().length() != 0 && (!ofuStr.equals("All"))) {     //产品功能
            osq1 = osq1 + sql[5];
        }
        if (opaStr != null && opaStr.trim().length() != 0 && (!opaStr.equals("All"))) {    //产品零件
            osq1 = osq1 + sql[6];
        }
        if (ocnStr != null && ocnStr.trim().length() != 0) {   //描述
            osq1 = osq1 + sql[7];
        }
        if (stateStr != null && stateStr.trim().length() != 0 && (!stateStr.equals("All"))) {    //产品种类
            osq1 = osq1 + sql[8];
        }
        if (onoStr != null && onoStr.trim().length() != 0) {   //商家号
            osq1 = osq1 + sql[9];
        }
        if (oteStr != null && oteStr.trim().length() != 0) {     //品牌
            osq1 = osq1 + sql[10];
        }
        if (oadStr != null && oadStr.trim().length() != 0) {   //大小
            osq1 = osq1 + sql[11];
        }
        if (col != null && col.trim().length() != 0&& (!col.equals("All"))) {   //大小
            osq1 = osq1 + sql[12];
        }
        osq1=osq1+" GROUP BY n.color, p.pianoNo";
        System.out.println(osq1);
        jp1.remove(sc1);
        Vector rowData1 = test.getRows(osq1, osq1);
        // 取得haha数据库的aa表的表头数据
        Vector columnNames1 = test.getHead(osq1, osq1);
        tableModel1 = new DefaultTableModel(rowData1, columnNames1){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table1 = new JTable(tableModel1);
        sc1 = new JScrollPane(table1);
        sc1.setPreferredSize(new Dimension(1000, 0));
        jp1.add(BorderLayout.EAST, sc1);

    }

    public JPanel pSearchGUI() {

        JPanel oINFO = new JPanel();
        JLabel not = new JLabel("Please select 1 or more condition");
        JLabel opn = new JLabel("Product No");
        JLabel opq = new JLabel("Product Name");
        JLabel opr = new JLabel("Price");
        JLabel opc = new JLabel("Comment");
        JLabel opf = new JLabel("Function");
        JLabel opp = new JLabel("Part");
        JLabel ocn = new JLabel("Statement");
        JLabel ostate = new JLabel("Type");
        JLabel ono = new JLabel("Store No");
        JLabel ote = new JLabel("Brand");
        JLabel oad = new JLabel("size");
        JLabel col=new JLabel("color");


        pr1 = new JTextField();  //产品号
        pr2 = new JTextField();  //产品名字
        pr3 = new JTextField("Minimum");  //最小价格

        pr4 = new JTextField("Maximum");  //最大价格
        pr5 = new JTextField();  //评价
        ptype1 = new JComboBox<String>(typValue2);   //种类
        pfunction1 = new JComboBox<String>(funValue2);       //产品功能
        parts1 = new JComboBox<String>(parValue2);     //产品零件
        pr6 = new JTextField();  //描述
        pr7 = new JTextField();//商家号
        pr8 = new JTextField();//品牌
        pr9 = new JTextField();//大小

        colorM=new JComboBox<>(colValue2);


        pr1.setMaximumSize(new Dimension(500, pr1.getMinimumSize().height));
        pr2.setMaximumSize(new Dimension(500, pr2.getMinimumSize().height));
        pr3.setMaximumSize(new Dimension(500, pr3.getMinimumSize().height));
        pr4.setMaximumSize(new Dimension(500, pr4.getMinimumSize().height));
        pr5.setMaximumSize(new Dimension(500, pr5.getMinimumSize().height));
        pr6.setMaximumSize(new Dimension(500, pr6.getMinimumSize().height));
        pr7.setMaximumSize(new Dimension(500, pr7.getMinimumSize().height));
        pr8.setMaximumSize(new Dimension(500, pr8.getMinimumSize().height));
        pr9.setMaximumSize(new Dimension(500, pr9.getMinimumSize().height));
        colorM.setMaximumSize(new Dimension(Integer.MAX_VALUE, colorM.getMinimumSize().height));
        pfunction1.setMaximumSize(new Dimension(Integer.MAX_VALUE, pfunction1.getMinimumSize().height));//unit size
        ptype1.setMaximumSize(new Dimension(Integer.MAX_VALUE, ptype1.getMinimumSize().height));
        parts1.setMaximumSize(new Dimension(Integer.MAX_VALUE, parts1.getMinimumSize().height));//unit size


        JPanel opnPanel = new JPanel();    //添加复选框和文本框
        JPanel opqPanel = new JPanel();
        JPanel oprPanel = new JPanel();
        JPanel opcPanel = new JPanel();
        JPanel opfPanel = new JPanel();
        JPanel oppPanel = new JPanel();
        JPanel ocnPanel = new JPanel();
        JPanel onoPanel = new JPanel();
        JPanel ostatePanel = new JPanel();
        JPanel otePanel = new JPanel();
        JPanel oadPanel = new JPanel();
        JPanel colPan=new JPanel();


        opnPanel.setLayout(new BoxLayout(opnPanel, BoxLayout.X_AXIS));
        opqPanel.setLayout(new BoxLayout(opqPanel, BoxLayout.X_AXIS));
        oprPanel.setLayout(new BoxLayout(oprPanel, BoxLayout.X_AXIS));
        opcPanel.setLayout(new BoxLayout(opcPanel, BoxLayout.X_AXIS));
        opfPanel.setLayout(new BoxLayout(opfPanel, BoxLayout.X_AXIS));
        oppPanel.setLayout(new BoxLayout(oppPanel, BoxLayout.X_AXIS));
        ocnPanel.setLayout(new BoxLayout(ocnPanel, BoxLayout.X_AXIS));
        onoPanel.setLayout(new BoxLayout(onoPanel, BoxLayout.X_AXIS));
        otePanel.setLayout(new BoxLayout(otePanel, BoxLayout.X_AXIS));
        oadPanel.setLayout(new BoxLayout(oadPanel, BoxLayout.X_AXIS));
        ostatePanel.setLayout(new BoxLayout(ostatePanel, BoxLayout.X_AXIS));
        colPan.setLayout(new BoxLayout(colPan, BoxLayout.X_AXIS));


        opnPanel.add(opn);
        opqPanel.add(opq);
        oprPanel.add(opr);
        opcPanel.add(opc);
        opfPanel.add(opf);
        oppPanel.add(opp);
        ocnPanel.add(ocn);
        ostatePanel.add(ostate);
        onoPanel.add(ono);
        otePanel.add(ote);
        oadPanel.add(oad);
        colPan.add(col);

        opnPanel.add(Box.createHorizontalStrut(5));
        opqPanel.add(Box.createHorizontalStrut(5));
        oprPanel.add(Box.createHorizontalStrut(5));
        opcPanel.add(Box.createHorizontalStrut(5));
        opfPanel.add(Box.createHorizontalStrut(5));
        oppPanel.add(Box.createHorizontalStrut(5));
        ocnPanel.add(Box.createHorizontalStrut(5));
        ostatePanel.add(Box.createHorizontalStrut(5));
        onoPanel.add(Box.createHorizontalStrut(5));
        otePanel.add(Box.createHorizontalStrut(5));
        oadPanel.add(Box.createHorizontalStrut(5));
        colPan.add(Box.createHorizontalStrut(5));

        opnPanel.add(pr1);
        opqPanel.add(pr2);
        oprPanel.add(pr3);
        oprPanel.add(pr4);
        opcPanel.add(pr5);
        opfPanel.add(pfunction1);
        oppPanel.add(parts1);
        ocnPanel.add(pr6);
        ostatePanel.add(ptype1);
        onoPanel.add(pr7);
        otePanel.add(pr8);
        oadPanel.add(pr9);
        colPan.add(colorM);


        oINFO.setLayout(new GridLayout(0, 2));
        oINFO.add(opnPanel);
        oINFO.add(opqPanel);
        oINFO.add(oprPanel);
        oINFO.add(opcPanel);
        oINFO.add(opfPanel);
        oINFO.add(oppPanel);
        oINFO.add(ocnPanel);
        oINFO.add(ostatePanel);
        oINFO.add(onoPanel);
        oINFO.add(otePanel);
        oINFO.add(oadPanel);
        oINFO.add(colPan);

        JPanel info = new JPanel();
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.add(not);
        info.add(oINFO);

        return info;
    }

    public void setUser() {
        String s1, s2, s3, s4, s5;
        JLabel jls1;
        JPanel np1;
        JRadioButton jb1, jb2, jb3, jb4, jb5;
        ButtonGroup option;


        process1 = new JButton("process");
        Dimension dim2 = new Dimension(80, 20);
        process1.setPreferredSize(dim2);

        s1 = "delete customer";
        s2 = "add customer";
        s3 = "reset customer's information";
        s4 = "seek customer";
        s5 = "show all user";
        jb1 = new JRadioButton(s1);
        jb2 = new JRadioButton(s2);
        jb3 = new JRadioButton(s3);
        jb4 = new JRadioButton(s4);
        jb5 = new JRadioButton(s5);
        jls1 = new JLabel("please select the operation");
        option = new ButtonGroup();
        option.add(jb1);
        option.add(jb2);
        option.add(jb3);
        option.add(jb4);
        option.add(jb5);
//右边用户信息展示栏目
        np1 = new JPanel();
        np1.setLayout(new GridLayout(0, 1));
        np1.add(jls1);
        np1.add(jb1);
        np1.add(jb2);
        np1.add(jb3);
        np1.add(jb4);
        np1.add(jb5);
        JPanel tampt=new JPanel();
        tampt.add(process1);
        np1.add(tampt);
        np1.setPreferredSize(new Dimension(200, 0));
        JPanel orderLeft=new JPanel();
        orderLeft.setLayout(new BorderLayout());
        orderLeft.add(np1,BorderLayout.CENTER);
        String st = "select cNo,cName,DateOfBirth,Sex,teleNo,address from Customer WHERE cNo>0";
        Vector rowData = test.getRows(st, st);
        // 取得haha数据库的aa表的表头数据
        Vector columnNames = test.getHead(st, st);
        tableModel2 = new DefaultTableModel(rowData, columnNames){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table2 = new JTable(tableModel2);
        sc2 = new JScrollPane(table2);
        sc2.setPreferredSize(new Dimension(1000, 0));

        jp2.add(BorderLayout.WEST, orderLeft);
        jp2.add(BorderLayout.EAST, sc2);
        process1.addActionListener(new ActionListener() {
                                       public void actionPerformed(ActionEvent e) {
                                           JPanel np3;
                                           if (jb1.isSelected()) {
                                               String fill = JOptionPane.showInputDialog("fill in the userNo：");
                                               if (fill != null) {
                                                   String judge = "SELECT * FROM Customer WHERE cNo=\'" + fill + "\'";
                                                   int row = test.judgeif(judge, judge);
                                                   if (row == 0) {
                                                       System.out.println("no");
                                                       String del = "The Customer where cNo=" + fill + "doesn't exist";
                                                       JOptionPane.showMessageDialog(null, del, "Delete Error", JOptionPane.ERROR_MESSAGE);
                                                   } else {
                                                       String sql = "delete from Customer where cNo=\'" + fill + "\'";
                                                       test.change(st, sql);
                                                       modelChange2(st, st);
                                                   }
                                               } else {
                                                   JOptionPane.showMessageDialog(null, "Please fill in the customer No", "Delete Error", JOptionPane.ERROR_MESSAGE);
                                               }
                                           } else if (jb2.isSelected()) {  //增加
                                               String usValue = JOptionPane.showInputDialog("Please enter customer number");
                                               String judge = "SELECT * FROM Customer WHERE cNo=\'" + usValue + "\'";
                                               int row = test.judgeif(judge, judge);
                                               if (usValue != null && usValue.trim().length() != 0) {
                                                   if (row == 1) {
                                                       System.out.println("yes");
                                                       String del = "The Customer where cNo= " + usValue + " exist";
                                                       JOptionPane.showMessageDialog(null, del, "Add Error", JOptionPane.ERROR_MESSAGE);
                                                   } else {
                                                       ua = new JFrame("User Add");
                                                       uay = new JButton("Yes");                          //确定取消按钮
                                                       uacan = new JButton("Cancel");
                                                       uay.addActionListener(new uAButtonListener());
                                                       uacan.addActionListener(new uAButtonListener());
                                                       JPanel yp = new JPanel();
                                                       JPanel cp = new JPanel();
                                                       JPanel bio = new JPanel();
                                                       yp.add(uay);
                                                       cp.add(uacan);
                                                       bio.setLayout(new GridLayout(1, 2));
                                                       bio.add(yp);
                                                       bio.add(cp);
                                                       JPanel content = new JPanel();
                                                       content.setLayout(new GridLayout(2, 1));
                                                       content.add(uAddGUI(usValue));
                                                       content.add(bio);
                                                       JLabel space0 = new JLabel("                    ");
                                                       JLabel space1 = new JLabel("                    ");
                                                       ua.setLayout(new BorderLayout(5, 10));
                                                       ua.add(space0, BorderLayout.WEST);
                                                       ua.add(content, BorderLayout.CENTER);
                                                       ua.add(space1, BorderLayout.EAST);
                                                       ua.setSize(800, 250);
                                                       ua.setLocation(300, 200);
                                                       ua.setVisible(true);
                                                       ua.setResizable(false);
                                                   }
                                               } else {
                                                   JOptionPane.showMessageDialog(null, "Please fill in the customer No", "Add Error", JOptionPane.ERROR_MESSAGE);
                                               }
                                           } else if (jb3.isSelected()) {  //修改
                                               omValue = JOptionPane.showInputDialog("Please enter customer number");
                                               String judge = "SELECT * FROM Customer WHERE cNo=\'" + omValue + "\'";
                                               int row = test.judgeif(judge, judge);

                                               if (omValue != null && omValue.trim().length() != 0) {
                                                   if (row == 0) {
                                                       System.out.println("no");
                                                       String del = "The Customer where cNo=" + omValue + "doesn't exist";
                                                       JOptionPane.showMessageDialog(null, del, "Modify Error", JOptionPane.ERROR_MESSAGE);
                                                   } else {
                                                       um = new JFrame("User Modify");

                                                       umy = new JButton("Yes");                          //确定取消按钮
                                                       umcan = new JButton("Cancel");
                                                       umy.addActionListener(new mUButtonListener());
                                                       umcan.addActionListener(new mUButtonListener());
                                                       JPanel yp = new JPanel();
                                                       JPanel cp = new JPanel();
                                                       JPanel bio = new JPanel();
                                                       yp.add(umy);
                                                       cp.add(umcan);
                                                       bio.setLayout(new GridLayout(1, 2));
                                                       bio.add(yp);
                                                       bio.add(cp);

                                                       JPanel content = new JPanel();
                                                       content.setLayout(new GridLayout(2, 1));
                                                       content.add(uModifyGUI());
                                                       content.add(bio);


                                                       JLabel space0 = new JLabel("                    ");
                                                       JLabel space1 = new JLabel("                    ");
                                                       um.setLayout(new BorderLayout(5, 10));
                                                       um.add(space0, BorderLayout.WEST);
                                                       um.add(content, BorderLayout.CENTER);
                                                       um.add(space1, BorderLayout.EAST);


                                                       um.setSize(650, 350);
                                                       um.setLocation(300, 200);
                                                       um.setVisible(true);
                                                       um.setResizable(false);
                                                   }
                                               } else {
                                                   JOptionPane.showMessageDialog(null, "Please fill in the Customer No", "Modify Error", JOptionPane.ERROR_MESSAGE);
                                               }
                                           } else if (jb4.isSelected()) {
                                               uS = new JFrame("User Search");

                                               usy = new JButton("Yes");
                                               usy.addActionListener(new uSButtonListener());

                                               JPanel content = new JPanel();
                                               content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
                                               content.add(uSearchGUI());
                                               content.add(usy);


                                               JLabel space0 = new JLabel("                    ");
                                               JLabel space1 = new JLabel("                    ");
                                               uS.setLayout(new BorderLayout(5, 10));
                                               uS.add(space0, BorderLayout.WEST);
                                               uS.add(content, BorderLayout.CENTER);
                                               uS.add(space1, BorderLayout.EAST);

                                               uS.setSize(650, 350);
                                               uS.setLocation(300, 200);
                                               uS.setVisible(true);
                                               uS.setResizable(false);
                                           } else if (jb5.isSelected()) {
                                               modelChange2(st, st);
                                           } else {
                                               JOptionPane.showInputDialog("please select the operation");
                                           }
                                       }
                                   }
        );
    }

    public void modelChange2(String s1, String s2) {
        jp2.remove(sc2);
        Vector rowData1 = test.getRows(s1, s2);
        // 取得数据库的表的表头数据
        Vector columnNames1 = test.getHead(s1, s2);
        tableModel2 = new DefaultTableModel(rowData1, columnNames1){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table2 = new JTable(tableModel2);
        sc2 = new JScrollPane(table2);
        sc2.setPreferredSize(new Dimension(1000, 0));
        jp2.add(BorderLayout.EAST, sc2);
        System.out.println(s1);
    }

    public void modelChange4(String s1, String s2) {
        jp4.remove(s);
        Vector rowData1 = test.getRows(s1, s2);
        // 取得haha数据库的aa表的表头数据
        Vector columnNames1 = test.getHead(s1, s2);
        tableModel = new DefaultTableModel(rowData1, columnNames1){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table4 = new JTable(tableModel);
        s = new JScrollPane(table4);
        s.setPreferredSize(new Dimension(1000, 0));
        jp4.add(BorderLayout.EAST, s);
    }

    class mUButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent ome) {
            if (ome.getSource() == umy) {    //modify the state of the item
                uModify(omValue);
                um.dispose();
            } else {
                um.dispose();
            }

        }
    }

    class uAButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent ome) {
            if (ome.getSource() == uay) {    //modify the state of the item
                uAdd();
                ua.dispose();
            } else {
                ua.dispose();
            }

        }
    }

    public void uModify(String uNo) {


        int year = DaY.getSelectedIndex();
        int mon = DaM.getSelectedIndex();
        int day = DaD.getSelectedIndex();

        String Year = DaY.getItemAt(year);
        String Mon = DaM.getItemAt(mon);
        String Day = DaD.getItemAt(day);
        String birth = "\'" + Year + "-" + Mon + "-" + Day + "\'";


        String uName = opqText3.getText();
        String tel = opfText3.getText();
        String addr = oppText3.getText();
        int tamp = SEX.getSelectedIndex();
        String sex;
        if (tamp == 0) {
            sex = "M";
        } else {
            sex = "F";
        }
        String st = "select cNo,cName,DateOfBirth,Sex,teleNo,address from Customer WHERE cNo>0";
        String[] sq = {"", "", "", "", "", ""};
        sq[0] = "UPDATE Customer SET cName =\'" + uName + "\' WHERE cNo=" + uNo;
        sq[1] = "UPDATE Customer SET DateOfBirth =" + birth + " WHERE cNo=" + uNo;
        sq[2] = "UPDATE Customer SET Sex =\'" + sex + "\' WHERE cNo=" + uNo;
        sq[3] = "UPDATE Customer SET teleNo =\'" + tel + "\' WHERE cNo=" + uNo;
        sq[4] = "UPDATE Customer SET address =\'" + addr + "\' WHERE cNo=" + uNo;
        sq[5] = "UPDATE Customer SET cPassword='0000', cPasswordC='aswfkwek4' WHERE cNo=" + uNo;

        if (uName != null && uName.trim().length() != 0) {   //改名
            test.change(st, sq[0]);
            modelChange2(st, st);
        }
        if (qu1.isSelected()) {   //改变生日
            test.change(st, sq[1]);
            modelChange2(st, st);
        }
        if (qu2.isSelected()) {   //改性别
            test.change(st, sq[2]);
            modelChange2(st, st);
        }
        if (qu3.isSelected()) {   //改电话
            test.change(st, sq[3]);
            modelChange2(st, st);
        }
        if (qu4.isSelected()) {   //改地址
            test.change(st, sq[4]);
            modelChange2(st, st);
        }
        if (ucn.isSelected()) {
            test.change(st, sq[5]);
            modelChange2(st, st);
        }
    }

    public JPanel uModifyGUI() {

        JPanel oINFO = new JPanel();


        JLabel opq = new JLabel("Customer Name");
        qu1 = new JRadioButton("Date of Birth");
        qu2 = new JRadioButton("Sex");
        qu3 = new JRadioButton("telephone No");
        qu4 = new JRadioButton("address");
        ucn = new JRadioButton("reset password");

        opqText3 = new JTextField();  //顾客名
        opfText3 = new JTextField();  //电话
        oppText3 = new JTextField();  //地址


        opqText3.setMaximumSize(new Dimension(500, opqText3.getMinimumSize().height));
        opfText3.setMaximumSize(new Dimension(500, opfText3.getMinimumSize().height));
        oppText3.setMaximumSize(new Dimension(500, oppText3.getMinimumSize().height));
        ucn.setMaximumSize(new Dimension(500, ucn.getMinimumSize().height));

        //添加复选框和文本框
        JPanel opqPanel = new JPanel();
        JPanel oprPanel = new JPanel();
        JPanel opcPanel = new JPanel();
        JPanel opfPanel = new JPanel();
        JPanel oppPanel = new JPanel();
        JPanel ocnPanel = new JPanel();

        opqPanel.setLayout(new BoxLayout(opqPanel, BoxLayout.X_AXIS));
        oprPanel.setLayout(new BoxLayout(oprPanel, BoxLayout.X_AXIS));
        opcPanel.setLayout(new BoxLayout(opcPanel, BoxLayout.X_AXIS));
        opfPanel.setLayout(new BoxLayout(opfPanel, BoxLayout.X_AXIS));
        oppPanel.setLayout(new BoxLayout(oppPanel, BoxLayout.X_AXIS));
        ocnPanel.setLayout(new BoxLayout(ocnPanel, BoxLayout.X_AXIS));


        opqPanel.add(opq);
        oprPanel.add(qu1);
        opcPanel.add(qu2);
        opfPanel.add(qu3);
        oppPanel.add(qu4);
        ocnPanel.add(ucn);
        opqPanel.add(Box.createHorizontalStrut(5));
        oprPanel.add(Box.createHorizontalStrut(15));
        opcPanel.add(Box.createHorizontalStrut(5));
        opfPanel.add(Box.createHorizontalStrut(5));
        oppPanel.add(Box.createHorizontalStrut(5));
        ocnPanel.add(Box.createHorizontalStrut(5));

        opqPanel.add(opqText3);
        oprPanel.add(defineDate());
        opcPanel.add(defineSex());
        opfPanel.add(opfText3);
        oppPanel.add(oppText3);

        oINFO.setLayout(new GridLayout(0, 2));
        oINFO.add(opqPanel);
        oINFO.add(opcPanel);
        oINFO.add(opfPanel);
        oINFO.add(oppPanel);
        oINFO.add(ocnPanel);
        JPanel fin = new JPanel();
        fin.setLayout(new BoxLayout(fin, BoxLayout.Y_AXIS));
        fin.add(oINFO);
        fin.add(Box.createVerticalStrut(5));
        fin.add(oprPanel);

        return fin;

    }


    public void uAdd() {

        int year = DaY.getSelectedIndex() + 1970;
        int mon = DaM.getSelectedIndex() + 1;
        int day = DaD.getSelectedIndex() + 1;

        String Year = String.valueOf(year);
        String Mon = String.valueOf(mon);
        String Day = String.valueOf(day);
        String birth = "\'" + Year + "-" + Mon + "-" + Day + "\'";

        String uNo = opnText3.getText();
        String uName = opqText3.getText();
        String tel = opfText3.getText();
        String addr = oppText3.getText();
        int tamp = SEX.getSelectedIndex();
        String sex;
        if (tamp == 0) {
            sex = "M";
        } else {
            sex = "F";
        }
        String sql = "INSERT INTO Customer VALUES( \'" + uNo + "\' ,  \'" + uName + "\', '0000' , " + birth +
                ",  \'" + sex + "\',  \'" + tel + "\',  \'" + addr + "\', '101', 'aassffdbas' )";
        System.out.println(sql);
        String st = "SELECT cNo,cName,DateOfBirth,Sex,teleNo,address FROM Customer WHERE cNo >0";
        test.change(st, sql);
        jp2.remove(sc2);
        Vector rowData1 = test.getRows(st, st);
        // 取得haha数据库的aa表的表头数据
        Vector columnNames1 = test.getHead(st, st);
        tableModel2 = new DefaultTableModel(rowData1, columnNames1){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table2 = new JTable(tableModel2);
        sc2 = new JScrollPane(table2);
        sc2.setPreferredSize(new Dimension(1000, 0));
        jp2.add(BorderLayout.EAST, sc2);
    }

    public JPanel uAddGUI(String No) {
        JPanel oINFO = new JPanel();

        JLabel opn = new JLabel("Customer No");
        JLabel opq = new JLabel("Customer Name");
        JLabel opr = new JLabel("Date of Birth");
        JLabel opc = new JLabel("Sex");
        JLabel opf = new JLabel("telephone No");
        JLabel opp = new JLabel("address");

        opnText3 = new JTextField(No);  //顾客号
        opnText3.setEditable(false);
        opqText3 = new JTextField();  //顾客名
        opfText3 = new JTextField();  //电话
        oppText3 = new JTextField();  //地址


        opnText3.setMaximumSize(new Dimension(500, opnText3.getMinimumSize().height));
        opqText3.setMaximumSize(new Dimension(500, opqText3.getMinimumSize().height));
        opfText3.setMaximumSize(new Dimension(500, opfText3.getMinimumSize().height));
        oppText3.setMaximumSize(new Dimension(500, oppText3.getMinimumSize().height));


        JPanel opnPanel = new JPanel();    //添加复选框和文本框
        JPanel opqPanel = new JPanel();
        JPanel oprPanel = new JPanel();
        JPanel opcPanel = new JPanel();
        JPanel opfPanel = new JPanel();
        JPanel oppPanel = new JPanel();

        opnPanel.setLayout(new BoxLayout(opnPanel, BoxLayout.X_AXIS));
        opqPanel.setLayout(new BoxLayout(opqPanel, BoxLayout.X_AXIS));
        oprPanel.setLayout(new BoxLayout(oprPanel, BoxLayout.X_AXIS));
        opcPanel.setLayout(new BoxLayout(opcPanel, BoxLayout.X_AXIS));
        opfPanel.setLayout(new BoxLayout(opfPanel, BoxLayout.X_AXIS));
        oppPanel.setLayout(new BoxLayout(oppPanel, BoxLayout.X_AXIS));


        opnPanel.add(opn);
        opqPanel.add(opq);
        oprPanel.add(opr);
        opcPanel.add(opc);
        opfPanel.add(opf);
        oppPanel.add(opp);
        opnPanel.add(Box.createHorizontalStrut(5));
        opqPanel.add(Box.createHorizontalStrut(5));
        oprPanel.add(Box.createHorizontalStrut(15));
        opcPanel.add(Box.createHorizontalStrut(5));
        opfPanel.add(Box.createHorizontalStrut(5));
        oppPanel.add(Box.createHorizontalStrut(5));

        opnPanel.add(opnText3);
        opqPanel.add(opqText3);
        oprPanel.add(defineDate());
        opcPanel.add(defineSex());
        opfPanel.add(opfText3);
        oppPanel.add(oppText3);

        oINFO.setLayout(new GridLayout(0, 2));
        oINFO.add(opnPanel);
        oINFO.add(opqPanel);
        oINFO.add(opcPanel);
        oINFO.add(opfPanel);
        oINFO.add(oppPanel);
        oINFO.add(oprPanel);



        return oINFO;
    }

    class uSButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent ome) {
            if (ome.getSource() == usy) {    //modify the state of the item
                uSearch();
                uS.dispose();
            } else {
                uS.dispose();
            }

        }
    }

    public void uSearch() {
        int index1 = DaY.getSelectedIndex();
        int index2 = DaM.getSelectedIndex();
        int index3 = DaD.getSelectedIndex();
        int index4 = BaY.getSelectedIndex();
        int index5 = BaM.getSelectedIndex();
        int index6 = BaD.getSelectedIndex();
        int index7 = SEX.getSelectedIndex();
        String sYear = DaY.getItemAt(index1);
        String sMon = DaM.getItemAt(index2);
        String sDay = DaD.getItemAt(index3);
        String eYear = BaY.getItemAt(index4);
        String eMon = BaM.getItemAt(index5);
        String eDay = BaD.getItemAt(index6);
        String Sex = SEX.getItemAt(index7);
        String sDOB = sYear + "-" + sMon + "-" + sDay;
        String eDOB = eYear + "-" + eMon + "-" + eDay;

        String usNo = us1.getText();//用户号
        String usName = us2.getText();// 用户名字
        String usTel = us3.getText();//用户电话
        String usAdd = us4.getText();//用户地址


        String[] sql = {"", "", "", "", "", "", "", "", "", "", "", ""};
        sql[0] = " AND cNo LIKE \'%" + usNo + "%\'";
        sql[1] = " AND cname LIKE \'%" + usName + "%\' ";
        sql[2] = " AND DateOfBirth > \'" + sDOB + "\'";
        sql[3] = " AND DateOfBirth < \'" + eDOB + "\'";
        sql[4] = " AND Sex =\'" + Sex + "\'";
        sql[5] = " AND teleNo LIKE \'%" + usTel + "%\'";
        sql[6] = " AND address LIKE \'%" + usAdd + "%\'";

        String osq1 = "SELECT cNo, cName , DateOfBirth, Sex, teleNo , address " +
                " FROM Customer WHERE Manager_mNo= '101' AND cNo>0";

        //添加筛选条件
        if (cS1.isSelected()) {   //输入了用户号
            osq1 = osq1 + sql[0];
        }
        if (cS2.isSelected()) { //用户名
            osq1 = osq1 + sql[1];
        }
        if (sUser.isSelected()) { //出生年月日大于

            osq1 = osq1 + sql[2];
        }
        if (eUser.isSelected()) { //出生年月日小于

            osq1 = osq1 + sql[3];

        }
        if (uSex.isSelected()) {//性别

            osq1 = osq1 + sql[4];
        }
        if (cS3.isSelected()) {     //电话
            osq1 = osq1 + sql[5];
        }
        if (cS4.isSelected()) {    //地址
            osq1 = osq1 + sql[6];
        }
        modelChange2(osq1, osq1);

    }

    public JPanel uSearchGUI() {

        JPanel oINFO = new JPanel();
        JLabel not = new JLabel("Please select 1 or more condition");
        cS1 = new JRadioButton("Customer No");
        cS2 = new JRadioButton("Customer Name");
        sUser = new JRadioButton("Date of Birth from");
        eUser = new JRadioButton("Date of Birth to");
        uSex = new JRadioButton("Sex");
        cS3 = new JRadioButton("telephone No");
        cS4 = new JRadioButton("address");

        us1 = new JTextField();  //用户号
        us2 = new JTextField();  //用户名字
        us3 = new JTextField();  //电话
        us4 = new JTextField(); //地址
        us1.setMaximumSize(new Dimension(500, us1.getMinimumSize().height));
        us2.setMaximumSize(new Dimension(500, us2.getMinimumSize().height));
        us3.setMaximumSize(new Dimension(500, us3.getMinimumSize().height));
        us4.setMaximumSize(new Dimension(500, us4.getMinimumSize().height));

        JPanel opnPanel = new JPanel();    //添加复选框和文本框
        JPanel opqPanel = new JPanel();
        JPanel oprPanel = new JPanel();
        JPanel opcPanel = new JPanel();
        JPanel opfPanel = new JPanel();
        JPanel oppPanel = new JPanel();
        JPanel ocnPanel = new JPanel();

        opnPanel.setLayout(new BoxLayout(opnPanel, BoxLayout.X_AXIS));
        opqPanel.setLayout(new BoxLayout(opqPanel, BoxLayout.X_AXIS));
        oprPanel.setLayout(new BoxLayout(oprPanel, BoxLayout.X_AXIS));
        opcPanel.setLayout(new BoxLayout(opcPanel, BoxLayout.X_AXIS));
        opfPanel.setLayout(new BoxLayout(opfPanel, BoxLayout.X_AXIS));
        oppPanel.setLayout(new BoxLayout(oppPanel, BoxLayout.X_AXIS));
        ocnPanel.setLayout(new BoxLayout(ocnPanel, BoxLayout.X_AXIS));

        opnPanel.add(cS1);
        opqPanel.add(cS2);
        oprPanel.add(sUser);
        opcPanel.add(eUser);
        opfPanel.add(uSex);
        oppPanel.add(cS3);
        ocnPanel.add(cS4);

        opnPanel.add(Box.createHorizontalStrut(5));
        opqPanel.add(Box.createHorizontalStrut(5));
        oprPanel.add(Box.createHorizontalStrut(5));
        opcPanel.add(Box.createHorizontalStrut(5));
        opfPanel.add(Box.createHorizontalStrut(5));
        oppPanel.add(Box.createHorizontalStrut(5));
        ocnPanel.add(Box.createHorizontalStrut(5));

        opnPanel.add(us1);
        opqPanel.add(us2);
        oprPanel.add(defineDate());
        opcPanel.add(defineEndDate());
        opfPanel.add(defineSex());
        oppPanel.add(us3);
        ocnPanel.add(us4);

        oINFO.setLayout(new GridLayout(0, 2));
        oINFO.add(opnPanel);
        oINFO.add(opqPanel);
        oINFO.add(opfPanel);
        oINFO.add(oppPanel);
        oINFO.add(ocnPanel);

        JPanel fin1 = new JPanel();
        fin1.setLayout(new BoxLayout(fin1, BoxLayout.Y_AXIS));
        fin1.add(oINFO);
        fin1.add(oprPanel);
        fin1.add(opcPanel);

        JPanel info = new JPanel();
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.add(not);
        info.add(fin1);

        return info;
    }


    public void setStore() {
        JPanel np1, np;
        JLabel jl1, jl2;
        JScrollPane sc1;
        String s1, s2, s3, s4, s5;

        JRadioButton jb1, jb2, jb3, jb4, jb5;
        ButtonGroup option;

        jl1 = new JLabel("please select the operation");
        s1 = "delete store's information";
        s2 = "add store's information";
        s3 = "modify store's information";
        s4 = "seek store's information";
        s5 = "show all store";
        jb1 = new JRadioButton(s1);
        jb2 = new JRadioButton(s2);
        jb3 = new JRadioButton(s3);
        jb4 = new JRadioButton(s4);
        jb5 = new JRadioButton(s5);
        option = new ButtonGroup();
        option.add(jb1);
        option.add(jb2);
        option.add(jb3);
        option.add(jb4);
        option.add(jb5);
        String st = "SELECT storeNo, storeName, Port, sComment FROM Store WHERE storeNo>0";
        Vector rowData = test.getRows(st, st);
        // 取得haha数据库的aa表的表头数据
        Vector columnNames = test.getHead(st, st);
        tableModel3 = new DefaultTableModel(rowData, columnNames){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table3 = new JTable(tableModel3);
        sc3 = new JScrollPane(table3);
        sc3.setPreferredSize(new Dimension(1000, 0));


        process2 = new JButton("process");
        Dimension dim2 = new Dimension(80, 20);
        process2.setPreferredSize(dim2);

        np = new JPanel();
        np.setLayout(new GridLayout(0,1));
        np.add(jl1);
        np.add(jb1);
        np.add(jb2);
        np.add(jb3);
        np.add(jb4);
        np.add(jb5);
        JPanel tampt=new JPanel();
        tampt.add(process2);
        np.add(tampt);
        np.setPreferredSize(new Dimension(200, 0));
        JPanel orderLeft=new JPanel();
        orderLeft.setLayout(new BorderLayout());
        orderLeft.add(np,BorderLayout.CENTER);

        jp3.add(BorderLayout.WEST, orderLeft);
        jp3.add(BorderLayout.EAST, sc3);
        process2.addActionListener(new ActionListener() {
                                       public void actionPerformed(ActionEvent e) {
                                           JPanel np3;
                                           if (jb1.isSelected()) {
                                               String fill = JOptionPane.showInputDialog("fill in the storeNo：");
                                               if (fill != null) {
                                                   String judge = "SELECT * FROM Store WHERE storeNo=\'" + fill + "\'";
                                                   int row = test.judgeif(judge, judge);
                                                   if (row == 0) {
                                                       System.out.println("no");
                                                       String del = "The Store where storeNo= " + fill + "doesn't exist";
                                                       JOptionPane.showMessageDialog(null, del, "Delete Error", JOptionPane.ERROR_MESSAGE);
                                                   } else {
                                                       String sql = "DELETE from Store where storeNo= \'" + fill + "\'";
                                                       test.change(st, sql);
                                                       modelChange3(st, st);
                                                   }
                                               } else {
                                                   JOptionPane.showMessageDialog(null, "Please fill in the storeNo", "Delete Error", JOptionPane.ERROR_MESSAGE);
                                               }
                                           } else if (jb2.isSelected()) {
                                               String usValue = JOptionPane.showInputDialog("Please enter storeNo");
                                               String judge = "SELECT * FROM Store WHERE storeNo=\'" + usValue + "\'";
                                               int row = test.judgeif(judge, judge);
                                               if (usValue != null && usValue.trim().length() != 0) {
                                                   if (row == 1) {
                                                       System.out.println("yes");
                                                       String del = "The Store where storeNo= " + usValue + " exist";
                                                       JOptionPane.showMessageDialog(null, del, "Add Error", JOptionPane.ERROR_MESSAGE);
                                                   } else {
                                                       sa = new JFrame("Store Add");
                                                       say = new JButton("Yes");                          //确定取消按钮
                                                       sacan = new JButton("Cancel");
                                                       say.addActionListener(new sAButtonListener());
                                                       sacan.addActionListener(new sAButtonListener());
                                                       JPanel yp = new JPanel();
                                                       JPanel cp = new JPanel();
                                                       JPanel bio = new JPanel();
                                                       yp.add(say);
                                                       cp.add(sacan);
                                                       bio.setLayout(new GridLayout(1, 2));
                                                       bio.add(yp);
                                                       bio.add(cp);

                                                       JPanel content = new JPanel();
                                                       content.setLayout(new GridLayout(2, 1));
                                                       content.add(sAddGUI(usValue));
                                                       content.add(bio);


                                                       JLabel space0 = new JLabel("                    ");
                                                       JLabel space1 = new JLabel("                    ");
                                                       sa.setLayout(new BorderLayout(5, 10));
                                                       sa.add(space0, BorderLayout.WEST);
                                                       sa.add(content, BorderLayout.CENTER);
                                                       sa.add(space1, BorderLayout.EAST);

                                                       sa.setSize(650, 350);
                                                       sa.setLocation(300, 200);
                                                       sa.setVisible(true);
                                                       sa.setResizable(false);
                                                   }
                                               } else {
                                                   JOptionPane.showMessageDialog(null, "Please fill in the storeNo", "Add Error", JOptionPane.ERROR_MESSAGE);
                                               }
                                           } else if (jb3.isSelected()) {
                                               sValue = JOptionPane.showInputDialog("Please enter store number");
                                               if (sValue != null && sValue.trim().length() != 0) {
                                                   String judge = "SELECT * FROM Store WHERE storeNo=\'" + sValue + "\'";
                                                   int row = test.judgeif(judge, judge);
                                                   if (row == 0) {
                                                       System.out.println("no");
                                                       String del = "The Store where storeNo= " + sValue + "doesn't exist";
                                                       JOptionPane.showMessageDialog(null, del, "Reset Error", JOptionPane.ERROR_MESSAGE);
                                                   } else {
                                                       sm = new JFrame("Store Modify");

                                                       smy = new JButton("Yes");                          //确定取消按钮
                                                       smcan = new JButton("Cancel");
                                                       smy.addActionListener(new sUButtonListener());
                                                       smcan.addActionListener(new sUButtonListener());
                                                       JPanel yp = new JPanel();
                                                       JPanel cp = new JPanel();
                                                       JPanel bio = new JPanel();
                                                       yp.add(smy);
                                                       cp.add(smcan);
                                                       bio.setLayout(new GridLayout(1, 2));
                                                       bio.add(yp);
                                                       bio.add(cp);
                                                       JPanel content = new JPanel();
                                                       content.setLayout(new GridLayout(2, 1));
                                                       content.add(sModifyGUI());
                                                       content.add(bio);
                                                       JLabel space0 = new JLabel("                    ");
                                                       JLabel space1 = new JLabel("                    ");
                                                       sm.setLayout(new BorderLayout(5, 10));
                                                       sm.add(space0, BorderLayout.WEST);
                                                       sm.add(content, BorderLayout.CENTER);
                                                       sm.add(space1, BorderLayout.EAST);
                                                       sm.setSize(650, 350);
                                                       sm.setLocation(300, 200);
                                                       sm.setVisible(true);
                                                       sm.setResizable(false);
                                                   }
                                               } else {
                                                   JOptionPane.showMessageDialog(null, "Please fill in the storeNo", "Search Error", JOptionPane.ERROR_MESSAGE);
                                               }

                                           } else if (jb4.isSelected()) {
                                               ss = new JFrame("Store Search");
                                               ssy = new JButton("Yes");
                                               ssy.addActionListener(new sSButtonListener());
                                               JPanel pan=new JPanel();
                                               pan.add(ssy);

                                               JPanel content = new JPanel();
                                               content.setLayout(new GridLayout(0,1));
                                               content.add(sSearchGUI());
                                               content.add(pan);

                                               JLabel space0 = new JLabel("                    ");
                                               JLabel space1 = new JLabel("                    ");
                                               ss.setLayout(new BorderLayout(5, 10));
                                               ss.add(space0, BorderLayout.WEST);
                                               ss.add(content, BorderLayout.CENTER);
                                               ss.add(space1, BorderLayout.EAST);

                                               ss.setSize(650, 350);
                                               ss.setLocation(300, 200);
                                               ss.setVisible(true);
                                               ss.setResizable(false);
                                           } else if (jb5.isSelected()) {
                                               modelChange3(st, st);
                                           } else {
                                               JOptionPane.showInputDialog("please select the operation");
                                           }
                                       }
                                   }
        );
    }

    class sUButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent ome) {
            if (ome.getSource() == smy) {    //modify the state of the item
                sModify(sValue);
                sm.dispose();
            } else {
                sm.dispose();
            }

        }
    }

    class sAButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent ome) {
            if (ome.getSource() == say) {    //modify the state of the item
                sAdd();
                sa.dispose();
            } else {
                sa.dispose();
            }

        }
    }

    public void modelChange3(String s1, String s2) {
        jp3.remove(sc3);
        Vector rowData1 = test.getRows(s1, s2);
        // 取得haha数据库的aa表的表头数据
        Vector columnNames1 = test.getHead(s1, s2);
        tableModel3 = new DefaultTableModel(rowData1, columnNames1){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table3 = new JTable(tableModel3);
        sc3 = new JScrollPane(table3);
        sc3.setPreferredSize(new Dimension(1000, 0));
        jp3.add(BorderLayout.EAST, sc3);
    }

    public void sAdd() {
        String sNo = ua1.getText();
        String sName = ua2.getText();
        String port = ua3.getText();
        String com = ua4.getText();
        String sql = "INSERT INTO Store VALUES( \'" + sNo + "\' ,  \'" + sName + "\', \'" + port + "\',  \'" + com + "\', '101', '0000')";
        String st = "SELECT storeNo,storeName,Port,sComment FROM Store WHERE storeNo>0";
        test.change(st, sql);
        modelChange3(st, st);
    }

    public JPanel sAddGUI(String us) {
        JPanel oINFO = new JPanel();
        JLabel opn = new JLabel("Store No");
        JLabel opq = new JLabel("Store Name");
        JLabel opr = new JLabel("Port");
        JLabel opc = new JLabel("Comment");


        ua1 = new JTextField(us);  //店铺号
        ua1.setEditable(false);
        ua2 = new JTextField();  //店铺名
        ua3 = new JTextField();  //发货地
        ua4 = new JTextField();  //评价


        ua1.setMaximumSize(new Dimension(500, ua1.getMinimumSize().height));
        ua2.setMaximumSize(new Dimension(500, ua2.getMinimumSize().height));
        ua3.setMaximumSize(new Dimension(500, ua3.getMinimumSize().height));
        ua4.setMaximumSize(new Dimension(500, ua4.getMinimumSize().height));


        JPanel opnPanel = new JPanel();    //添加复选框和文本框
        JPanel opqPanel = new JPanel();
        JPanel oprPanel = new JPanel();
        JPanel opcPanel = new JPanel();

        opnPanel.setLayout(new BoxLayout(opnPanel, BoxLayout.X_AXIS));
        opqPanel.setLayout(new BoxLayout(opqPanel, BoxLayout.X_AXIS));
        oprPanel.setLayout(new BoxLayout(oprPanel, BoxLayout.X_AXIS));
        opcPanel.setLayout(new BoxLayout(opcPanel, BoxLayout.X_AXIS));


        opnPanel.add(opn);
        opqPanel.add(opq);
        oprPanel.add(opr);
        opcPanel.add(opc);
        opnPanel.add(Box.createHorizontalStrut(5));
        opqPanel.add(Box.createHorizontalStrut(5));
        oprPanel.add(Box.createHorizontalStrut(5));
        opcPanel.add(Box.createHorizontalStrut(5));

        opnPanel.add(ua1);
        opqPanel.add(ua2);
        oprPanel.add(ua3);
        opcPanel.add(ua4);

        oINFO.setLayout(new GridLayout(0, 2));
        oINFO.add(opnPanel);
        oINFO.add(opqPanel);
        oINFO.add(oprPanel);
        oINFO.add(opcPanel);

        return oINFO;

    }

    public void sModify(String sNo) {
        String uName = ua2.getText();
        String port = ua3.getText();
        String com = ua4.getText();
        String[] sql = {"", "", "", ""};
        sql[0] = " UPDATE Store SET storeName= \'" + uName + "\' WHERE storeNo= \'" + sNo + "\'";
        sql[1] = "UPDATE Store SET Port= \'" + port + "\' WHERE storeNo= \'" + sNo + "\'";
        sql[2] = " UPDATE Store SET sComment= \'" + com + "\' WHERE storeNo= \'" + sNo + "\'";
        sql[3] = "UPDATE Store SET sPassword='0000' WHERE storeNo= " + sNo;
        String st = "SELECT storeNo,storeName,Port,sComment FROM Store WHERE storeNo>0";
        if (qu5.isSelected()) {
            test.change(st, sql[0]);
            modelChange3(st, st);
        }
        if (qu6.isSelected()) {
            test.change(st, sql[1]);
            modelChange3(st, st);
        }
        if (qu7.isSelected()) {
            test.change(st, sql[2]);
            modelChange3(st, st);
        }
        if (scn.isSelected()) {
            test.change(st, sql[3]);
            modelChange3(st, st);
        }
    }

    public JPanel sModifyGUI() {

        JPanel oINFO = new JPanel();
        qu5 = new JRadioButton("Store Name");
        qu6 = new JRadioButton("Port");
        qu7 = new JRadioButton("Comment");
        scn = new JRadioButton("reset password");

        ua2 = new JTextField();  //店铺名
        ua3 = new JTextField();  //发货地
        ua4 = new JTextField();  //评价


        ua2.setMaximumSize(new Dimension(500, ua2.getMinimumSize().height));
        ua3.setMaximumSize(new Dimension(500, ua3.getMinimumSize().height));
        ua4.setMaximumSize(new Dimension(500, ua4.getMinimumSize().height));
        scn.setMaximumSize(new Dimension(500, scn.getMinimumSize().height));

        JPanel opqPanel = new JPanel();
        JPanel oprPanel = new JPanel();
        JPanel opcPanel = new JPanel();
        JPanel opfPanel = new JPanel();

        opqPanel.setLayout(new BoxLayout(opqPanel, BoxLayout.X_AXIS));
        oprPanel.setLayout(new BoxLayout(oprPanel, BoxLayout.X_AXIS));
        opcPanel.setLayout(new BoxLayout(opcPanel, BoxLayout.X_AXIS));
        opfPanel.setLayout(new BoxLayout(opfPanel, BoxLayout.X_AXIS));

        opqPanel.add(qu5);
        oprPanel.add(qu6);
        opcPanel.add(qu7);
        opfPanel.add(scn);
        opqPanel.add(Box.createHorizontalStrut(5));
        oprPanel.add(Box.createHorizontalStrut(5));
        opcPanel.add(Box.createHorizontalStrut(5));
        opfPanel.add(Box.createHorizontalStrut(5));

        opqPanel.add(ua2);
        oprPanel.add(ua3);
        opcPanel.add(ua4);

        oINFO.setLayout(new GridLayout(0, 2));
        oINFO.add(opqPanel);
        oINFO.add(oprPanel);
        oINFO.add(opcPanel);
        oINFO.add(opfPanel);
        return oINFO;
    }

    class sSButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent ome) {
            if (ome.getSource() == ssy) {    //modify the state of the item
                sSearch();
                ss.dispose();
            } else {
                ss.dispose();
            }

        }
    }

    public void sSearch() {


        String usNo = ss1.getText();//商家号
        String usName = ss2.getText();// 商家名字
        String usTel = ss3.getText();//发货地址
        String usAdd = ss4.getText();//评价


        String[] sql = {"", "", "", "", "", "", "", "", "", "", "", ""};
        sql[0] = " AND storeNo LIKE '%" + usNo + "%' ";
        sql[1] = " AND storeName LIKE \'%" + usName + "%\'";
        sql[2] = " AND Port LIKE \'%" + usTel + "%\'";
        sql[3] = " AND sComment LIKE \'%" + usAdd + "%\'";

        String osq1 = "SELECT storeNo, storeName, Port, sComment " +
                " FROM Store WHERE Manager_mNo='101' AND storeNo>0";

        //添加筛选条件
        if (usNo != null && usNo.trim().length() != 0) {   //输入了用户号
            osq1 = osq1 + sql[0];
            System.out.println("No" + osq1);
            //modelChange3(osq1,osq1);
        }
        if (usName != null && usName.trim().length() != 0) { //用户名
            osq1 = osq1 + sql[1];
            System.out.println("Name" + osq1);
            // modelChange3(osq1,osq1);
        }
        if (usTel != null && usTel.trim().length() != 0) {     //发货地
            osq1 = osq1 + sql[2];
            System.out.println("Port" + osq1);
            //modelChange3(osq1,osq1);
        }
        if (usAdd != null && usAdd.trim().length() != 0) {    //评价
            osq1 = osq1 + sql[3];
            System.out.println("comment" + osq1);
            //modelChange3(osq1,osq1);
        }
        modelChange3(osq1, osq1);
    }

    public JPanel sSearchGUI() {

        JPanel oINFO = new JPanel();
        JLabel not = new JLabel("Please select 1 or more condition");
        JLabel opn = new JLabel("Store No");
        JLabel opq = new JLabel("Store Name");
        JLabel opr = new JLabel("Port");
        JLabel opc = new JLabel("Comment");

        ss1 = new JTextField();  //商家号
        ss2 = new JTextField();  //商家名字
        ss3 = new JTextField();  //发货地址
        ss4 = new JTextField(); //评价
        ss1.setMaximumSize(new Dimension(500, ss1.getMinimumSize().height));
        ss2.setMaximumSize(new Dimension(500, ss2.getMinimumSize().height));
        ss3.setMaximumSize(new Dimension(500, ss3.getMinimumSize().height));
        ss4.setMaximumSize(new Dimension(500, ss4.getMinimumSize().height));

        JPanel opnPanel = new JPanel();    //添加复选框和文本框
        JPanel opqPanel = new JPanel();
        JPanel oprPanel = new JPanel();
        JPanel opcPanel = new JPanel();

        opnPanel.setLayout(new BoxLayout(opnPanel, BoxLayout.X_AXIS));
        opqPanel.setLayout(new BoxLayout(opqPanel, BoxLayout.X_AXIS));
        oprPanel.setLayout(new BoxLayout(oprPanel, BoxLayout.X_AXIS));
        opcPanel.setLayout(new BoxLayout(opcPanel, BoxLayout.X_AXIS));

        opnPanel.add(opn);
        opqPanel.add(opq);
        oprPanel.add(opr);
        opcPanel.add(opc);

        opnPanel.add(Box.createHorizontalStrut(5));
        opqPanel.add(Box.createHorizontalStrut(5));
        oprPanel.add(Box.createHorizontalStrut(5));
        opcPanel.add(Box.createHorizontalStrut(5));

        opnPanel.add(ss1);
        opqPanel.add(ss2);
        oprPanel.add(ss3);
        opcPanel.add(ss4);

        oINFO.setLayout(new GridLayout(0, 2));
        oINFO.add(opnPanel);
        oINFO.add(opqPanel);
        oINFO.add(oprPanel);
        oINFO.add(opcPanel);

        JPanel fin1 = new JPanel();
        fin1.setLayout(new BoxLayout(fin1, BoxLayout.Y_AXIS));
        fin1.add(not);
        fin1.add(oINFO);
        return fin1;
    }

    public void setPurchase() {
        JPanel np;
        JLabel jl1;
        String s1, s2, s3, s4, s5;
        JRadioButton jb1, jb2, jb3, jb4, jb5;
        ButtonGroup option;

        String st = "SELECT p.pname AS pianoName, ohp.Num, ROUND(p.price*ohp.Num,2) AS price, p.Store_storeNo AS storeNo, s.storeName, ohp.color, p.pfunction, p.parts, c.cName, o.state, o.oNo, o.dateAndTime, o.oTeleNo, o.oAddress" +
                " FROM orders o, Orders_has_Product ohp,Product p,Customer c, Store s " +
                " WHERE p.pianoNo = ohp.Product_pianoNo AND c.cNo =o.Customer_cNo AND ohp.Orders_oNo = o.oNo AND s.storeNo=p.Store_storeNo";
        jl1 = new JLabel("please select the operation");
        s1 = "delete purchase";
        s2 = "add purchase";
        s3 = "seek purchase";
        s4 = "show all purchase";
        s5 = "Show purchase statics";
//设置订单管理选项卡
        jb1 = new JRadioButton(s1);
        jb2 = new JRadioButton(s2);
        jb3 = new JRadioButton(s3);
        jb4 = new JRadioButton(s4);
        jb5 = new JRadioButton(s5);
        option = new ButtonGroup();
        option.add(jb1);
        option.add(jb2);
        option.add(jb3);
        option.add(jb4);
        option.add(jb5);

        np = new JPanel();
        np.setLayout(new GridLayout(0,1));
        np.add(jl1);
        np.add(jb1);
        np.add(jb2);
        np.add(jb3);
        np.add(jb5);
        np.add(jb4);
        np.setPreferredSize(new Dimension(200, 0));
        process3 = new JButton("process");
        Dimension dim2 = new Dimension(80, 20);
        process3.setPreferredSize(dim2);
        JPanel tampt=new JPanel();
        tampt.add(process3);
        np.add(tampt);
        JPanel orderLeft=new JPanel();
        orderLeft.setLayout(new BorderLayout());
        orderLeft.add(np,BorderLayout.CENTER);
        // 取得haha数据库的aa表的各行数据
        Vector rowData = test.getRows(st, st);
        // 取得haha数据库的aa表的表头数据
        Vector columnNames = test.getHead(st, st);
        tableModel = new DefaultTableModel(rowData, columnNames){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table4 = new JTable(tableModel);
        s = new JScrollPane(table4);
        s.setPreferredSize(new Dimension(1000, 0));
        jp4.add(BorderLayout.WEST, orderLeft);
        jp4.add(BorderLayout.EAST, s);
        process3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (jb1.isSelected()) {
                    String fill = JOptionPane.showInputDialog("fill in the purchaseNo：");
                    if (fill != null) {
                        String judge = "SELECT * FROM Orders WHERE oNo=\'" + fill + "\'";
                        int row = test.judgeif(judge, judge);
                        if (row == 0) {
                            System.out.println("no");
                            String del = "The Order where oderNo= " + fill + "doesn't exist";
                            JOptionPane.showMessageDialog(null, del, "Delete Error", JOptionPane.ERROR_MESSAGE);
                        } else {
                            String sql = "delete from Orders where oNo=" + fill;
                            String sql1 = "DELETE FROM Orders_has_Product WHERE Orders_oNo =" + fill;
                            String st1 = " SELECT * FROM Orders_has_Product";
                            String st2 = "SELECT * FROM Orders";
                            test.change(st1, sql1);
                            test.change(st2, sql);
                            modelChange4(st, st);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Please fill in the purchaseNo", "Delete Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else if (jb2.isSelected()) {
                    String usValue = JOptionPane.showInputDialog("Please enter oderNo");
                    String judge = "SELECT * FROM Orders WHERE oNo=\'" + usValue + "\'";
                    int row = test.judgeif(judge, judge);
                    if (usValue != null && usValue.trim().length() != 0) {
                        if (row == 1) {
                            System.out.println("yes");
                            String del = "The Order where orderNo= " + usValue + " exist";
                            JOptionPane.showMessageDialog(null, del, "Add Error", JOptionPane.ERROR_MESSAGE);
                        } else {
                            pa = new JFrame("Add");

                            pay = new JButton("Yes");                          //确定取消按钮
                            pacan = new JButton("Cancel");
                            pay.addActionListener(new pAButtonListener());
                            pacan.addActionListener(new pAButtonListener());
                            JPanel yp = new JPanel();
                            JPanel cp = new JPanel();
                            JPanel bio = new JPanel();
                            yp.add(pay);
                            cp.add(pacan);
                            bio.setLayout(new GridLayout(1, 2));
                            bio.add(yp);
                            bio.add(cp);

                            JPanel content = new JPanel();
                            content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
                            content.add(pAddGUI(usValue));
                            content.add(bio);

                            JLabel space0 = new JLabel("                    ");
                            JLabel space1 = new JLabel("                    ");
                            pa.setLayout(new BorderLayout(5, 10));
                            pa.add(space0, BorderLayout.WEST);
                            pa.add(content, BorderLayout.CENTER);
                            pa.add(space1, BorderLayout.EAST);

                            pa.setSize(800, 350);
                            pa.setLocation(300, 200);
                            pa.setVisible(true);
                            pa.setResizable(false);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Please fill in the purchaseNo", "Add Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else if (jb3.isSelected()) {
                    pm = new JFrame("Search");

                    pmy = new JButton("Yes");
                    pmcan = new JButton("Cancel");
                    pmy.addActionListener(new pSButtonListener());
                    pmcan.addActionListener(new pSButtonListener());
                    JPanel pyes = new JPanel();
                    JPanel pcan = new JPanel();
                    JPanel bio = new JPanel();
                    pyes.add(pmy);
                    pcan.add(pmcan);
                    bio.setLayout(new GridLayout(1, 2));
                    bio.add(pyes);
                    bio.add(pcan);


                    JPanel content = new JPanel();
                    content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
                    content.add(oSearchGUI());
                    content.add(bio);

                    JLabel space0 = new JLabel("                    ");
                    JLabel space1 = new JLabel("                    ");
                    pm.setLayout(new BorderLayout(5, 10));
                    pm.add(space0, BorderLayout.WEST);
                    pm.add(content, BorderLayout.CENTER);
                    pm.add(space1, BorderLayout.EAST);

                    pm.setSize(800, 400);
                    pm.setLocation(300, 200);
                    pm.setVisible(true);
                    pm.setResizable(false);
                } else if (jb4.isSelected()) {
                    jp4.remove(s);
                    modelChange4(st, st);
                } else if (jb5.isSelected()) {
                    qm = new JFrame("Statics");
                    JLabel space0 = new JLabel("                    ");
                    JLabel space1 = new JLabel("                    ");
                    qm.setLayout(new BorderLayout(5, 10));
                    qm.add(space0, BorderLayout.WEST);
                    qm.add(qSearch(), BorderLayout.CENTER);
                    qm.add(space1, BorderLayout.EAST);
                    qm.setSize(1000, 600);
                    qm.setLocation(300, 200);
                    qm.setVisible(true);
                    qm.setResizable(false);
                } else {
                    JOptionPane.showInputDialog("please select the operation");
                }
            }
        });
    }


    class pAButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent ome) {
            if (ome.getSource() == pay) {    //modify the state of the item
                pAdd();
                pa.dispose();
            } else {
                pa.dispose();
            }

        }
    }

    class pSButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent ome) {
            if (ome.getSource() == pmy) {    //modify the state of the item
                oSearch();
                pm.dispose();
            } else {
                pm.dispose();
            }

        }
    }

    public void pAdd() {

        int year = TaY.getSelectedIndex() ;
        int mon = TaM.getSelectedIndex() ;
        int day = TaD.getSelectedIndex() ;
        int hour = TaH.getSelectedIndex();
        int minute = TaI.getSelectedIndex();
        int second = TaS.getSelectedIndex();
        int colo=colorP.getSelectedIndex();
        String Year = TaY.getItemAt(year);
        String Mon = TaM.getItemAt(mon);
        String Day = TaD.getItemAt(day);
        String Hour = TaH.getItemAt(hour);
        String Minute = TaI.getItemAt(minute);
        String Second = TaS.getItemAt(second);
        String time = "\'" + Year + "-" + Mon + "-" + Day + " " + Hour + ":" + Minute + ":" + Second + "\'";

        String oNo = pa1.getText();
        String pNo = pa2.getText();
        String num = pa3.getText();
        String col = colorP.getItemAt(colo);
        String cNo = pa5.getText();

        String tele = pa7.getText();
        String add = pa8.getText();
        String remark = pa9.getText();
        int index1 = stateBox.getSelectedIndex();
        String state = stateBox.getItemAt(index1);

        String sql = "INSERT INTO Orders_has_Product VALUES( \'" + oNo + "\' ,  \'" + pNo + "\', \'" + num + "\',  \'" + col + "\')";
        System.out.println(sql);
        String st2 = "SELECT * FROM Orders_has_Product";
        test.change(st2, sql);
        String sql_url = "jdbc:mysql://localhost:3306/e_piano_2";	//数据库路径（一般都是这样写），test是数据库名称
        String name = "root";		//用户名
        String password = "Extraord10";	//密码
        Connection conn;
        String sql2="SELECT ROUND(p.price*n.Num,2) AS AMOUNT FROM Product p, Orders_has_Product n WHERE p.pianoNo=n.Product_pianoNo AND p.pianoNo= "+pNo+" AND n.Orders_oNo= "+oNo;
        System.out.println(sql2);
        PreparedStatement preparedStatement = null;
        String amo;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");		//连接驱动
            conn = DriverManager.getConnection(sql_url, name, password);	//连接数据库
            preparedStatement = conn.prepareStatement(sql2);
            ResultSet result1 = preparedStatement.executeQuery(sql2);

            while (result1.next()) {
                amo=result1.getString("AMOUNT");
                String sql1 = "INSERT INTO Orders VALUES( \'" + oNo + "\' , " + time + ", \'" + amo + "\',  \'" + state + "\', \'" + cNo
                        + "\', '101', \'" + add + "\', \'" + tele + "\', \'" + remark + "\')";
                System.out.println(sql1);
                String st1 = "SELECT * FROM Orders";
                test.change(st1, sql1);
                jp4.remove(s);
                String st = "SELECT p.pname AS pianoName, ohp.Num, ROUND(p.price*ohp.Num,2) AS price, p.Store_storeNo AS storeNo, s.storeName, ohp.color, p.pfunction, p.parts, c.cName, o.state, o.oNo, o.dateAndTime, o.oTeleNo, o.oAddress" +
                        " FROM orders o, Orders_has_Product ohp,Product p,Customer c, Store s " +
                        " WHERE p.pianoNo = ohp.Product_pianoNo AND c.cNo =o.Customer_cNo AND ohp.Orders_oNo = o.oNo AND s.storeNo=p.Store_storeNo";
                modelChange4(st, st);
            }

            conn.close();
            preparedStatement.close();

        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("未成功加载驱动。");
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("未成功打开数据库。0000000000000");
            e.printStackTrace();
        }


    }

    public JPanel pAddGUI(String us) {
        JPanel oINFO = new JPanel();

        JLabel oNo = new JLabel("order No");
        JLabel pNo = new JLabel("pianoNo");
        JLabel num = new JLabel("number of piano");
        JLabel col = new JLabel("color of piano");
        JLabel cNo = new JLabel("customer No");
        JLabel state = new JLabel("order state");
        JLabel tel = new JLabel("telephone No");
        JLabel add = new JLabel("address");
        JLabel remark = new JLabel("remark");
        JLabel time = new JLabel("order time");
        String[] stateValue = {"ordered", "delivered", "completed", "canceled"};
        stateBox = new JComboBox<>(stateValue);//订单状态
        colorP =new JComboBox<>(colValue);
        pa1 = new JTextField(us);  //订单号
        pa1.setEditable(false);
        pa2 = new JTextField();  //钢琴号
        pa3 = new JTextField();  //钢琴数量
        pa5 = new JTextField();  //顾客号
        pa7 = new JTextField();  //电话号
        pa8 = new JTextField();  //地址
        pa9 = new JTextField();  //备注


        pa1.setMaximumSize(new Dimension(500, pa1.getMinimumSize().height));
        pa2.setMaximumSize(new Dimension(500, pa2.getMinimumSize().height));
        pa3.setMaximumSize(new Dimension(500, pa3.getMinimumSize().height));
        colorP.setMaximumSize(new Dimension(Integer.MAX_VALUE, colorP.getMinimumSize().height));
        pa5.setMaximumSize(new Dimension(500, pa5.getMinimumSize().height));
        stateBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, stateBox.getMinimumSize().height));

        pa7.setMaximumSize(new Dimension(500, pa7.getMinimumSize().height));
        pa8.setMaximumSize(new Dimension(500, pa8.getMinimumSize().height));
        pa9.setMaximumSize(new Dimension(500, pa9.getMinimumSize().height));


        JPanel p1 = new JPanel();    //添加复选框和文本框
        JPanel p2 = new JPanel();
        JPanel p3 = new JPanel();
        JPanel p4 = new JPanel();
        JPanel p5 = new JPanel();
        JPanel p6 = new JPanel();
        JPanel p7 = new JPanel();
        JPanel p8 = new JPanel();
        JPanel p9 = new JPanel();
        JPanel p10 = new JPanel();

        p1.setLayout(new BoxLayout(p1, BoxLayout.X_AXIS));
        p2.setLayout(new BoxLayout(p2, BoxLayout.X_AXIS));
        p3.setLayout(new BoxLayout(p3, BoxLayout.X_AXIS));
        p4.setLayout(new BoxLayout(p4, BoxLayout.X_AXIS));
        p5.setLayout(new BoxLayout(p5, BoxLayout.X_AXIS));
        p6.setLayout(new BoxLayout(p6, BoxLayout.X_AXIS));
        p7.setLayout(new BoxLayout(p7, BoxLayout.X_AXIS));
        p8.setLayout(new BoxLayout(p8, BoxLayout.X_AXIS));
        p9.setLayout(new BoxLayout(p9, BoxLayout.X_AXIS));
        p10.setLayout(new BoxLayout(p10, BoxLayout.X_AXIS));
        p1.add(oNo);
        p2.add(pNo);
        p3.add(num);
        p4.add(col);
        p5.add(cNo);
        p6.add(state);
        p7.add(tel);
        p8.add(add);
        p9.add(remark);
        p10.add(time);
        p1.add(Box.createHorizontalStrut(5));
        p2.add(Box.createHorizontalStrut(5));
        p3.add(Box.createHorizontalStrut(5));
        p4.add(Box.createHorizontalStrut(5));
        p5.add(Box.createHorizontalStrut(5));
        p6.add(Box.createHorizontalStrut(5));
        p7.add(Box.createHorizontalStrut(5));
        p8.add(Box.createHorizontalStrut(5));
        p9.add(Box.createHorizontalStrut(5));
        p10.add(Box.createHorizontalStrut(5));
        p1.add(pa1);
        p2.add(pa2);
        p3.add(pa3);
        p4.add(colorP);
        p5.add(pa5);
        p6.add(stateBox);
        p7.add(pa7);
        p8.add(pa8);
        p9.add(pa9);
        p10.add(defineTime());


        oINFO.setLayout(new GridLayout(0, 2));
        oINFO.add(p1);
        oINFO.add(p2);
        oINFO.add(p3);
        oINFO.add(p4);
        oINFO.add(p5);
        oINFO.add(p6);
        oINFO.add(p7);
        oINFO.add(p8);
        oINFO.add(p9);


        JPanel fin = new JPanel(new GridLayout(0, 1));
        fin.setLayout(new BoxLayout(fin, BoxLayout.Y_AXIS));
        fin.add(oINFO);
        fin.add(Box.createVerticalStrut(5));
        fin.add(p10);

        return fin;
    }

    public JPanel oSearchGUI() {
        colorO=new JComboBox<>();
        colorO.addItem("All");
        for(int i=0;i<colValue.length;i++){
            colorO.addItem(colValue[i]);
        }

        JPanel oINFO = new JPanel();
        JLabel note1 = new JLabel("Please select 1 or more condition");

        JLabel opn = new JLabel("Product name");
        JLabel opq = new JLabel("Quantity");
        JLabel opr = new JLabel("Price");
        JLabel opc = new JLabel("Color");
        JLabel opf = new JLabel("Function");
        JLabel opp = new JLabel("Part");
        JLabel ocn = new JLabel("Customer name");
        JLabel ostate = new JLabel("State");
        JLabel ono = new JLabel("Order No");
        startPur = new JRadioButton("Start time");
        endPur = new JRadioButton("End time");
        JLabel ote = new JLabel("Phone number");
        JLabel oad = new JLabel("Address");
        JLabel sNo = new JLabel("storeNo");
        JLabel sName = new JLabel("store name");
        JLabel type = new JLabel("type");


        opnText = new JTextField();  //产品名字
        opqText = new JTextField();  //产品数量
        oplText = new JTextField("Minimum");  //最低
        ophText = new JTextField("Maximum");  //最高

        ocnText = new JTextField();  //顾客昵称
        onoText = new JTextField();  //订单编号

        oteText = new JTextField();//电话
        oadText = new JTextField();//地址
        sNoText = new JTextField();//店铺号
        sNameText = new JTextField();//店铺名
        String[] typeValue = {"All", "ordered", "delivered", "completed", "canceled"};   //commodity service column


        oStateCmb2 = new JComboBox<String>(typeValue);   //订单状态
        ofunCmb = new JComboBox<String>(funValue2);       //产品功能
        opartCmb = new JComboBox<String>(parValue2);     //产品零件
        ptype = new JComboBox<>(typValue2); //产品种类


        opnText.setMaximumSize(new Dimension(500, opnText.getMinimumSize().height));
        opqText.setMaximumSize(new Dimension(500, opqText.getMinimumSize().height));
        oplText.setMaximumSize(new Dimension(500, oplText.getMinimumSize().height));
        ophText.setMaximumSize(new Dimension(500, ophText.getMinimumSize().height));
        colorO.setMaximumSize(new Dimension(Integer.MAX_VALUE, colorO.getMinimumSize().height));
        ocnText.setMaximumSize(new Dimension(500, ocnText.getMinimumSize().height));
        onoText.setMaximumSize(new Dimension(500, onoText.getMinimumSize().height));
        oteText.setMaximumSize(new Dimension(500, oteText.getMinimumSize().height));
        oadText.setMaximumSize(new Dimension(500, oadText.getMinimumSize().height));
        sNoText.setMaximumSize(new Dimension(500, sNoText.getMinimumSize().height));
        sNameText.setMaximumSize(new Dimension(500, sNameText.getMinimumSize().height));
        oStateCmb2.setMaximumSize(new Dimension(Integer.MAX_VALUE, oStateCmb2.getMinimumSize().height));//unit size
        ofunCmb.setMaximumSize(new Dimension(Integer.MAX_VALUE, ofunCmb.getMinimumSize().height));
        opartCmb.setMaximumSize(new Dimension(Integer.MAX_VALUE, opartCmb.getMinimumSize().height));//unit size
        startPur.setMaximumSize(new Dimension(500, startPur.getMinimumSize().height));
        endPur.setMaximumSize(new Dimension(500, endPur.getMinimumSize().height));
        ptype.setMaximumSize(new Dimension(500, ptype.getMinimumSize().height));

        JPanel opnPanel = new JPanel();    //添加复选框和文本框
        JPanel opqPanel = new JPanel();
        JPanel oprPanel = new JPanel();
        JPanel opcPanel = new JPanel();
        JPanel opfPanel = new JPanel();
        JPanel oppPanel = new JPanel();
        JPanel ocnPanel = new JPanel();
        JPanel onoPanel = new JPanel();
        JPanel starPanel = new JPanel();
        JPanel endPanel = new JPanel();
        JPanel ostatePanel = new JPanel();
        JPanel otePanel = new JPanel();
        JPanel oadPanel = new JPanel();
        JPanel sNoPanel = new JPanel();
        JPanel sNamePanel = new JPanel();
        JPanel pType = new JPanel();

        opnPanel.setLayout(new BoxLayout(opnPanel, BoxLayout.X_AXIS));
        opqPanel.setLayout(new BoxLayout(opqPanel, BoxLayout.X_AXIS));
        oprPanel.setLayout(new BoxLayout(oprPanel, BoxLayout.X_AXIS));
        opcPanel.setLayout(new BoxLayout(opcPanel, BoxLayout.X_AXIS));
        opfPanel.setLayout(new BoxLayout(opfPanel, BoxLayout.X_AXIS));
        oppPanel.setLayout(new BoxLayout(oppPanel, BoxLayout.X_AXIS));
        ocnPanel.setLayout(new BoxLayout(ocnPanel, BoxLayout.X_AXIS));
        onoPanel.setLayout(new BoxLayout(onoPanel, BoxLayout.X_AXIS));
        starPanel.setLayout(new BoxLayout(starPanel, BoxLayout.X_AXIS));
        endPanel.setLayout(new BoxLayout(endPanel, BoxLayout.X_AXIS));
        otePanel.setLayout(new BoxLayout(otePanel, BoxLayout.X_AXIS));
        oadPanel.setLayout(new BoxLayout(oadPanel, BoxLayout.X_AXIS));
        ostatePanel.setLayout(new BoxLayout(ostatePanel, BoxLayout.X_AXIS));
        sNoPanel.setLayout(new BoxLayout(sNoPanel, BoxLayout.X_AXIS));
        sNamePanel.setLayout(new BoxLayout(sNamePanel, BoxLayout.X_AXIS));
        pType.setLayout(new BoxLayout(pType, BoxLayout.X_AXIS));

        opnPanel.add(opn);
        opqPanel.add(opq);
        oprPanel.add(opr);
        opcPanel.add(opc);
        opfPanel.add(opf);
        oppPanel.add(opp);
        ocnPanel.add(ocn);
        ostatePanel.add(ostate);
        onoPanel.add(ono);
        starPanel.add(startPur);
        endPanel.add(endPur);
        otePanel.add(ote);
        oadPanel.add(oad);
        sNoPanel.add(sNo);
        sNamePanel.add(sName);
        pType.add(type);
        opnPanel.add(Box.createHorizontalStrut(5));
        opqPanel.add(Box.createHorizontalStrut(5));
        oprPanel.add(Box.createHorizontalStrut(5));
        opcPanel.add(Box.createHorizontalStrut(5));
        opfPanel.add(Box.createHorizontalStrut(5));
        oppPanel.add(Box.createHorizontalStrut(5));
        ocnPanel.add(Box.createHorizontalStrut(5));
        ostatePanel.add(Box.createHorizontalStrut(5));
        onoPanel.add(Box.createHorizontalStrut(5));
        starPanel.add(Box.createHorizontalStrut(5));
        endPanel.add(Box.createHorizontalStrut(5));
        otePanel.add(Box.createHorizontalStrut(5));
        oadPanel.add(Box.createHorizontalStrut(5));
        sNoPanel.add(Box.createHorizontalStrut(5));
        sNamePanel.add(Box.createHorizontalStrut(5));
        pType.add(Box.createHorizontalStrut(5));
        opnPanel.add(opnText);
        opqPanel.add(opqText);
        oprPanel.add(oplText);
        oprPanel.add(ophText);
        opcPanel.add(colorO);
        opfPanel.add(ofunCmb);
        oppPanel.add(opartCmb);
        ocnPanel.add(ocnText);
        ostatePanel.add(oStateCmb2);
        onoPanel.add(onoText);
        starPanel.add(defineTime());
        endPanel.add(defineEndTime());
        otePanel.add(oteText);
        oadPanel.add(oadText);
        sNoPanel.add(sNoText);
        sNamePanel.add(sNameText);
        pType.add(ptype);

        oINFO.setLayout(new GridLayout(0, 3));
        oINFO.add(opnPanel);
        oINFO.add(pType);
        oINFO.add(opqPanel);
        oINFO.add(oprPanel);
        oINFO.add(opcPanel);
        oINFO.add(opfPanel);
        oINFO.add(oppPanel);
        oINFO.add(ocnPanel);
        oINFO.add(ostatePanel);
        oINFO.add(onoPanel);
        oINFO.add(otePanel);
        oINFO.add(oadPanel);
        oINFO.add(sNoPanel);
        oINFO.add(sNamePanel);

        JPanel fin1 = new JPanel();
        fin1.setLayout(new BoxLayout(fin1, BoxLayout.Y_AXIS));
        fin1.add(oINFO);
        fin1.add(Box.createVerticalStrut(5));
        fin1.add(starPanel);
        fin1.add(endPanel);

        JPanel fin = new JPanel();
        fin.setLayout(new BoxLayout(fin, BoxLayout.Y_AXIS));
        fin.add(note1);
        fin.add(fin1);

        return fin;
    }

    public void oSearch() {
        int index2 = ofunCmb.getSelectedIndex();
        int index3 = opartCmb.getSelectedIndex();
        int index1 = oStateCmb2.getSelectedIndex();
        int index4 = ptype.getSelectedIndex();
        int colo=colorO.getSelectedIndex();
        String ofuStr = ofunCmb.getItemAt(index2);   //获得功能
        String opaStr = opartCmb.getItemAt(index3);   //获得零件
        String stateStr = oStateCmb2.getItemAt(index1);   //获得状态
        String pType = ptype.getItemAt(index4);//获得种类

        int indexY1 = TaY.getSelectedIndex();
        String sy = TaY.getItemAt(indexY1);
        int indexM1 = TaM.getSelectedIndex();
        String sm = TaM.getItemAt(indexM1);
        int indexD1 = TaD.getSelectedIndex();
        String sd = TaD.getItemAt(indexD1);
        int indexH1 = TaH.getSelectedIndex();
        String sh = TaH.getItemAt(indexH1);
        int indexI1 = TaI.getSelectedIndex();
        String si = TaI.getItemAt(indexI1);
        int indexS1 = TaS.getSelectedIndex();
        String ss = TaS.getItemAt(indexS1);
        String sTime = sy + "-" + sm + "-" + sd + " " + sh + ":" + si + ":" + ss;

        int indexY2 = EaY.getSelectedIndex();
        String ey = EaY.getItemAt(indexY2);
        int indexM2 = EaM.getSelectedIndex();
        String em = EaM.getItemAt(indexM2);
        int indexD2 = EaD.getSelectedIndex();
        String ed = EaD.getItemAt(indexD2);
        int indexH2 = EaH.getSelectedIndex();
        String eh = EaH.getItemAt(indexH2);
        int indexI2 = EaI.getSelectedIndex();
        String ei = EaI.getItemAt(indexI2);
        int indexS2 = EaS.getSelectedIndex();
        String es = EaS.getItemAt(indexS2);
        String eTime = ey + "-" + em + "-" + ed + " " + eh + ":" + ei + ":" + es;

        String opnStr = opnText.getText();
        String opqStr = opqText.getText();
        String oplStr = oplText.getText();
        String ophStr = ophText.getText();
        String opcStr = colorO.getItemAt(colo);
        String ocnStr = ocnText.getText();
        String onoStr = onoText.getText();
        String oteStr = oteText.getText();
        String oadStr = oadText.getText();
        String sNo = sNoText.getText();
        String sName = sNameText.getText();


        String[] sql = {"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};
        sql[0] = " AND p.pname LIKE \'%" + opnStr + "%\' ";
        sql[1] = " AND ohp.Num= \'" + opqStr + "\'";
        sql[2] = " AND p.price*ohp.Num  > \'" + oplStr + "\'";
        sql[3] = " AND p.price*ohp.Num  < \'" + ophStr + "\'";
        sql[4] = " AND ohp.color = \'" + opcStr + "\'";
        sql[5] = " AND p.pfunction= \'" + ofuStr + "\'";
        sql[6] = " AND p.parts = \'" + opaStr + "\'";
        sql[7] = " AND c.cName LIKE \'%" + ocnStr + "%\' ";
        sql[8] = " AND o.state = \'" + stateStr + "\'";
        sql[9] = " AND o.oNo LIKE '%" + onoStr + "%' ";
        sql[10] = " AND o.dateAndTime > \' " + sTime + "\'";
        sql[11] = " AND o.dateAndTime < \'" + eTime + "\'";
        sql[12] = " AND o.oTeleNo LIKE \'%" + oteStr + "%\'";
        sql[13] = " AND o.oAddress LIKE \'%" + oadStr + "%\' ";
        sql[14] = " AND p.Store_storeNo = \'" + sNo + "\'";
        sql[15] = " AND s.storeName LIKE \'%" + sName + "%\'";
        sql[16] = " AND p.ptype= \'" + pType + "\'";

        String osq1 = "SELECT p.pname AS pianoName, ohp.Num, ROUND(p.price*ohp.Num,2) AS price, p.ptype, p.Store_storeNo AS storeNo, s.storeName, ohp.color, p.pfunction, p.parts, c.cName, o.state, o.oNo, o.dateAndTime, o.oTeleNo, o.oAddress" +
                " FROM orders o, Orders_has_Product ohp,Product p,Customer c, Store s " +
                " WHERE p.pianoNo = ohp.Product_pianoNo AND c.cNo =o.Customer_cNo AND ohp.Orders_oNo = o.oNo AND s.storeNo=p.Store_storeNo";

        //添加筛选条件
        if (opnStr != null && opnStr.trim().length() != 0) {   //如果输入了产品名称
            osq1 = osq1 + sql[0];
        }
        if (opqStr != null && opqStr.trim().length() != 0) {
            osq1 = osq1 + sql[1];
        }
        if (oplStr != null && oplStr.trim().length() != 0 && (!oplStr.equals("Minimum"))) {
            osq1 = osq1 + sql[2];
        }
        if (ophStr != null && ophStr.trim().length() != 0 && (!ophStr.equals("Maximum"))) {
            osq1 = osq1 + sql[3];    //最低价、最高价必须都有有效输入
        }
        if (opcStr != null && opcStr.trim().length() != 0 && (!opcStr.equals("All"))) {
            osq1 = osq1 + sql[4];     //产品颜色
        }
        if (ofuStr != null && ofuStr.trim().length() != 0 && (!ofuStr.equals("All"))) {     //产品功能
            osq1 = osq1 + sql[5];
        }
        if (opaStr != null && opaStr.trim().length() != 0 && (!opaStr.equals("All"))) {    //产品零件
            osq1 = osq1 + sql[6];
        }
        if (ocnStr != null && ocnStr.trim().length() != 0) {   //顾客昵称
            osq1 = osq1 + sql[7];
        }
        if (stateStr != null && stateStr.trim().length() != 0 && (!stateStr.equals("All"))) {    //订单状态
            osq1 = osq1 + sql[8];
        }
        if (onoStr != null && onoStr.trim().length() != 0) {   //订单编号
            osq1 = osq1 + sql[9];
        }
        if (startPur.isSelected()) {
            osq1 = osq1 + sql[10];   //开始日期
        }
        if (endPur.isSelected()) {
            osq1 = osq1 + sql[11];  //结束时间
        }
        if (oteStr != null && oteStr.trim().length() != 0) {     //顾客电话
            osq1 = osq1 + sql[12];
        }
        if (oadStr != null && oadStr.trim().length() != 0) {   //顾客地址
            osq1 = osq1 + sql[13];
        }
        if (sNo != null && sNo.trim().length() != 0) {   //商家号
            osq1 = osq1 + sql[14];
        }
        if (sName != null && sName.trim().length() != 0) {   //商家名称
            osq1 = osq1 + sql[15];
        }
        if (pType != null && pType.trim().length() != 0 && (!pType.equals("All"))) {   //商品种类
            osq1 = osq1 + sql[16];
        }
        System.out.println(osq1);
        modelChange4(osq1, osq1);
    }

    public void modelChange5(String s1, String s2) {
        content1.remove(sc5);
        Vector rowData1 = test.getRows(s1, s2);
        Vector columnNames1 = test.getHead(s1, s2);
        tableModel5 = new DefaultTableModel(rowData1, columnNames1){
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table5 = new JTable(tableModel5);
        sc5 = new JScrollPane(table5);
        sc5.setPreferredSize(new Dimension(800, 400));
        content1.add(sc5);
    }


    public JPanel qSearch(){
        JPanel fin = new JPanel();

        String[] sqs = {"", "", "", "", "", "", "", "", ""};
        JLabel te = new JLabel("Please select one operation and fill in the information");
        sqs[0] = "Number and total amount of all orders for a period"; //某个时间段所有订单的单数和总金额  起止时间
        sqs[1] = "Order number and total amount of a certain category"; //查询某个类别商品的订单数和总金额  类别
        sqs[2] = "Top ten best-selling items in a certain period of time";  //某个时间段内，前十名热销的商品  起止时间
        sqs[3] = "All store's number and total amount of all orders for a period"; //按照商家统计某段时间的订单数和总金额  起止时间
        sqs[4] = "A certain store's number and total amount of all orders for a period"; //商家号，起止时间
        sqs[5] = "Top ten  store in a certain period"; //某个时间段内，销量排名前十名的商家   起止时间
        sqs[6] = "Top ten customers with orders in a certain period";//某个时间段内，成功下单金额前十名的用户  起止时间
        sqs[7] = "Statistics of order quantity and amount each month";//每个月的订单数量和金额情况统计   起止时间


        stat = new JComboBox<>(sqs);  //选择操作

        sname = new JTextField();  //商家号名字


        qfunc = new JComboBox<String>(funValue2);       //产品功能
        qparts = new JComboBox<String>(parValue2);     //产品零件
        qtype = new JComboBox<>(typValue2); //产品种类
        qfunc.addMouseListener(new Mouse());
        qparts.addMouseListener(new Mouse());
        qtype.addMouseListener(new Mouse());

        JLabel name = new JLabel("Store No");
        JLabel typ = new JLabel("Type");
        JLabel func = new JLabel("Function");
        JLabel part = new JLabel("Parts");
        JLabel stime = new JLabel("start time");
        JLabel etime = new JLabel("end time");
        qmy = new JButton("Process");
        qmy.addActionListener(new Statis());



        sname.setMaximumSize(new Dimension(500, sname.getMinimumSize().height));
        stat.setMaximumSize(new Dimension(Integer.MAX_VALUE, stat.getMinimumSize().height));
        qfunc.setMaximumSize(new Dimension(Integer.MAX_VALUE, qfunc.getMinimumSize().height));
        qparts.setMaximumSize(new Dimension(Integer.MAX_VALUE, qparts.getMinimumSize().height));//unit size
        qtype.setMaximumSize(new Dimension(Integer.MAX_VALUE, qtype.getMinimumSize().height));
        qmy.setMaximumSize(new Dimension(Integer.MAX_VALUE, qmy.getMinimumSize().height));

        JPanel opnPanel = new JPanel();    //添加复选框和文本框
        JPanel opqPanel = new JPanel();
        JPanel oprPanel = new JPanel();
        JPanel opcPanel = new JPanel();
        JPanel opfPanel = new JPanel();
        JPanel opePanel = new JPanel();


        opnPanel.setLayout(new BoxLayout(opnPanel, BoxLayout.X_AXIS));
        opqPanel.setLayout(new BoxLayout(opqPanel, BoxLayout.X_AXIS));
        oprPanel.setLayout(new BoxLayout(oprPanel, BoxLayout.X_AXIS));
        opcPanel.setLayout(new BoxLayout(opcPanel, BoxLayout.X_AXIS));
        opfPanel.setLayout(new BoxLayout(opfPanel, BoxLayout.X_AXIS));
        opePanel.setLayout(new BoxLayout(opePanel, BoxLayout.X_AXIS));


        opnPanel.add(name);
        opqPanel.add(typ);
        oprPanel.add(func);
        opcPanel.add(part);
        opfPanel.add(stime);
        opePanel.add(etime);


        opnPanel.add(Box.createHorizontalStrut(5));
        opqPanel.add(Box.createHorizontalStrut(5));
        oprPanel.add(Box.createHorizontalStrut(5));
        opcPanel.add(Box.createHorizontalStrut(5));
        opfPanel.add(Box.createHorizontalStrut(5));
        opePanel.add(Box.createHorizontalStrut(5));

        opnPanel.add(sname);
        opqPanel.add(qtype);
        oprPanel.add(qfunc);
        opcPanel.add(qparts);
        opfPanel.add(defineTime());
        opePanel.add(defineEndTime());

        JPanel f1 = new JPanel(new GridLayout(0, 4));
        f1.add(opnPanel);
        f1.add(opqPanel);
        f1.add(oprPanel);
        f1.add(opcPanel);

        JPanel f2 = new JPanel();
        f2.setLayout(new BoxLayout(f2, BoxLayout.X_AXIS));
        f2.add(stat);
        f2.add(qmy);


        //右边选择和时间
        JPanel fin1 = new JPanel();
        fin1.setLayout(new BoxLayout(fin1, BoxLayout.Y_AXIS));
        fin1.add(Box.createVerticalStrut(5));

        fin1.add(f2);
        fin1.add(f1);
        fin1.add(opfPanel);
        fin1.add(opePanel);


        //展示信息
        try {
            Connection conn1 = connect();
            String st = "SELECT p.pname AS pianoName, ohp.Num, ROUND(p.price*ohp.Num,2) AS price, p.Store_storeNo AS storeNo, s.storeName, ohp.color, p.pfunction, p.parts, c.cName, o.state, o.oNo, o.dateAndTime, o.oTeleNo, o.oAddress" +
                    " FROM orders o, Orders_has_Product ohp,Product p,Customer c, Store s " +
                    " WHERE p.pianoNo = ohp.Product_pianoNo AND c.cNo =o.Customer_cNo AND ohp.Orders_oNo = o.oNo AND s.storeNo=p.Store_storeNo";
            PreparedStatement stmt = conn1.prepareStatement(st, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet res = stmt.executeQuery();
            table5= new JTable(Statics(res, conn1));   //之后只要更新table5就可以了
            sc5 = new JScrollPane(table5);
            sc5.setPreferredSize(new Dimension(800, 400));

            content1 = new JPanel();
            content1.setLayout(new BoxLayout(content1, BoxLayout.Y_AXIS));
            content1.add(fin1);
            content1.add(sc5);


            fin.add(te);
            fin.add(content1);
            return fin;
        }catch (SQLException e) {
            e.printStackTrace();
        }

        return fin;

    }
    public DefaultTableModel Statics(ResultSet rs, Connection conn) {
        try {
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][12];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("pianoName");
                comm[count][1] = rs.getString("ohp.Num");
                comm[count][2] = rs.getString("price");
                comm[count][3] = rs.getString("storeName");
                comm[count][4] = rs.getString("ohp.color");
                comm[count][5] = rs.getString("p.pfunction");
                comm[count][6] = rs.getString("p.parts");
                comm[count][7] = rs.getString("c.cName");
                comm[count][8] = rs.getString("o.state");
                comm[count][9] = rs.getString("o.dateAndTime");
                comm[count][10] = rs.getString("o.oTeleNo");
                comm[count][11] = rs.getString("o.oAddress");
                count++;
            }
            conn.close();

            String[] title = {"Product name", "Quantity", "Price", "Store name", "Color", "Function", "Parts","Customer name", "State",  "Date", "Phone number", "Address"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            return tableModel;

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;
    }
    public DefaultTableModel Statics0(ResultSet rs, Connection conn) {

        try {
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][2];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("SUM");
                comm[count][1] = rs.getString("OderNo");
                count++;
            }
            conn.close();

            String[] title = {"SUM", "OderNo"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            String c = comm[0][1];
            if (  c.equals("0") ) {
                JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                        JOptionPane.ERROR_MESSAGE);
                tableModel.setRowCount( 0 );
            }
            return tableModel;

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;
    }

    public DefaultTableModel Statics1(ResultSet rs, Connection conn) {
        //查询type
        try {
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][3];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("p.ptype");
                comm[count][1] = rs.getString("SUM");
                comm[count][2] = rs.getString("OderNumber");
                count++;
            }
            conn.close();

            String[] title = {"Type","SUM","OderNumber"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            String c = comm[0][2];
            if (  c.equals("0") ) {
                JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                        JOptionPane.ERROR_MESSAGE);
                tableModel.setRowCount( 0 );
            }
            return tableModel;

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;
    }

    public DefaultTableModel Statics2(ResultSet rs, Connection conn) {
        //查询功能
        try {
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][3];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("p.pfunction");
                comm[count][1] = rs.getString("SUM");
                comm[count][2] = rs.getString("OderNumber");
                count++;
            }
            conn.close();

            String[] title = {"Function","SUM", "OderNumber"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            return tableModel;

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;
    }

    public DefaultTableModel Statics3(ResultSet rs, Connection conn) {
        //查询零件
        try {
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][3];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("p.parts");
                comm[count][1] = rs.getString("SUM");
                comm[count][2] = rs.getString("OderNumber");
                count++;
            }
            conn.close();

            String[] title = {"Parts","SUM", "OderNumber"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            return tableModel;

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;
    }
    public DefaultTableModel Statics4(ResultSet rs, Connection conn) {
        //热销前十商品
        try {
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][4];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("p.pianoNo");
                comm[count][1] = rs.getString("p.pname");
                comm[count][2] = rs.getString("totalNo");
                comm[count][3] = rs.getString("Amount");
                count++;
            }
            conn.close();

            String[] title = {"Product No", "Product name", "TotalNo","Total Amount"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            return tableModel;

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;
    }
    public DefaultTableModel Statics5(ResultSet rs, Connection conn) {
        //所有商家订单总数，订单总金额
        try {
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][4];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("s.storeNO");
                comm[count][1] = rs.getString("s.storeName");
                comm[count][2] = rs.getString("OrderNumber");
                comm[count][3] = rs.getString("totalAmount");
                count++;
            }
            conn.close();

            String[] title = {"Store No", "Store name", "OrderNumber","TotalAmount"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            String c = comm[0][3];
            if (  c.equals("0") ) {
                JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                        JOptionPane.ERROR_MESSAGE);
            }
            return tableModel;

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;

    }
    public DefaultTableModel Statics6(ResultSet rs, Connection conn) {
        //某个商家订单总数，总金额

        try {
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][4];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("s.storeNO");
                comm[count][1] = rs.getString("s.storeName");
                comm[count][2] = rs.getString("OrderNumber");
                comm[count][3] = rs.getString("totalAmount");
                count++;
            }
            conn.close();

            String[] title = {"Store No", "Store name", "OrderNumber","TotalAmount"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            String c = comm[0][2];
            if (  c.equals("0") ) {
                JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                        JOptionPane.ERROR_MESSAGE);
            }
            return tableModel;

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;

    }
    public DefaultTableModel Statics7(ResultSet rs, Connection conn) {
        //某个时间段内，销量排名前十名的商家

        try {
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][4];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("s.storeNO");
                comm[count][1] = rs.getString("s.storeName");
                comm[count][2] = rs.getString("OrderNumber");
                comm[count][3] = rs.getString("totalAmount");
                count++;
            }
            conn.close();

            String[] title = {"Store No", "Store name", "OrderNumber","TotalAmount"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            String c = comm[0][2];
            if (  c.equals("0") ) {
                JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                        JOptionPane.ERROR_MESSAGE);
            }
            return tableModel;

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;

    }
    public DefaultTableModel Statics8(ResultSet rs, Connection conn) {
        //某个时间段内，成功下单金额前十名的用户

        try {
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][3];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("c.cNo");
                comm[count][1] = rs.getString("c.cName");
                comm[count][2] = rs.getString("Amount");
                count++;
            }
            conn.close();

            String[] title = {"Customer No", "Customer name", "Amount"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            String c = comm[0][2];
            if (  c.equals("0") ) {
                JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                        JOptionPane.ERROR_MESSAGE);
            }
            return tableModel;

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;
    }
    public DefaultTableModel Statics9(ResultSet rs, Connection conn) {
        //每个月的订单数量和金额情况统计
        try {
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][4];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("YEAR(dateAndTime)");
                comm[count][1] = rs.getString("MONTH(dateAndTime)");
                comm[count][2] = rs.getString("round(SUM(Amount),2)");
                comm[count][3] = rs.getString("COUNT(oNo)");
                count++;
            }
            conn.close();

            String[] title = {"YEAR(dateAndTime)", "MONTH(dateAndTime)", "SUM(Amount)","COUNT(oNo)"};
            //使表格不可编辑
            DefaultTableModel tableModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            String c = comm[0][3];
            if (  c.equals("0") ) {
                JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                        JOptionPane.ERROR_MESSAGE);
            }
            return tableModel;

        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        return tableModel;
    }




    class Statis implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            qfunc.setEnabled(true);
            qparts.setEnabled(true);
            qtype.setEnabled(true);
            int index1 = qtype.getSelectedIndex();
            int index2 = qfunc.getSelectedIndex();
            int index3 = qparts.getSelectedIndex();
            int index4 = TaY.getSelectedIndex();
            int index5 = TaM.getSelectedIndex();
            int index6 = TaD.getSelectedIndex();
            int index7 = TaH.getSelectedIndex();
            int index8 = TaI.getSelectedIndex();
            int index9 = TaS.getSelectedIndex();
            int index10 = EaY.getSelectedIndex();
            int index11 = EaM.getSelectedIndex();
            int index12 = EaD.getSelectedIndex();
            int index13 = EaH.getSelectedIndex();
            int index14 = EaI.getSelectedIndex();
            int index15 = EaS.getSelectedIndex();

            String type = qtype.getItemAt(index1);   //获得种类
            String fun = qfunc.getItemAt(index2);   //获得功能
            String par = qparts.getItemAt(index3);   //获得零件

            String sy = TaY.getItemAt(index4);//  获得开始时间
            String sm = TaM.getItemAt(index5);
            String sd = TaD.getItemAt(index6);
            String sh = TaH.getItemAt(index7);
            String si = TaI.getItemAt(index8);
            String ss = TaS.getItemAt(index9);

            String ey = EaY.getItemAt(index10);//  获得结束时间
            String em = EaM.getItemAt(index11);
            String ed = EaD.getItemAt(index12);
            String eh = EaH.getItemAt(index13);
            String ei = EaI.getItemAt(index14);
            String es = EaS.getItemAt(index15);

            String sTime = sy + "-" + sm + "-" + sd + " " + sh + ":" + si + ":" + ss;
            String eTime = ey + "-" + em + "-" + ed + " " + eh + ":" + ei + ":" + es;

            String name = sname.getText();
            String run = "";


            String[] sql = {"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};
            //所有订单数和总金额
            sql[0] = "SELECT round(SUM(Amount),2) AS SUM,COUNT(oNo) AS OderNo " +
                    "FROM Orders " +
                    "WHERE dateAndTime BETWEEN \'" + sTime + "\' AND \'" + eTime + "\'";
            //查询类别
            sql[1] = "SELECT p.ptype, round(SUM(ohp.num*p.price),2) AS SUM, COUNT(o.oNo) AS OderNumber "
                    + " FROM Orders_has_Product ohp, Product p, Orders o " +
                    " Where o.oNo=ohp.Orders_oNo AND ohp.Product_pianoNo = p.pianoNo  AND p.ptype= \'" + type + "\' GROUP BY p.ptype";
            sql[2] = "SELECT p.pfunction, round(SUM(ohp.num*p.price),2) AS SUM, COUNT(o.oNo) AS OderNumber "
                    + " FROM Orders_has_Product ohp, Product p, Orders o " +
                    " Where o.oNo=ohp.Orders_oNo AND ohp.Product_pianoNo = p.pianoNo  AND p.pfunction= \'" + fun + "\' GROUP BY p.pfunction";
            sql[3] = "SELECT p.parts, round(SUM(ohp.num*p.price),2) AS SUM, COUNT(o.oNo) AS OderNumber "
                    + " FROM Orders_has_Product ohp, Product p, Orders o " +
                    " Where o.oNo=ohp.Orders_oNo AND ohp.Product_pianoNo = p.pianoNo  AND p.parts= \'" + par + "\' GROUP BY p.parts";


            //热销前十商品
            sql[4] = "SELECT p.pianoNo, p.pname, COUNT(ohp.Orders_oNo) AS totalNo, ROUND(SUM(ohp.num*p.price),2) AS Amount " +
                    "FROM Product p, Orders_has_Product ohp, Orders o " +
                    "WHERE ohp.Product_pianoNo=p.pianoNo AND o.oNo=ohp.Orders_oNo AND o.dateAndTime BETWEEN \'" + sTime + "\' AND \'" + eTime +
                    "\' GROUP BY p.pianoNo " +
                    "ORDER BY COUNT(ohp.Orders_oNo) DESC,ROUND(SUM(ohp.num*p.price),2) DESC LIMIT 10";
            //所有商家订单总数，订单总金额
            sql[5] = "SELECT s.storeNO, s.storeName, COUNT(o.oNo) AS OrderNumber, round(SUM(o.Amount),2) AS totalAmount"
                    + " FROM Orders o, Store s, Product p, Orders_has_Product ohp"
                    + " WHERE o.oNo=ohp.Orders_oNo AND ohp.Product_pianoNo=p.pianoNo AND p.Store_storeNo=s.storeNo AND o.dateAndTime BETWEEN \'" + sTime + "\' AND \'" + eTime
                    + "\' GROUP BY s.storeNO ORDER BY COUNT(o.oNo) DESC,ROUND(SUM(o.Amount),2) DESC";
            //某个商家订单总数，总金额
            sql[6] = "SELECT s.storeNO, s.storeName, COUNT(o.oNo) AS OrderNumber, round(SUM(ohp.num*p.price),2) AS totalAmount"
                    + " FROM Orders o, Store s, Product p, Orders_has_Product ohp"
                    + " WHERE o.oNo=ohp.Orders_oNo AND ohp.Product_pianoNo=p.pianoNo AND p.Store_storeNo=s.storeNo AND o.dateAndTime BETWEEN \'"
                    + sTime + "\' AND \'" + eTime
                    + "\' GROUP BY s.storeNO HAVING s.storeNo= \'" + name + "\'";
            //某个时间段内，销量排名前十名的商家
            sql[7] = "SELECT s.storeNO, s.storeName, COUNT(o.oNo) AS OrderNumber, round(SUM(ohp.num*p.price),2) AS totalAmount"
                    + " FROM Orders o, Store s, Product p, Orders_has_Product ohp"
                    + " WHERE o.oNo=ohp.Orders_oNo AND ohp.Product_pianoNo=p.pianoNo AND p.Store_storeNo=s.storeNo AND o.dateAndTime BETWEEN \'" + sTime + "\' AND \'" + eTime
                    + "\' GROUP BY s.storeNO" +
                    " ORDER BY COUNT(o.oNo) DESC, round(SUM(ohp.num*p.price),2) DESC LIMIT 10";
            //某个时间段内，成功下单金额前十名的用户
            sql[8] = "SELECT c.cNo, c.cName, round(SUM(o.Amount),2) AS Amount"
                    + " FROM Customer c, Orders o"
                    + " WHERE o.Customer_cNo=c.cNo AND o.dateAndTime BETWEEN \'" + sTime + "\' AND \'" + eTime
                    + "\' GROUP BY c.cNo " +
                    " ORDER BY SUM(o.Amount) DESC, round(SUM(o.Amount),2) DESC LIMIT 10";

            //每个月的订单数量和金额情况统计
            sql[9] = "SELECT YEAR(dateAndTime), MONTH(dateAndTime), round(SUM(Amount),2), COUNT(oNo)"
                    + " FROM Orders"
                    + " WHERE dateAndTime BETWEEN \'" + sTime + "\' and \'" + eTime
                    + "\' Group by YEAR(dateAndTime),  MONTH(dateAndTime) ORDER BY  YEAR(dateAndTime),  MONTH(dateAndTime)";

            int sele = stat.getSelectedIndex();
            String sel = stat.getItemAt(sele);
            if (sel.equals(stat.getItemAt(0))) {
                try{

                    Connection conn = connect();
                    PreparedStatement stmt = conn.prepareStatement(sql[0],ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    ResultSet res = stmt.executeQuery();
                    if (  res.isBeforeFirst() ){
                        table5.setModel(Statics0(res,conn));
                    }else {
                        JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                JOptionPane.ERROR_MESSAGE);
                    }


                } catch (SQLException e0) {
                    e0.printStackTrace();
                }
            }
            if (sel.equals(stat.getItemAt(1))) {

                if (type != null && type.trim().length() != 0 && (!type.equals("All"))) {
                    try{

                        Connection conn = connect();
                        PreparedStatement stmt = conn.prepareStatement(sql[1],ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                        ResultSet res1 = stmt.executeQuery();
                        if (  res1.isBeforeFirst() ){
                            table5.setModel(Statics1(res1,conn));
                        }else {
                            JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                    JOptionPane.ERROR_MESSAGE);
                        }

                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }

                }
                if (fun != null && fun.trim().length() != 0 && (!fun.equals("All"))) {
                    try{

                        Connection conn = connect();
                        PreparedStatement stmt = conn.prepareStatement(sql[2],ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                        ResultSet res2 = stmt.executeQuery();
                        if (  res2.isBeforeFirst() ){
                            table5.setModel(Statics2(res2,conn));
                        }else {
                            JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                    JOptionPane.ERROR_MESSAGE);
                        }

                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                }
                if (par != null && par.trim().length() != 0 && (!par.equals("All"))) {
                    try{

                        Connection conn = connect();
                        PreparedStatement stmt = conn.prepareStatement(sql[3],ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                        ResultSet res3 = stmt.executeQuery();
                        if (  res3.isBeforeFirst() ){
                            table5.setModel(Statics3(res3,conn));
                        }else {
                            JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                    JOptionPane.ERROR_MESSAGE);
                        }

                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                }
            }
            if (sel.equals(stat.getItemAt(2))) {
                try{

                    Connection conn = connect();
                    PreparedStatement stmt = conn.prepareStatement(sql[4],ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    ResultSet res = stmt.executeQuery();
                    if (  res.isBeforeFirst() ){
                        table5.setModel(Statics4(res,conn));

                    }else {
                        JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                JOptionPane.ERROR_MESSAGE);
                    }
                    new TopStore("Order Statics of the Top10 Product ",sql[4],"p.pianoNo","totalNo");

                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
            if (sel.equals(stat.getItemAt(3))) {
                try{

                    Connection conn = connect();
                    PreparedStatement stmt = conn.prepareStatement(sql[5],ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    ResultSet res = stmt.executeQuery();
                    if (  res.isBeforeFirst() ){
                        table5.setModel(Statics5(res,conn));
                    }else {
                        JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                JOptionPane.ERROR_MESSAGE);
                    }

                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
            if (sel.equals(stat.getItemAt(4))) {
                try{

                    Connection conn = connect();
                    PreparedStatement stmt = conn.prepareStatement(sql[6],ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    ResultSet res = stmt.executeQuery();
                    if (  res.isBeforeFirst() ){
                        table5.setModel(Statics6(res,conn));

                    }else {
                        JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                JOptionPane.ERROR_MESSAGE);
                    }

                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
            if (sel.equals(stat.getItemAt(5))) {
                try{

                    Connection conn = connect();
                    PreparedStatement stmt = conn.prepareStatement(sql[7],ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    ResultSet res = stmt.executeQuery();
                    if (  res.isBeforeFirst() ){
                        table5.setModel(Statics7(res,conn));
                    }else {
                        JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                JOptionPane.ERROR_MESSAGE);
                    }
                    new TopStore("Order Statics of the Top10 Store ",sql[7],"s.storeNo","OrderNumber");

                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
            if (sel.equals(stat.getItemAt(6))) {
                try{
                    Connection conn = connect();
                    PreparedStatement stmt = conn.prepareStatement(sql[8],ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    ResultSet res = stmt.executeQuery();
                    if (  res.isBeforeFirst() ){
                        table5.setModel(Statics8(res,conn));
                    }else {
                        JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                JOptionPane.ERROR_MESSAGE);
                    }
                    new TopStore("Order Statics of the Top10 Store ",sql[8],"c.cName","Amount");

                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
            if (sel.equals(stat.getItemAt(7))) {
                try{

                    Connection conn = connect();
                    PreparedStatement stmt = conn.prepareStatement(sql[9],ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    ResultSet res = stmt.executeQuery();
                    if (  res.isBeforeFirst() ){
                        table5.setModel(Statics9(res,conn));
                    }else {
                        JOptionPane.showMessageDialog(null, "Data not found!", "Tips",
                                JOptionPane.ERROR_MESSAGE);
                    }


                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
                String ca1 = "SELECT YEAR(dateAndTime), MONTH(dateAndTime), COUNT(oNo)"
                        + " FROM Orders"
                        + " WHERE dateAndTime BETWEEN \'" + sTime + "\' and \'" + eTime
                        + "\' Group by YEAR(dateAndTime),  MONTH(dateAndTime) ORDER BY  YEAR(dateAndTime),  MONTH(dateAndTime)";
                String ca2 = "SELECT YEAR(dateAndTime), MONTH(dateAndTime), SUM(Amount)"
                        + " FROM Orders"
                        + " WHERE dateAndTime BETWEEN \'" + sTime + "\' and \'" + eTime
                        + "\' Group by YEAR(dateAndTime),  MONTH(dateAndTime) ORDER BY  YEAR(dateAndTime),  MONTH(dateAndTime)";
                try{

                    Connection conn = connect();
                    PreparedStatement stmt1 = conn.prepareStatement(ca1,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    PreparedStatement stmt2 = conn.prepareStatement(ca2,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    ResultSet res1 = stmt1.executeQuery();
                    ResultSet res2 = stmt2.executeQuery();
                    if (  res1.isBeforeFirst() ){
                        new ChartFigure("Statics of order quantity each month ", ca1);
                    }
                    if (  res2.isBeforeFirst() ){
                        new ChartF("Statics of order amount each month", ca2);
                    }


                } catch (SQLException e1) {
                    e1.printStackTrace();
                }

            }

        }

    }
    class Mouse implements MouseListener {
        public void mouseEntered(MouseEvent e){ }
        public void mouseExited(MouseEvent e){ }
        public void mouseClicked(MouseEvent e){ }
        public void mousePressed(MouseEvent e){
            //点击其中一个其它两个为“All"（e.g.点击type,fun & par为“All")

            if(e.getSource()== qfunc){
                qparts.setSelectedIndex(0);
                qtype.setSelectedIndex(0);
            }else if (e.getSource() == qparts){
                qfunc.setSelectedIndex(0);
                qtype.setSelectedIndex(0);
            }else{
                qfunc.setSelectedIndex(0);
                qparts.setSelectedIndex(0);
            }

        }
        public void mouseDragged(MouseEvent e){}
        public void mouseReleased(MouseEvent e){ }

    }
    public JPanel cGUI(){

        JPanel jp= new JPanel();
        JPanel csPanel = new JPanel();
        JPanel cLeft = new JPanel();        //把csPanel放在cLeft的borderLayout。CENTER


        JLabel clb = new JLabel("Please select the operation");
        cadd = new JRadioButton("Add category");
        cmod = new JRadioButton("Modify category");
        csee = new JRadioButton("Seek category");
        call = new JRadioButton("Show all category");
        cbg = new ButtonGroup();
        cbg.add(cadd);
        cbg.add(cmod);
        cbg.add(csee);
        cbg.add(call);


        //按钮
        JPanel csbp= new JPanel();
        cButton = new JButton("Process");
        cButton.addActionListener(new cButtonListener());
        csbp.add(cButton);


        csPanel.setLayout(new GridLayout(6,1));
        csPanel.add(clb);
        csPanel.add(cadd);
        csPanel.add(cmod);
        csPanel.add(csee);
        csPanel.add(call);
        csPanel.add(csbp);

        cLeft.setLayout(new BorderLayout());
        cLeft.add(csPanel,BorderLayout.CENTER);


        /**
         * 展示商品编号，名字和类别信息
         */
        try{    //将数据库信息放到JTable中

            Connection conn = connect();

            String csql = "SELECT p.ptype,p.pfunction,p.parts, pn.color" +
                    " FROM Product p,productNo pn" +
                    " WHERE p.pianoNo = pn.Product_pianoNo GROUP BY p.ptype,p.pfunction,p.parts, pn.color";
            PreparedStatement stmt = conn.prepareStatement(csql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet res = stmt.executeQuery();


            cTable= new JTable(csetTable(res,conn));
            cTable.setPreferredScrollableViewportSize(new Dimension(800,200));
            JScrollPane jScrollPane = new JScrollPane(cTable,
                    ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

            jp.setLayout(new BorderLayout(20,15));    //add component on jp1
            jp.add(cLeft,BorderLayout.WEST);
            jp.add(jScrollPane,BorderLayout.CENTER);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jp;
    }
    public DefaultTableModel csetTable(ResultSet rs, Connection conn){
        try{
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][6];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("ptype");
                comm[count][1] = rs.getString("p.pfunction");
                comm[count][2] = rs.getString("p.parts");
                comm[count][3] = rs.getString("pn.color");

                count++;
            }
            conn.close();

            String[] title = {"Type","Function","Parts","Color"};
            //使表格不可编辑
            cModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            return cModel;

        }catch (SQLException e2) {
            e2.printStackTrace();
        }
        return cModel;
    }


    public JPanel cAddGUI(){


        JLabel typlb1 = new JLabel("Type");
        JLabel collb1 = new JLabel("Color");
        JLabel funlb1= new JLabel("Function");
        JLabel parlb1= new JLabel("Parts");



        typText1 = new JTextField();
        colText1 = new JTextField();
        funText1 = new JTextField();
        parText1 = new JTextField();


        typText1.setMaximumSize(new Dimension(500, typText1.getMinimumSize().height));
        colText1.setMaximumSize(new Dimension(500, colText1.getMinimumSize().height));
        funText1.setMaximumSize(new Dimension(500, funText1.getMinimumSize().height));
        parText1.setMaximumSize(new Dimension(500, parText1.getMinimumSize().height));



        JPanel  typpl1= new JPanel();
        JPanel  colpl1= new JPanel();
        JPanel  funpl1= new JPanel();
        JPanel  parpl1= new JPanel();


        typpl1.setLayout(new BoxLayout(typpl1, BoxLayout.X_AXIS));
        colpl1.setLayout(new BoxLayout(colpl1, BoxLayout.X_AXIS));
        funpl1.setLayout(new BoxLayout(funpl1, BoxLayout.X_AXIS));
        parpl1.setLayout(new BoxLayout(parpl1, BoxLayout.X_AXIS));



        typpl1.add(typlb1);
        colpl1.add(collb1);
        funpl1.add(funlb1);
        parpl1.add(parlb1);
        typpl1.add(Box.createHorizontalStrut(5));
        colpl1.add(Box.createHorizontalStrut(5));
        funpl1.add(Box.createHorizontalStrut(5));
        parpl1.add(Box.createHorizontalStrut(5));
        typpl1.add(typText1);
        colpl1.add(colText1);
        funpl1.add(funText1);
        parpl1.add(parText1);


        JPanel pcontent = new JPanel();
        pcontent.setLayout(new GridLayout(2,2)); //component in center
        pcontent.add(typpl1);
        pcontent.add(colpl1);
        pcontent.add(funpl1);
        pcontent.add(parpl1);
        return pcontent;

    }
    public JPanel cModifyGUI(){
        JLabel typlb2 = new JLabel("Type");
        JLabel collb2 = new JLabel("Color");
        JLabel funlb2= new JLabel("Function");
        JLabel parlb2= new JLabel("Parts");
        JLabel typlb3 = new JLabel("Change to");
        JLabel collb3 = new JLabel("Change to");
        JLabel funlb3= new JLabel("Change to");
        JLabel parlb3= new JLabel("Change to");



        typCb2 = new JComboBox<String>(typValue);
        colCb2 = new JComboBox<String>(colValue);
        funCb2= new JComboBox<String>(funValue);
        parCb2= new JComboBox<String>(parValue);
        typText2 = new JTextField();
        colText2 = new JTextField();
        funText2 = new JTextField();
        parText2 = new JTextField();


        typCb2.setMaximumSize(new Dimension(Integer.MAX_VALUE,typCb2.getMinimumSize().height));//unit size
        colCb2.setMaximumSize(new Dimension(Integer.MAX_VALUE,colCb2.getMinimumSize().height));
        funCb2.setMaximumSize(new Dimension(Integer.MAX_VALUE,funCb2.getMinimumSize().height));
        parCb2.setMaximumSize(new Dimension(Integer.MAX_VALUE,parCb2.getMinimumSize().height));
        typText2.setMaximumSize(new Dimension(500,  typText2.getMinimumSize().height));
        colText2.setMaximumSize(new Dimension(500, colText2.getMinimumSize().height));
        funText2.setMaximumSize(new Dimension(500, funText2.getMinimumSize().height));
        parText2.setMaximumSize(new Dimension(500, parText2.getMinimumSize().height));



        JPanel  typpl2= new JPanel();
        JPanel  colpl2= new JPanel();
        JPanel  funpl2= new JPanel();
        JPanel  parpl2= new JPanel();
        JPanel  typpl3= new JPanel();
        JPanel  colpl3= new JPanel();
        JPanel  funpl3= new JPanel();
        JPanel  parpl3= new JPanel();


        typpl2.setLayout(new BoxLayout(typpl2, BoxLayout.X_AXIS));
        colpl2.setLayout(new BoxLayout(colpl2, BoxLayout.X_AXIS));
        funpl2.setLayout(new BoxLayout(funpl2, BoxLayout.X_AXIS));
        parpl2.setLayout(new BoxLayout(parpl2, BoxLayout.X_AXIS));
        typpl3.setLayout(new BoxLayout(typpl3, BoxLayout.X_AXIS));
        colpl3.setLayout(new BoxLayout(colpl3, BoxLayout.X_AXIS));
        funpl3.setLayout(new BoxLayout(funpl3, BoxLayout.X_AXIS));
        parpl3.setLayout(new BoxLayout(parpl3, BoxLayout.X_AXIS));


        typpl2.add(typlb2);
        colpl2.add(collb2);
        funpl2.add(funlb2);
        parpl2.add(parlb2);
        typpl3.add(typlb3);
        colpl3.add(collb3);
        funpl3.add(funlb3);
        parpl3.add(parlb3);
        typpl2.add(Box.createHorizontalStrut(5));
        colpl2.add(Box.createHorizontalStrut(5));
        funpl2.add(Box.createHorizontalStrut(5));
        parpl2.add(Box.createHorizontalStrut(5));
        typpl3.add(Box.createHorizontalStrut(5));
        colpl3.add(Box.createHorizontalStrut(5));
        funpl3.add(Box.createHorizontalStrut(5));
        parpl3.add(Box.createHorizontalStrut(5));
        typpl2.add(typCb2);
        colpl2.add(colCb2);
        funpl2.add(funCb2);
        parpl2.add(parCb2);
        typpl3.add(typText2);
        colpl3.add(colText2);
        funpl3.add(funText2);
        parpl3.add(parText2);


        JPanel pcontent = new JPanel();
        pcontent.setLayout(new GridLayout(4,2)); //component in center
        pcontent.add(typpl2);
        pcontent.add(typpl3);
        pcontent.add(colpl2);
        pcontent.add(colpl3);
        pcontent.add(funpl2);
        pcontent.add(funpl3);
        pcontent.add(parpl2);
        pcontent.add(parpl3);
        return pcontent;

    }

    public JPanel cSeekGUI(){
        JLabel typlb3 = new JLabel("Type");
        JLabel collb3 = new JLabel("Color");
        JLabel funlb3= new JLabel("Function");
        JLabel parlb3= new JLabel("Parts");


        typCb3 = new JComboBox<String>(typValue2);
        colCb3 = new JComboBox<String>(colValue2);
        funCb3= new JComboBox<String>(funValue2);
        parCb3= new JComboBox<String>(parValue2);
        typCb3.setSelectedIndex(0);
        colCb3.setSelectedIndex(0);
        funCb3.setSelectedIndex(0);
        parCb3.setSelectedIndex(0);

        typCb3.setMaximumSize(new Dimension(Integer.MAX_VALUE,typCb3.getMinimumSize().height));//unit size
        colCb3.setMaximumSize(new Dimension(Integer.MAX_VALUE,colCb3.getMinimumSize().height));
        funCb3.setMaximumSize(new Dimension(Integer.MAX_VALUE,funCb3.getMinimumSize().height));
        parCb3.setMaximumSize(new Dimension(Integer.MAX_VALUE,parCb3.getMinimumSize().height));


        JPanel  typpl3= new JPanel();
        JPanel  colpl3= new JPanel();
        JPanel  funpl3= new JPanel();
        JPanel  parpl3= new JPanel();

        typpl3.setLayout(new BoxLayout(typpl3, BoxLayout.X_AXIS));
        colpl3.setLayout(new BoxLayout(colpl3, BoxLayout.X_AXIS));
        funpl3.setLayout(new BoxLayout(funpl3, BoxLayout.X_AXIS));
        parpl3.setLayout(new BoxLayout(parpl3, BoxLayout.X_AXIS));


        typpl3.add(typlb3);
        colpl3.add(collb3);
        funpl3.add(funlb3);
        parpl3.add(parlb3);
        typpl3.add(Box.createHorizontalStrut(5));
        colpl3.add(Box.createHorizontalStrut(5));
        funpl3.add(Box.createHorizontalStrut(5));
        parpl3.add(Box.createHorizontalStrut(5));

        typpl3.add(typCb3);
        colpl3.add(colCb3);
        funpl3.add(funCb3);
        parpl3.add(parCb3);


        JPanel pcontent = new JPanel();
        pcontent.setLayout(new GridLayout(3,2)); //component in center

        pcontent.add(typpl3);
        pcontent.add(colpl3);
        pcontent.add(funpl3);
        pcontent.add(parpl3);
        return pcontent;

    }
    public void cAdd(){
        int ran = (int)((Math.random()*9+1)*100000);

        String typStr = typText1.getText();
        String colStr = colText1.getText();
        String funStr = funText1.getText();
        String parStr = parText1.getText();
        Initialize();
        int col=0;


        try{
            Connection conn = connect();
            //添加类别
            if (typStr != null && typStr.trim().length()!=0){
                if(typList.contains(typStr))
                {
                    col++;
                }
                else {
                    String va1 = "ALTER TABLE product  MODIFY COLUMN ptype enum(";
                    for (int j = 0; j < typValue.length; j++) {
                        va1 = va1 + "?,";
                    }
                    va1 = va1 + " ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";

                    PreparedStatement st1 = conn.prepareStatement(va1, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    for (int i = 0; i < typValue.length; i++) {
                        st1.setString(i + 1, typValue[i]);
                    }
                    st1.setString(typValue.length + 1, typStr);
                    st1.setString(typValue.length + 2, typValue[0]);

                    //修改ArrayList的值
                    typList.add(typStr);
                    typList2.add(typStr);
                    update();

                    st1.execute();
                }

            }


            //添加颜色
            if (colStr != null && colStr .trim().length()!=0){
                if(colList.contains(colStr)){
                    col++;
                }
                else {
                    String colva1 = "ALTER TABLE productNo  MODIFY COLUMN color enum(";
                    for (int j = 0; j < colValue.length; j++) {
                        colva1 = colva1 + "?,";
                    }
                    colva1 = colva1 + " ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                    PreparedStatement colst1 = conn.prepareStatement(colva1, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    for (int i = 0; i < colValue.length; i++) {
                        colst1.setString(i + 1, colValue[i]);
                    }
                    colst1.setString(colValue.length + 1, colStr);
                    colst1.setString(colValue.length + 2, colValue[0]);

                    //修改ArrayList的值
                    colList.add(colStr);
                    colList2.add(colStr);
                    update();
                    colst1.execute();
                }
            }



            //添加功能
            if (funStr !=null && funStr.trim().length()!=0){
                if(funList.contains(funStr)){
                    col++;
                }
                else {
                    String fun1 = "ALTER TABLE product  MODIFY COLUMN pfunction enum(";
                    for (int j = 0; j < funValue.length; j++) {
                        fun1 = fun1 + "?,";
                    }
                    fun1 = fun1 + " ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                    PreparedStatement funst1 = conn.prepareStatement(fun1, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    for (int i = 0; i < funValue.length; i++) {
                        funst1.setString(i + 1, funValue[i]);
                    }
                    funst1.setString(funValue.length + 1, funStr);
                    funst1.setString(funValue.length + 2, funValue[0]);

                    //修改ArrayList的值
                    funList.add(funStr);
                    funList2.add(funStr);
                    update();

                    funst1.execute();
                }
            }


            //添加零件
            if (parStr !=null && parStr.trim().length()!=0){
                if(parList.contains(parStr)){
                    col++;
                }
                else {
                    String par1 = "ALTER TABLE product MODIFY COLUMN parts enum(";
                    for (int j = 0; j < parValue.length; j++) {
                        par1 = par1 + "?,";
                    }
                    par1 = par1 + " ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                    PreparedStatement parst1 = conn.prepareStatement(par1, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    for (int i = 0; i < parValue.length; i++) {
                        parst1.setString(i + 1, parValue[i]);
                    }
                    parst1.setString(parValue.length + 1, parStr);
                    parst1.setString(parValue.length + 2, parValue[0]);

                    //修改ArrayList的值
                    parList.add(parStr);
                    parList2.add(parStr);
                    update();
                    parst1.execute();
                }

            }
            if(col==4){
                JOptionPane.showMessageDialog(null, "The category exists", "Add Error", JOptionPane.ERROR_MESSAGE);
            }
            //展示筛选过后的信息
            String csql = "SELECT p.ptype,p.pfunction,p.parts, pn.color" +
                    " FROM Product p,productNo pn" +
                    " WHERE p.pianoNo = pn.Product_pianoNo GROUP BY p.ptype,p.pfunction,p.parts, pn.color";
            PreparedStatement stmt3 = conn.prepareStatement(csql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs3 = stmt3.executeQuery();
            cTable.setModel(csetTable(rs3,conn));


        } catch (SQLException ome2) {
            ome2.printStackTrace();
        }


    }
    public void cModify(){

        int index1 = typCb2.getSelectedIndex();
        int index2 = colCb2.getSelectedIndex();
        int index3 = funCb2.getSelectedIndex();
        int index4 = parCb2.getSelectedIndex();
        String typStr = typCb2.getItemAt(index1);   //获得类型
        String colStr = colCb2.getItemAt(index2);   //获得颜色
        String funStr = funCb2.getItemAt(index3);   //获得功能
        String parStr = parCb2.getItemAt(index4);   //获得零件

        String typ = typText2.getText();   //将类型修改为typ
        String col = colText2.getText();   //将颜色修改为col
        String fun = funText2.getText();   //将功能修改围殴fun
        String par = parText2.getText();   //将零件修改为par

        typValue=getTypENUM(1);
        funValue=getFunENUM(1);
        parValue=getParENUM(1);
        typValue2 =getTypENUM(2);
        funValue2=getFunENUM(2);
        parValue2=getParENUM(2);

        try{
            Connection conn = connect();

            //修改类别
            if (typ != null && typ.trim().length()!=0){
                String va1 = "ALTER TABLE product  MODIFY COLUMN ptype enum(";
                for ( int j= 0; j<typValue.length; j++){
                    va1 = va1+"?,";
                }
                va1 = va1 +" ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";

                String va2 = " UPDATE product SET ptype = ? WHERE  ptype = ?";
                String va3 = "ALTER TABLE product " +
                        " MODIFY COLUMN ptype enum(";
                for( int m=0; m<typValue.length-1; m++){
                    va3 = va3+"?,";
                }
                va3 = va3 + "?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                PreparedStatement st1 = conn.prepareStatement( va1  ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0;i<typValue.length;i++){
                    st1.setString(i+1,typValue[i]);
                }
                st1.setString(typValue.length+1 ,typ);
                st1.setString(typValue.length +2,typValue[0]);

                PreparedStatement st2 = conn.prepareStatement( va2 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                st2.setString(1,typ);
                st2.setString(2,typStr);
                //修改ArrayList的值
                typList.set(index1,typ);
                typList2.set(index1+1,typ);
                update();


                PreparedStatement st3 = conn.prepareStatement( va3 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0; i<typValue.length;i++){
                    st3.setString(i+1,typValue[i]);
                }
                st3.setString(typValue.length+1,typValue[0]);

                st1.execute();
                st2.executeUpdate();
                st3.execute();
            }


            //修改颜色
            if (col != null && col .trim().length()!=0){
                String colva1 = "ALTER TABLE productNo  MODIFY COLUMN color enum(";
                for ( int j= 0; j<colValue.length; j++){
                    colva1 = colva1+"?,";
                }
                colva1 = colva1 +" ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";

                String colva2 = " UPDATE productNo SET color = ? WHERE  color = ?";
                String colva3 = "ALTER TABLE productNo " +
                        " MODIFY COLUMN color enum(";
                for( int m=0; m<colValue.length-1; m++){
                    colva3 = colva3+"?,";
                }
                colva3 = colva3 + "?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                PreparedStatement colst1 = conn.prepareStatement( colva1  ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0;i<colValue.length;i++){
                    colst1.setString(i+1,colValue[i]);
                }
                colst1.setString(colValue.length+1 ,col);
                colst1.setString(colValue.length +2,colValue[0]);

                PreparedStatement colst2 = conn.prepareStatement( colva2 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                colst2.setString(1,col);
                colst2.setString(2,colStr);
                //修改ArrayList的值
                colList.set(index2,col);
                colList2.set(index2+1,col);
                update();


                PreparedStatement colst3 = conn.prepareStatement( colva3 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0; i<colValue.length;i++){
                    colst3.setString(i+1,colValue[i]);
                }
                colst3.setString(colValue.length+1,colValue[0]);

                colst1.execute();
                colst2.executeUpdate();
                colst3.execute();
            }



            //修改功能
            if (fun !=null && fun.trim().length()!=0){
                String fun1 = "ALTER TABLE product  MODIFY COLUMN pfunction enum(";
                for ( int j= 0; j<funValue.length; j++){
                    fun1 = fun1+"?,";
                }
                fun1 = fun1 +" ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";

                String fun2 = " UPDATE product SET pfunction = ? WHERE  pfunction = ?";
                String fun3 = "ALTER TABLE product " +
                        " MODIFY COLUMN pfunction enum(";
                for( int m=0; m<funValue.length-1; m++){
                    fun3 = fun3+"?,";
                }
                fun3 = fun3 + "?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                PreparedStatement funst1 = conn.prepareStatement( fun1  ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0;i<funValue.length;i++){
                    funst1.setString(i+1,funValue[i]);
                }
                funst1.setString(funValue.length+1 ,fun);
                funst1.setString(funValue.length +2,funValue[0]);

                PreparedStatement funst2 = conn.prepareStatement( fun2 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                funst2.setString(1,fun);
                funst2.setString(2,funStr);
                //修改ArrayList的值
                funList.set(index3,fun);
                funList2.set(index3+1,fun);
                update();


                PreparedStatement funst3 = conn.prepareStatement( fun3 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0; i<funValue.length;i++){
                    funst3.setString(i+1,funValue[i]);
                }
                funst3.setString(funValue.length+1,funValue[0]);
                funst1.execute();
                funst2.executeUpdate();
                funst3.execute();
            }


            //修改零件
            if (par !=null && par.trim().length()!=0){
                String par1 = "ALTER TABLE product MODIFY COLUMN parts enum(";
                for ( int j= 0; j<parValue.length; j++){
                    par1 = par1+"?,";
                }
                par1 = par1 +" ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";

                String par2 = " UPDATE product SET parts = ? WHERE  parts = ?";
                String par3 = "ALTER TABLE product " +
                        " MODIFY COLUMN parts enum(";
                for( int m=0; m<parValue.length-1; m++){
                    par3 = par3+"?,";
                }
                par3 = par3 + "?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                PreparedStatement parst1 = conn.prepareStatement( par1  ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0;i<parValue.length;i++){
                    parst1.setString(i+1,parValue[i]);
                }
                parst1.setString(parValue.length+1 ,par);
                parst1.setString(parValue.length +2,parValue[0]);

                PreparedStatement parst2 = conn.prepareStatement( par2 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                parst2.setString(1,par);
                parst2.setString(2,parStr);
                //修改ArrayList的值
                parList.set(index4,par);
                parList2.set(index4+1,par);
                update();


                PreparedStatement parst3 = conn.prepareStatement( par3 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0; i<parValue.length;i++){
                    parst3.setString(i+1,parValue[i]);
                }
                parst3.setString(parValue.length+1,parValue[0]);
                parst1.execute();
                parst2.executeUpdate();
                parst3.execute();
            }



            //展示筛选过后的信息
            String csql = "SELECT p.ptype,p.pfunction,p.parts, pn.color" +
                    " FROM Product p,productNo pn" +
                    " WHERE p.pianoNo = pn.Product_pianoNo GROUP BY p.ptype,p.pfunction,p.parts, pn.color";
            PreparedStatement stmt3 = conn.prepareStatement(csql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs3 = stmt3.executeQuery();
            cTable.setModel(csetTable(rs3,conn));


        } catch (SQLException ome2) {
            ome2.printStackTrace();
        }

    }

    public void cSeek(){
        int index1 = typCb3.getSelectedIndex();
        int index2 = colCb3.getSelectedIndex();
        int index3 = funCb3.getSelectedIndex();
        int index4 = parCb3.getSelectedIndex();
        String typ = typCb3.getItemAt(index1);   //获得种类
        String col = colCb3.getItemAt(index2);   //获得功能
        String fun = funCb3.getItemAt(index3);   //获得功能
        String par = parCb3.getItemAt(index4);   //获得零件
        String[] sql ={"","","","","",""};
        sql[0] = " AND ptype = ? ";
        sql[1] = " AND pn.color = ?";
        sql[2] = " AND pfunction = ?";
        sql[3] = " AND parts =? ";
        try{

            Connection pconn = connect();

            String csql = "SELECT p.ptype,p.pfunction,p.parts, pn.color" +
                    " FROM Product p,productNo pn" +
                    " WHERE p.pianoNo = pn.Product_pianoNo ";
            //添加筛选条件
            int[] pos ={0,0,0,0,0,0,0,0,0,0,0,0,0};
            int pos2 =0;  //计算被选中的信息要插入的sql的位置
            if( typ != null && typ.trim().length() != 0  && (!typ.equals("All"))){
                csql = csql + sql[0];
                pos2 ++ ;
                pos[0]=pos2;   //pos[2]=5
            }
            if( col != null && col.trim().length() != 0 && (!col.equals("All"))){
                csql = csql + sql[1];    //最低价、最高价必须都有有效输入
                pos2 ++ ;
                pos[1]=pos2;
            }
            if(  fun!= null && fun.trim().length() != 0 && (!fun.equals("All"))){
                csql = csql + sql[2];     //产品颜色
                pos2++;
                pos[2]=pos2;
            }
            if( par != null && par.trim().length() != 0 && (!par.equals("All"))){     //产品功能
                csql = csql + sql[3];
                pos2++;
                pos[3]= pos2;
            }
            csql = csql + "GROUP BY p.ptype,p.pfunction,p.parts, pn.color";
            PreparedStatement state = pconn.prepareStatement(csql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            for ( int j=0;j<4;j++){
                if (pos[j]!=0){
                    if(j==0){
                        state.setString(pos[j],typ);
                    }
                    if(j==1){
                        state.setString(pos[j],col);
                    }
                    if(j==2){
                        state.setString(pos[j],fun);
                    }
                    if(j==3){
                        state.setString(pos[j],par);
                    }

                }else{

                }
            }
            ResultSet prs = state.executeQuery();
            if (  prs.isBeforeFirst() ){  //有结果
                cTable.setModel(csetTable(prs,pconn));
            }

        } catch (SQLException e2) {
            e2.printStackTrace();
        }

    }
    class cButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {


            if (cadd.isSelected()) {
                ca = new JFrame("Add");

                cayes = new JButton("Yes");
                cacan = new JButton("Cancel");
                cayes.addActionListener(new cAButtonListener());
                cacan.addActionListener(new cAButtonListener());
                JPanel cyes = new JPanel();
                JPanel ccan = new JPanel();
                JPanel bio = new JPanel();
                cyes.add(cayes);
                ccan.add(cacan);
                bio.setLayout(new GridLayout(1, 2));
                bio.add(cyes);
                bio.add(ccan);


                JPanel content = new JPanel();
                content.setLayout(new BorderLayout(5, 10));
                content.add(cAddGUI(), BorderLayout.CENTER);
                content.add(bio, BorderLayout.SOUTH);

                JLabel space0 = new JLabel("                    ");
                JLabel space1 = new JLabel("                    ");
                ca.setLayout(new BorderLayout(5, 10));
                ca.add(space0, BorderLayout.WEST);
                ca.add(content, BorderLayout.CENTER);
                ca.add(space1, BorderLayout.EAST);

                ca.setSize(650, 350);
                ca.setLocation(300, 200);
                ca.setVisible(true);

            } else if (cmod.isSelected()) {

                cm = new JFrame("Modify");

                cmyes = new JButton("Yes");                          //确定取消按钮
                cmcan = new JButton("Canacel");
                cmyes.addActionListener(new cMButtonListener());
                cmcan.addActionListener(new cMButtonListener());
                JPanel yp = new JPanel();
                JPanel cp = new JPanel();
                JPanel biop = new JPanel();
                yp.add(cmyes);
                cp.add(cmcan);
                biop.setLayout(new GridLayout(1, 2));
                biop.add(yp);
                biop.add(cp);

                JPanel content = new JPanel();
                content.setLayout(new BorderLayout(5, 10));
                content.add(cModifyGUI(), BorderLayout.CENTER);
                content.add(biop, BorderLayout.SOUTH);
                //cnoText2.setEnabled(false);
                //cnaText2.setEnabled(false);


                JLabel space0 = new JLabel("                    ");
                JLabel space1 = new JLabel("                    ");
                cm.setLayout(new BorderLayout(5, 10));
                cm.add(space0, BorderLayout.WEST);
                cm.add(content, BorderLayout.CENTER);
                cm.add(space1, BorderLayout.EAST);


                cm.setSize(650, 350);
                cm.setLocation(300, 200);
                cm.setVisible(true);


            } else if (csee.isSelected()) {
                cs = new JFrame("Seek");

                csyes = new JButton("Yes");
                cscan = new JButton("Cancel");
                csyes.addActionListener(new cSButtonListener());
                cscan.addActionListener(new cSButtonListener());
                JPanel pyes = new JPanel();
                JPanel pcan = new JPanel();
                JPanel bio = new JPanel();
                pyes.add(csyes);
                pcan.add(cscan);
                bio.setLayout(new GridLayout(1,2));
                bio.add(pyes);
                bio.add(pcan);


                JPanel content = new JPanel();
                content.setLayout(new BorderLayout(5,10));
                content.add(cSeekGUI(),BorderLayout.CENTER);
                content.add(bio,BorderLayout.SOUTH);

                JLabel space0 = new JLabel("                    ");
                JLabel space1 = new JLabel("                    ");
                cs.setLayout(new BorderLayout(5,10));
                cs.add(space0,BorderLayout.WEST);
                cs.add(content,BorderLayout.CENTER);
                cs.add(space1,BorderLayout.EAST);


                cs.setSize(650,350);
                cs.setLocation(300,200);
                cs.setVisible(true);

            } else if (call.isSelected()) {
                try{    //将数据库信息放到JTable中
                    Connection pmdconn = connect();
                    String csql = "SELECT p.ptype,p.pfunction,p.parts, pn.color" +
                            " FROM Product p,productNo pn" +
                            " WHERE p.pianoNo = pn.Product_pianoNo GROUP BY p.ptype,p.pfunction,p.parts, pn.color";
                    PreparedStatement pmdstmt = pmdconn.prepareStatement(csql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    ResultSet pmdres = pmdstmt.executeQuery();

                    cTable.setModel(csetTable(pmdres,pmdconn));

                } catch (SQLException e2) {
                    e2.printStackTrace();
                }

            }
        }

    }
    class cAButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent c){
            if( c.getSource() == cayes ){
                cAdd();
                ca.dispose();
            }else{
                ca.dispose();
            }

        }
    }
    class cMButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent c){
            if( c.getSource() == cmyes ){
                cModify();
                cm.dispose();
            }else{
                cm.dispose();
            }
        }
    }
    class cSButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent c){
            if( c.getSource() == csyes ){
                cSeek();
                cs.dispose();
            }else{
                cs.dispose();
            }

        }
    }

    /**
     * 连接数据库
     * @return
     */
    public Connection connect(){
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException classNotFoundException) {
            System.out.println("Failed to load driver package.");
        }
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/e_piano_2", "root", "Extraord10");
            return conn;
        } catch (SQLException throwables) {
            System.out.println("Failed to connect to database.");
        }
        return conn;
    }
    /**
     * 判断是否含有字母
     * @param str  待检验的字符串
     * @return   返回是否包含
     * true  包含字母
     */
    public boolean judgeContainsStr(String str) {
        String regex=".*[a-zA-Z]+.*";
        Matcher m= Pattern.compile(regex).matcher(str);
        return m.matches();
    }
    /**
     * 判断商品中是否包含这个编号
     * @param str  从对话框中获取的编号字符串
     * @return   返回是否存在
     * true 存在
     */
    public boolean checkPExist(String str){
        boolean flag = false;
        try{
            int pInt = Integer.parseInt(str);
            Connection check = connect();
            String csql = "SELECT * FROM Product WHERE pianoNo = ?";
            PreparedStatement cstate = check.prepareStatement(csql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            cstate.setInt(1,pInt);
            ResultSet crs = cstate.executeQuery();
            if ( ! crs.isBeforeFirst()){
                flag= false;
            }else{
                flag =  true;
            }
        }catch (SQLException c1) {
            c1.printStackTrace();
        }
        return flag;
    }

    /**从数据库获取并初始化
     * type,color,function,parts的数值
     */
    public void Initialize(){
        try{
            typList = new ArrayList<String>();
            colList = new ArrayList<String>();
            funList = new ArrayList<String>();
            parList = new ArrayList<String>();
            typList2 = new ArrayList<String>();
            colList2 = new ArrayList<String>();
            funList2 = new ArrayList<String>();
            parList2 = new ArrayList<String>();
            typList2.add("All");
            colList2.add("All");
            funList2.add("All");
            parList2.add("All");
            //获得数据库中的type
            Connection conn = connect();
            String csql2 = "SELECT color From productNo GROUP BY color";
            PreparedStatement stmt2 = conn.prepareStatement(csql2,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs2 = stmt2.executeQuery();
            String[] typ1 = getTypENUM(1);
            String[] fun1 = getFunENUM(1);
            String[] par1 = getParENUM(1);
            for ( int i=0;i<typ1.length;i++){
                typList.add(typ1[i]);
                typList2.add(typ1[i]);
            }
            for ( int i=0;i<fun1.length;i++){
                funList.add(fun1[i]);
                funList2.add(fun1[i]);
            }
            for ( int i=0;i<par1.length;i++){
                parList.add(par1[i]);
                parList2.add(par1[i]);
            }

            //将结果放到ArrayList中
            //color
            int count2 = 0;
            while (rs2.next()) {
                count2++;
            }
            String comm2[][] = new String[count2][1];
            count2 = 0;
            rs2.beforeFirst();
            while (rs2.next()) {
                comm2[count2][0] = rs2.getString("color");
                colList.add(comm2[count2][0]);
                colList2.add(comm2[count2][0]);
                count2++;
            }


            conn.close();

            update();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void update(){
        typValue = (String[])typList.toArray(new String[typList.size()]) ;
        colValue = (String[])colList.toArray(new String[colList.size()]) ;
        funValue = (String[])funList.toArray(new String[funList.size()]) ;
        parValue = (String[])parList.toArray(new String[parList.size()]) ;
        typValue2 = (String[])typList2.toArray(new String[typList2.size()]) ;
        colValue2 = (String[])colList2.toArray(new String[colList2.size()]) ;
        funValue2 = (String[])funList2.toArray(new String[funList2.size()]) ;
        parValue2 = (String[])parList2.toArray(new String[parList2.size()]) ;

    }

    public String[] getTypENUM( int  num){
        ArrayList<String> typlt = new ArrayList<String>();
        ArrayList<String> typlt2 = new ArrayList<String>();
        typlt2.add("All");
        String[] tValue = null ;
        String[] tValue2 = null;
        String tENUM = " ";
        try{
            Connection conn = connect();
            String s = "SELECT column_type" +
                    " FROM  information_schema. COLUMNS  WHERE" +
                    "        TABLE_SCHEMA = 'e_piano_2'" +
                    "        AND DATA_TYPE = 'enum'" +
                    "        AND table_name='product'" +
                    "        AND column_name='ptype'";
            PreparedStatement st1 = conn.prepareStatement(s,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs1 = st1.executeQuery();
            while (rs1.next()) {
                tENUM = rs1.getString("column_type");
            }
            String test = tENUM.replace(',', ' ');
            String test2 = subString(test,"enum(",")");
            String[] splitStr = test2.split("'");
            for ( int i=0;i<splitStr.length;i++){
                if (splitStr[i]!=null && splitStr[i].trim().length()!=0){
                    typlt.add(splitStr[i]);
                    typlt2.add(splitStr[i]);
                }

            }

            tValue = (String[])typlt.toArray(new String[typlt.size()]) ;
            tValue2 = (String[])typlt2.toArray(new String[typlt2.size()]) ;

            if ( num ==1){
                return tValue;
            }else{
                return tValue2;
            }


        }catch (SQLException e) {
            e.printStackTrace();
        }
        return tValue;

    }
    public String[] getFunENUM( int  num){
        ArrayList<String> funlt = new ArrayList<String>();
        ArrayList<String> funlt2 = new ArrayList<String>();
        funlt2.add("All");
        String[] fValue = null ;
        String[] fValue2 = null;
        String fENUM = " ";
        try{
            Connection conn = connect();
            String s = "SELECT column_type" +
                    " FROM  information_schema. COLUMNS  WHERE" +
                    "        TABLE_SCHEMA = 'e_piano_2'" +
                    "        AND DATA_TYPE = 'enum'" +
                    "        AND table_name='product'" +
                    "        AND column_name='pfunction'";
            PreparedStatement st1 = conn.prepareStatement(s,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs1 = st1.executeQuery();
            while (rs1.next()) {
                fENUM = rs1.getString("column_type");
            }
            String test = fENUM.replace(',', ' ');
            String test2 = subString(test,"enum(",")");
            String[] splitStr = test2.split("'");
            for ( int i=0;i<splitStr.length;i++){
                if (splitStr[i]!=null && splitStr[i].trim().length()!=0){
                    funlt.add(splitStr[i]);
                    funlt2.add(splitStr[i]);
                }

            }

            fValue = (String[])funlt.toArray(new String[funlt.size()]) ;
            fValue2 = (String[])funlt2.toArray(new String[funlt2.size()]) ;

            if ( num ==1){
                return fValue;
            }else{
                return fValue2;
            }


        }catch (SQLException e) {
            e.printStackTrace();
        }
        return fValue;

    }
    public String[] getParENUM( int  num){
        ArrayList<String> parlt = new ArrayList<String>();
        ArrayList<String> parlt2 = new ArrayList<String>();
        parlt2.add("All");
        String[] pValue = null ;
        String[] pValue2 = null;
        String pENUM = " ";
        try{
            Connection conn = connect();
            String s = "SELECT column_type" +
                    " FROM  information_schema. COLUMNS  WHERE" +
                    "        TABLE_SCHEMA = 'e_piano_2'" +
                    "        AND DATA_TYPE = 'enum'" +
                    "        AND table_name='product'" +
                    "        AND column_name='parts'";
            PreparedStatement st1 = conn.prepareStatement(s,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs1 = st1.executeQuery();
            while (rs1.next()) {
                pENUM = rs1.getString("column_type");
            }
            String test = pENUM.replace(',', ' ');
            String test2 = subString(test,"enum(",")");
            String[] splitStr = test2.split("'");
            for ( int i=0;i<splitStr.length;i++){
                if (splitStr[i]!=null && splitStr[i].trim().length()!=0){
                    parlt.add(splitStr[i]);
                    parlt2.add(splitStr[i]);
                }

            }

            pValue = (String[])parlt.toArray(new String[parlt.size()]) ;
            pValue2 = (String[])parlt2.toArray(new String[parlt2.size()]) ;

            if ( num ==1){
                return pValue;
            }else{
                return pValue2;
            }


        }catch (SQLException e) {
            e.printStackTrace();
        }
        return pValue;

    }
    public  String subString(String str, String strStart, String strEnd) {

        int strStartIndex = str.indexOf(strStart);
        int strEndIndex = str.indexOf(strEnd);

        String result = str.substring(strStartIndex, strEndIndex).substring(strStart.length());
        return result;
    }

}



