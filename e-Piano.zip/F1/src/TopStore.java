import java.awt.Font;
import java.sql.*;


import org.jfree.chart.*;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;

public class TopStore extends ApplicationFrame {
    public TopStore(String title, String sql, String s1, String s2) {
        super(title);
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/e_piano_2",
                    "root",
                    "Extraord10");
            System.out.println("Connected successfully");


            PreparedStatement state = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = state.executeQuery();


            //执行更新操作
            int count = 0;
            while (rs.next()) {   //存到数组中
                count++;
            }
            int row= count;

            String comm[][] = new String[count][2];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString(s1);
                comm[count][1] = rs.getString(s2);
                count++;
            }
            conn.close();
            for (int m = 0; m < row; m++) {
                dataset.setValue(Double.parseDouble(comm[m][1]), s2, comm[m][0]);
            }

        } catch (ClassNotFoundException ome1) {
            ome1.printStackTrace();
        } catch (SQLException e2) {
            e2.printStackTrace();
        }
        JFreeChart chart = ChartFactory.createBarChart(
                title,
                s1,
                s2,
                dataset, PlotOrientation.VERTICAL,
                true,
                true,
                false); //创建一个JFreeChart
        chart.setTitle(new TextTitle(
                title,
                new Font("宋体", Font.BOLD + Font.ITALIC, 20)));//可以重新设置标题，替换“hi”标题
        CategoryPlot plot = (CategoryPlot) chart.getPlot();//获得图标中间部分，即plot
        CategoryAxis categoryAxis = plot.getDomainAxis();//获得横坐标
        categoryAxis.setLabelFont(new Font("微软雅黑", Font.BOLD, 20));//设置横坐标字体
        chart.getCategoryPlot();//设置图的高级属性

        BarRenderer barRenderer = (BarRenderer) plot.getRenderer();
        barRenderer.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
        barRenderer.setBaseItemLabelsVisible(true);
        plot.setRenderer(barRenderer);
        ChartFrame frame=new ChartFrame(title,chart);
        frame.setVisible(true);
        frame.pack();

    }
}
