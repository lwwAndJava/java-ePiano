import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class Category {
    //cGUI上的组件
    JRadioButton cadd,cmod,csee,call;   //添加、修改、查找、展示所有
    ButtonGroup cbg;
    JButton cButton;       //确认
    DefaultTableModel cModel;
    JTable cTable;

    //cAddGUI上的组件
    JTextField typText1,colText1,funText1,parText1;   //   商品管理 修改版面上的组件

    //cModifyGUI上的组件
    JTextField cnoText2,cnaText2,typText2,colText2,funText2,parText2;   //   商品管理 修改版面上的组件
    JComboBox<String> typCb2,colCb2,funCb2, parCb2;  //无All

    //cSeekGUI上的组件

    JComboBox<String> typCb3,colCb3,funCb3, parCb3;   //有All

    //添加、修改、查找弹出框的JFrame
    JFrame ca,cm,cs;

    //添加、修改、查找弹出框的确认与取消按钮
    JButton cayes,cmyes,csyes,cacan,cmcan,cscan;

    //type,color,function,parts的值
    ArrayList<String> typList, colList,funList,parList;      //无All
    ArrayList<String> typList2, colList2,funList2,parList2;  //有All
    String[] typValue,colValue,funValue,parValue ; //无All
    String[] typValue2,colValue2,funValue2,parValue2 ;  //有All


    /*
    public static void main(String[] args){
        Category c = new Category();
    }

     */


    public Category (int num){

    }
    public Category (){

        Initialize();
    }
    public JPanel cGUI(){

        JPanel jp= new JPanel();
        JPanel csPanel = new JPanel();
        JPanel cLeft = new JPanel();        //把csPanel放在cLeft的borderLayout。CENTER


        JLabel clb = new JLabel("Please select the operation");
        cadd = new JRadioButton("Add category");
        cmod = new JRadioButton("Modify category");
        csee = new JRadioButton("Seek category");
        call = new JRadioButton("Show all category");
        cbg = new ButtonGroup();
        cbg.add(cadd);
        cbg.add(cmod);
        cbg.add(csee);
        cbg.add(call);


        //按钮
        JPanel csbp= new JPanel();
        cButton = new JButton("Process");
        cButton.addActionListener(new cButtonListener());
        csbp.add(cButton);


        csPanel.setLayout(new GridLayout(6,1));
        csPanel.add(clb);
        csPanel.add(cadd);
        csPanel.add(cmod);
        csPanel.add(csee);
        csPanel.add(call);
        csPanel.add(csbp);

        cLeft.setLayout(new BorderLayout());
        cLeft.add(csPanel,BorderLayout.CENTER);


        /**
         * 展示商品编号，名字和类别信息
         */
        try{    //将数据库信息放到JTable中

            Connection conn = connect();

            String csql = "SELECT p.ptype,p.pfunction,p.parts, pn.color" +
                    " FROM Product p,productNo pn" +
                    " WHERE p.pianoNo = pn.Product_pianoNo GROUP BY p.ptype,p.pfunction,p.parts, pn.color";
            PreparedStatement stmt = conn.prepareStatement(csql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet res = stmt.executeQuery();


            cTable= new JTable(csetTable(res,conn));
            cTable.setPreferredScrollableViewportSize(new Dimension(800,200));
            JScrollPane jScrollPane = new JScrollPane(cTable,
                    ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

            jp.setLayout(new BorderLayout(20,15));    //add component on jp1
            jp.add(cLeft,BorderLayout.WEST);
            jp.add(jScrollPane,BorderLayout.CENTER);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jp;
    }
    public DefaultTableModel csetTable(ResultSet rs, Connection conn){
        try{
            int count = 0;   //更新JTable
            while (rs.next()) {
                count++;
            }

            String comm[][] = new String[count][6];
            count = 0;
            rs.beforeFirst();
            while (rs.next()) {
                comm[count][0] = rs.getString("ptype");
                comm[count][1] = rs.getString("p.pfunction");
                comm[count][2] = rs.getString("p.parts");
                comm[count][3] = rs.getString("pn.color");

                count++;
            }
            conn.close();

            String[] title = {"Type","Function","Parts","Color"};
            //使表格不可编辑
            cModel = new DefaultTableModel(comm, title) {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            return cModel;

        }catch (SQLException e2) {
            e2.printStackTrace();
        }
        return cModel;
    }


    public JPanel cAddGUI(){


        JLabel typlb1 = new JLabel("Type");
        JLabel collb1 = new JLabel("Color");
        JLabel funlb1= new JLabel("Function");
        JLabel parlb1= new JLabel("Parts");



        typText1 = new JTextField();
        colText1 = new JTextField();
        funText1 = new JTextField();
        parText1 = new JTextField();


        typText1.setMaximumSize(new Dimension(500, typText1.getMinimumSize().height));
        colText1.setMaximumSize(new Dimension(500, colText1.getMinimumSize().height));
        funText1.setMaximumSize(new Dimension(500, funText1.getMinimumSize().height));
        parText1.setMaximumSize(new Dimension(500, parText1.getMinimumSize().height));



        JPanel  typpl1= new JPanel();
        JPanel  colpl1= new JPanel();
        JPanel  funpl1= new JPanel();
        JPanel  parpl1= new JPanel();


        typpl1.setLayout(new BoxLayout(typpl1, BoxLayout.X_AXIS));
        colpl1.setLayout(new BoxLayout(colpl1, BoxLayout.X_AXIS));
        funpl1.setLayout(new BoxLayout(funpl1, BoxLayout.X_AXIS));
        parpl1.setLayout(new BoxLayout(parpl1, BoxLayout.X_AXIS));



        typpl1.add(typlb1);
        colpl1.add(collb1);
        funpl1.add(funlb1);
        parpl1.add(parlb1);
        typpl1.add(Box.createHorizontalStrut(5));
        colpl1.add(Box.createHorizontalStrut(5));
        funpl1.add(Box.createHorizontalStrut(5));
        parpl1.add(Box.createHorizontalStrut(5));
        typpl1.add(typText1);
        colpl1.add(colText1);
        funpl1.add(funText1);
        parpl1.add(parText1);


        JPanel pcontent = new JPanel();
        pcontent.setLayout(new GridLayout(2,2)); //component in center
        pcontent.add(typpl1);
        pcontent.add(colpl1);
        pcontent.add(funpl1);
        pcontent.add(parpl1);
        return pcontent;

    }
    public JPanel cModifyGUI(){
        JLabel typlb2 = new JLabel("Type");
        JLabel collb2 = new JLabel("Color");
        JLabel funlb2= new JLabel("Function");
        JLabel parlb2= new JLabel("Parts");
        JLabel typlb3 = new JLabel("Change to");
        JLabel collb3 = new JLabel("Change to");
        JLabel funlb3= new JLabel("Change to");
        JLabel parlb3= new JLabel("Change to");



        typCb2 = new JComboBox<String>(typValue);
        colCb2 = new JComboBox<String>(colValue);
        funCb2= new JComboBox<String>(funValue);
        parCb2= new JComboBox<String>(parValue);
        typText2 = new JTextField();
        colText2 = new JTextField();
        funText2 = new JTextField();
        parText2 = new JTextField();


        typCb2.setMaximumSize(new Dimension(Integer.MAX_VALUE,typCb2.getMinimumSize().height));//unit size
        colCb2.setMaximumSize(new Dimension(Integer.MAX_VALUE,colCb2.getMinimumSize().height));
        funCb2.setMaximumSize(new Dimension(Integer.MAX_VALUE,funCb2.getMinimumSize().height));
        parCb2.setMaximumSize(new Dimension(Integer.MAX_VALUE,parCb2.getMinimumSize().height));
        typText2.setMaximumSize(new Dimension(500,  typText2.getMinimumSize().height));
        colText2.setMaximumSize(new Dimension(500, colText2.getMinimumSize().height));
        funText2.setMaximumSize(new Dimension(500, funText2.getMinimumSize().height));
        parText2.setMaximumSize(new Dimension(500, parText2.getMinimumSize().height));



        JPanel  typpl2= new JPanel();
        JPanel  colpl2= new JPanel();
        JPanel  funpl2= new JPanel();
        JPanel  parpl2= new JPanel();
        JPanel  typpl3= new JPanel();
        JPanel  colpl3= new JPanel();
        JPanel  funpl3= new JPanel();
        JPanel  parpl3= new JPanel();


        typpl2.setLayout(new BoxLayout(typpl2, BoxLayout.X_AXIS));
        colpl2.setLayout(new BoxLayout(colpl2, BoxLayout.X_AXIS));
        funpl2.setLayout(new BoxLayout(funpl2, BoxLayout.X_AXIS));
        parpl2.setLayout(new BoxLayout(parpl2, BoxLayout.X_AXIS));
        typpl3.setLayout(new BoxLayout(typpl3, BoxLayout.X_AXIS));
        colpl3.setLayout(new BoxLayout(colpl3, BoxLayout.X_AXIS));
        funpl3.setLayout(new BoxLayout(funpl3, BoxLayout.X_AXIS));
        parpl3.setLayout(new BoxLayout(parpl3, BoxLayout.X_AXIS));


        typpl2.add(typlb2);
        colpl2.add(collb2);
        funpl2.add(funlb2);
        parpl2.add(parlb2);
        typpl3.add(typlb3);
        colpl3.add(collb3);
        funpl3.add(funlb3);
        parpl3.add(parlb3);
        typpl2.add(Box.createHorizontalStrut(5));
        colpl2.add(Box.createHorizontalStrut(5));
        funpl2.add(Box.createHorizontalStrut(5));
        parpl2.add(Box.createHorizontalStrut(5));
        typpl3.add(Box.createHorizontalStrut(5));
        colpl3.add(Box.createHorizontalStrut(5));
        funpl3.add(Box.createHorizontalStrut(5));
        parpl3.add(Box.createHorizontalStrut(5));
        typpl2.add(typCb2);
        colpl2.add(colCb2);
        funpl2.add(funCb2);
        parpl2.add(parCb2);
        typpl3.add(typText2);
        colpl3.add(colText2);
        funpl3.add(funText2);
        parpl3.add(parText2);


        JPanel pcontent = new JPanel();
        pcontent.setLayout(new GridLayout(4,2)); //component in center
        pcontent.add(typpl2);
        pcontent.add(typpl3);
        pcontent.add(colpl2);
        pcontent.add(colpl3);
        pcontent.add(funpl2);
        pcontent.add(funpl3);
        pcontent.add(parpl2);
        pcontent.add(parpl3);
        return pcontent;

    }

    public JPanel cSeekGUI(){
        JLabel typlb3 = new JLabel("Type");
        JLabel collb3 = new JLabel("Color");
        JLabel funlb3= new JLabel("Function");
        JLabel parlb3= new JLabel("Parts");


        typCb3 = new JComboBox<String>(typValue2);
        colCb3 = new JComboBox<String>(colValue2);
        funCb3= new JComboBox<String>(funValue2);
        parCb3= new JComboBox<String>(parValue2);
        typCb3.setSelectedIndex(0);
        colCb3.setSelectedIndex(0);
        funCb3.setSelectedIndex(0);
        parCb3.setSelectedIndex(0);

        typCb3.setMaximumSize(new Dimension(Integer.MAX_VALUE,typCb3.getMinimumSize().height));//unit size
        colCb3.setMaximumSize(new Dimension(Integer.MAX_VALUE,colCb3.getMinimumSize().height));
        funCb3.setMaximumSize(new Dimension(Integer.MAX_VALUE,funCb3.getMinimumSize().height));
        parCb3.setMaximumSize(new Dimension(Integer.MAX_VALUE,parCb3.getMinimumSize().height));


        JPanel  typpl3= new JPanel();
        JPanel  colpl3= new JPanel();
        JPanel  funpl3= new JPanel();
        JPanel  parpl3= new JPanel();

        typpl3.setLayout(new BoxLayout(typpl3, BoxLayout.X_AXIS));
        colpl3.setLayout(new BoxLayout(colpl3, BoxLayout.X_AXIS));
        funpl3.setLayout(new BoxLayout(funpl3, BoxLayout.X_AXIS));
        parpl3.setLayout(new BoxLayout(parpl3, BoxLayout.X_AXIS));


        typpl3.add(typlb3);
        colpl3.add(collb3);
        funpl3.add(funlb3);
        parpl3.add(parlb3);
        typpl3.add(Box.createHorizontalStrut(5));
        colpl3.add(Box.createHorizontalStrut(5));
        funpl3.add(Box.createHorizontalStrut(5));
        parpl3.add(Box.createHorizontalStrut(5));

        typpl3.add(typCb3);
        colpl3.add(colCb3);
        funpl3.add(funCb3);
        parpl3.add(parCb3);


        JPanel pcontent = new JPanel();
        pcontent.setLayout(new GridLayout(3,2)); //component in center

        pcontent.add(typpl3);
        pcontent.add(colpl3);
        pcontent.add(funpl3);
        pcontent.add(parpl3);
        return pcontent;

    }
    public void cAdd(){
        int ran = (int)((Math.random()*9+1)*100000);

        String typStr = typText1.getText();
        String colStr = colText1.getText();
        String funStr = funText1.getText();
        String parStr = parText1.getText();
        Initialize();
        int col=0;


        try{
            Connection conn = connect();
            //添加类别
            if (typStr != null && typStr.trim().length()!=0){
                if(typList.contains(typStr))
                {
                    col++;
                }
                else {
                    String va1 = "ALTER TABLE product  MODIFY COLUMN ptype enum(";
                    for (int j = 0; j < typValue.length; j++) {
                        va1 = va1 + "?,";
                    }
                    va1 = va1 + " ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";

                    PreparedStatement st1 = conn.prepareStatement(va1, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    for (int i = 0; i < typValue.length; i++) {
                        st1.setString(i + 1, typValue[i]);
                    }
                    st1.setString(typValue.length + 1, typStr);
                    st1.setString(typValue.length + 2, typValue[0]);

                    //修改ArrayList的值
                    typList.add(typStr);
                    typList2.add(typStr);
                    update();

                    st1.execute();
                }

            }


            //添加颜色
            if (colStr != null && colStr .trim().length()!=0){
                if(colList.contains(colStr)){
                    col++;
                }
                else {
                    String colva1 = "ALTER TABLE productNo  MODIFY COLUMN color enum(";
                    for (int j = 0; j < colValue.length; j++) {
                        colva1 = colva1 + "?,";
                    }
                    colva1 = colva1 + " ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                    PreparedStatement colst1 = conn.prepareStatement(colva1, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    for (int i = 0; i < colValue.length; i++) {
                        colst1.setString(i + 1, colValue[i]);
                    }
                    colst1.setString(colValue.length + 1, colStr);
                    colst1.setString(colValue.length + 2, colValue[0]);

                    //修改ArrayList的值
                    colList.add(colStr);
                    colList2.add(colStr);
                    update();
                    colst1.execute();
                }
            }



            //添加功能
            if (funStr !=null && funStr.trim().length()!=0){
                if(funList.contains(funStr)){
                    col++;
                }
                else {
                    String fun1 = "ALTER TABLE product  MODIFY COLUMN pfunction enum(";
                    for (int j = 0; j < funValue.length; j++) {
                        fun1 = fun1 + "?,";
                    }
                    fun1 = fun1 + " ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                    PreparedStatement funst1 = conn.prepareStatement(fun1, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    for (int i = 0; i < funValue.length; i++) {
                        funst1.setString(i + 1, funValue[i]);
                    }
                    funst1.setString(funValue.length + 1, funStr);
                    funst1.setString(funValue.length + 2, funValue[0]);

                    //修改ArrayList的值
                    funList.add(funStr);
                    funList2.add(funStr);
                    update();

                    funst1.execute();
                }
            }


            //添加零件
            if (parStr !=null && parStr.trim().length()!=0){
                if(parList.contains(parStr)){
                    col++;
                }
                else {
                    String par1 = "ALTER TABLE product MODIFY COLUMN parts enum(";
                    for (int j = 0; j < parValue.length; j++) {
                        par1 = par1 + "?,";
                    }
                    par1 = par1 + " ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                    PreparedStatement parst1 = conn.prepareStatement(par1, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    for (int i = 0; i < parValue.length; i++) {
                        parst1.setString(i + 1, parValue[i]);
                    }
                    parst1.setString(parValue.length + 1, parStr);
                    parst1.setString(parValue.length + 2, parValue[0]);

                    //修改ArrayList的值
                    parList.add(parStr);
                    parList2.add(parStr);
                    update();
                    parst1.execute();
                }

            }
            if(col==4){
                JOptionPane.showMessageDialog(null, "The category exists", "Add Error", JOptionPane.ERROR_MESSAGE);
            }
            //展示筛选过后的信息
            String csql = "SELECT p.ptype,p.pfunction,p.parts, pn.color" +
                    " FROM Product p,productNo pn" +
                    " WHERE p.pianoNo = pn.Product_pianoNo GROUP BY p.ptype,p.pfunction,p.parts, pn.color";
            PreparedStatement stmt3 = conn.prepareStatement(csql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs3 = stmt3.executeQuery();
            cTable.setModel(csetTable(rs3,conn));


        } catch (SQLException ome2) {
            ome2.printStackTrace();
        }


    }
    public void cModify(){

        int index1 = typCb2.getSelectedIndex();
        int index2 = colCb2.getSelectedIndex();
        int index3 = funCb2.getSelectedIndex();
        int index4 = parCb2.getSelectedIndex();
        String typStr = typCb2.getItemAt(index1);   //获得类型
        String colStr = colCb2.getItemAt(index2);   //获得颜色
        String funStr = funCb2.getItemAt(index3);   //获得功能
        String parStr = parCb2.getItemAt(index4);   //获得零件

        String typ = typText2.getText();   //将类型修改为typ
        String col = colText2.getText();   //将颜色修改为col
        String fun = funText2.getText();   //将功能修改围殴fun
        String par = parText2.getText();   //将零件修改为par

        typValue=getTypENUM(1);
        funValue=getFunENUM(1);
        parValue=getParENUM(1);
        typValue2 =getTypENUM(2);
        funValue2=getFunENUM(2);
        parValue2=getParENUM(2);

        try{
            Connection conn = connect();

            //修改类别
            if (typ != null && typ.trim().length()!=0){
                String va1 = "ALTER TABLE product  MODIFY COLUMN ptype enum(";
                for ( int j= 0; j<typValue.length; j++){
                    va1 = va1+"?,";
                }
                va1 = va1 +" ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";

                String va2 = " UPDATE product SET ptype = ? WHERE  ptype = ?";
                String va3 = "ALTER TABLE product " +
                        " MODIFY COLUMN ptype enum(";
                for( int m=0; m<typValue.length-1; m++){
                    va3 = va3+"?,";
                }
                va3 = va3 + "?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                PreparedStatement st1 = conn.prepareStatement( va1  ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0;i<typValue.length;i++){
                    st1.setString(i+1,typValue[i]);
                }
                st1.setString(typValue.length+1 ,typ);
                st1.setString(typValue.length +2,typValue[0]);

                PreparedStatement st2 = conn.prepareStatement( va2 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                st2.setString(1,typ);
                st2.setString(2,typStr);
                //修改ArrayList的值
                typList.set(index1,typ);
                typList2.set(index1+1,typ);
                update();


                PreparedStatement st3 = conn.prepareStatement( va3 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0; i<typValue.length;i++){
                    st3.setString(i+1,typValue[i]);
                }
                st3.setString(typValue.length+1,typValue[0]);

                st1.execute();
                st2.executeUpdate();
                st3.execute();
            }


            //修改颜色
            if (col != null && col .trim().length()!=0){
                String colva1 = "ALTER TABLE productNo  MODIFY COLUMN color enum(";
                for ( int j= 0; j<colValue.length; j++){
                    colva1 = colva1+"?,";
                }
                colva1 = colva1 +" ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";

                String colva2 = " UPDATE productNo SET color = ? WHERE  color = ?";
                String colva3 = "ALTER TABLE productNo " +
                        " MODIFY COLUMN color enum(";
                for( int m=0; m<colValue.length-1; m++){
                    colva3 = colva3+"?,";
                }
                colva3 = colva3 + "?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                PreparedStatement colst1 = conn.prepareStatement( colva1  ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0;i<colValue.length;i++){
                    colst1.setString(i+1,colValue[i]);
                }
                colst1.setString(colValue.length+1 ,col);
                colst1.setString(colValue.length +2,colValue[0]);

                PreparedStatement colst2 = conn.prepareStatement( colva2 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                colst2.setString(1,col);
                colst2.setString(2,colStr);
                //修改ArrayList的值
                colList.set(index2,col);
                colList2.set(index2+1,col);
                update();


                PreparedStatement colst3 = conn.prepareStatement( colva3 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0; i<colValue.length;i++){
                    colst3.setString(i+1,colValue[i]);
                }
                colst3.setString(colValue.length+1,colValue[0]);

                colst1.execute();
                colst2.executeUpdate();
                colst3.execute();
            }



            //修改功能
            if (fun !=null && fun.trim().length()!=0){
                String fun1 = "ALTER TABLE product  MODIFY COLUMN pfunction enum(";
                for ( int j= 0; j<funValue.length; j++){
                    fun1 = fun1+"?,";
                }
                fun1 = fun1 +" ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";

                String fun2 = " UPDATE product SET pfunction = ? WHERE  pfunction = ?";
                String fun3 = "ALTER TABLE product " +
                        " MODIFY COLUMN pfunction enum(";
                for( int m=0; m<funValue.length-1; m++){
                    fun3 = fun3+"?,";
                }
                fun3 = fun3 + "?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                PreparedStatement funst1 = conn.prepareStatement( fun1  ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0;i<funValue.length;i++){
                    funst1.setString(i+1,funValue[i]);
                }
                funst1.setString(funValue.length+1 ,fun);
                funst1.setString(funValue.length +2,funValue[0]);

                PreparedStatement funst2 = conn.prepareStatement( fun2 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                funst2.setString(1,fun);
                funst2.setString(2,funStr);
                //修改ArrayList的值
                funList.set(index3,fun);
                funList2.set(index3+1,fun);
                update();


                PreparedStatement funst3 = conn.prepareStatement( fun3 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0; i<funValue.length;i++){
                    funst3.setString(i+1,funValue[i]);
                }
                funst3.setString(funValue.length+1,funValue[0]);
                funst1.execute();
                funst2.executeUpdate();
                funst3.execute();
            }


            //修改零件
            if (par !=null && par.trim().length()!=0){
                String par1 = "ALTER TABLE product MODIFY COLUMN parts enum(";
                for ( int j= 0; j<parValue.length; j++){
                    par1 = par1+"?,";
                }
                par1 = par1 +" ?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";

                String par2 = " UPDATE product SET parts = ? WHERE  parts = ?";
                String par3 = "ALTER TABLE product " +
                        " MODIFY COLUMN parts enum(";
                for( int m=0; m<parValue.length-1; m++){
                    par3 = par3+"?,";
                }
                par3 = par3 + "?) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ? ";


                PreparedStatement parst1 = conn.prepareStatement( par1  ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0;i<parValue.length;i++){
                    parst1.setString(i+1,parValue[i]);
                }
                parst1.setString(parValue.length+1 ,par);
                parst1.setString(parValue.length +2,parValue[0]);

                PreparedStatement parst2 = conn.prepareStatement( par2 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                parst2.setString(1,par);
                parst2.setString(2,parStr);
                //修改ArrayList的值
                parList.set(index4,par);
                parList2.set(index4+1,par);
                update();


                PreparedStatement parst3 = conn.prepareStatement( par3 ,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
                for ( int i=0; i<parValue.length;i++){
                    parst3.setString(i+1,parValue[i]);
                }
                parst3.setString(parValue.length+1,parValue[0]);
                parst1.execute();
                parst2.executeUpdate();
                parst3.execute();
            }



            //展示筛选过后的信息
            String csql = "SELECT p.ptype,p.pfunction,p.parts, pn.color" +
                    " FROM Product p,productNo pn" +
                    " WHERE p.pianoNo = pn.Product_pianoNo GROUP BY p.ptype,p.pfunction,p.parts, pn.color";
            PreparedStatement stmt3 = conn.prepareStatement(csql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs3 = stmt3.executeQuery();
            cTable.setModel(csetTable(rs3,conn));


        } catch (SQLException ome2) {
            ome2.printStackTrace();
        }

    }

    public void cSeek(){

        int index1 = typCb3.getSelectedIndex();
        int index2 = colCb3.getSelectedIndex();
        int index3 = funCb3.getSelectedIndex();
        int index4 = parCb3.getSelectedIndex();
        String typ = typCb3.getItemAt(index1);   //获得种类
        String col = colCb3.getItemAt(index2);   //获得功能
        String fun = funCb3.getItemAt(index3);   //获得功能
        String par = parCb3.getItemAt(index4);   //获得零件





        String[] sql ={"","","","","",""};
        sql[0] = " AND ptype = ? ";
        sql[1] = " AND pn.color = ?";
        sql[2] = " AND pfunction = ?";
        sql[3] = " AND parts =? ";


        try{

            Connection pconn = connect();

            String csql = "SELECT p.ptype,p.pfunction,p.parts, pn.color" +
                    " FROM Product p,productNo pn" +
                    " WHERE p.pianoNo = pn.Product_pianoNo ";

            //添加筛选条件
            int[] pos ={0,0,0,0,0,0,0,0,0,0,0,0,0};
            int pos2 =0;  //计算被选中的信息要插入的sql的位置
            if( typ != null && typ.trim().length() != 0  && (!typ.equals("All"))){
                csql = csql + sql[0];
                pos2 ++ ;
                pos[0]=pos2;   //pos[2]=5
            }
            if( col != null && col.trim().length() != 0 && (!col.equals("All"))){
                csql = csql + sql[1];    //最低价、最高价必须都有有效输入
                pos2 ++ ;
                pos[1]=pos2;
            }
            if(  fun!= null && fun.trim().length() != 0 && (!fun.equals("All"))){
                csql = csql + sql[2];     //产品颜色
                pos2++;
                pos[2]=pos2;
            }
            if( par != null && par.trim().length() != 0 && (!par.equals("All"))){     //产品功能
                csql = csql + sql[3];
                pos2++;
                pos[3]= pos2;
            }

            csql = csql + "GROUP BY p.ptype,p.pfunction,p.parts, pn.color";
            PreparedStatement state = pconn.prepareStatement(csql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            for ( int j=0;j<4;j++){
                if (pos[j]!=0){
                    if(j==0){
                        state.setString(pos[j],typ);
                    }
                    if(j==1){
                        state.setString(pos[j],col);
                    }
                    if(j==2){
                        state.setString(pos[j],fun);
                    }
                    if(j==3){
                        state.setString(pos[j],par);
                    }

                }else{

                }
            }
            ResultSet prs = state.executeQuery();
            if (  prs.isBeforeFirst() ){  //有结果
                cTable.setModel(csetTable(prs,pconn));
            }

        } catch (SQLException e2) {
            e2.printStackTrace();
        }

    }
    class cButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {


            if (cadd.isSelected()) {
                ca = new JFrame("Add");

                cayes = new JButton("Yes");
                cacan = new JButton("Cancel");
                cayes.addActionListener(new cAButtonListener());
                cacan.addActionListener(new cAButtonListener());
                JPanel cyes = new JPanel();
                JPanel ccan = new JPanel();
                JPanel bio = new JPanel();
                cyes.add(cayes);
                ccan.add(cacan);
                bio.setLayout(new GridLayout(1, 2));
                bio.add(cyes);
                bio.add(ccan);


                JPanel content = new JPanel();
                content.setLayout(new BorderLayout(5, 10));
                content.add(cAddGUI(), BorderLayout.CENTER);
                content.add(bio, BorderLayout.SOUTH);

                JLabel space0 = new JLabel("                    ");
                JLabel space1 = new JLabel("                    ");
                ca.setLayout(new BorderLayout(5, 10));
                ca.add(space0, BorderLayout.WEST);
                ca.add(content, BorderLayout.CENTER);
                ca.add(space1, BorderLayout.EAST);

                ca.setSize(650, 350);
                ca.setLocation(300, 200);
                ca.setVisible(true);

            } else if (cmod.isSelected()) {

                cm = new JFrame("Modify");

                cmyes = new JButton("Yes");                          //确定取消按钮
                cmcan = new JButton("Canacel");
                cmyes.addActionListener(new cMButtonListener());
                cmcan.addActionListener(new cMButtonListener());
                JPanel yp = new JPanel();
                JPanel cp = new JPanel();
                JPanel biop = new JPanel();
                yp.add(cmyes);
                cp.add(cmcan);
                biop.setLayout(new GridLayout(1, 2));
                biop.add(yp);
                biop.add(cp);

                JPanel content = new JPanel();
                content.setLayout(new BorderLayout(5, 10));
                content.add(cModifyGUI(), BorderLayout.CENTER);
                content.add(biop, BorderLayout.SOUTH);
                //cnoText2.setEnabled(false);
                //cnaText2.setEnabled(false);


                JLabel space0 = new JLabel("                    ");
                JLabel space1 = new JLabel("                    ");
                cm.setLayout(new BorderLayout(5, 10));
                cm.add(space0, BorderLayout.WEST);
                cm.add(content, BorderLayout.CENTER);
                cm.add(space1, BorderLayout.EAST);


                cm.setSize(650, 350);
                cm.setLocation(300, 200);
                cm.setVisible(true);


            } else if (csee.isSelected()) {
                cs = new JFrame("Seek");

                csyes = new JButton("Yes");
                cscan = new JButton("Cancel");
                csyes.addActionListener(new cSButtonListener());
                cscan.addActionListener(new cSButtonListener());
                JPanel pyes = new JPanel();
                JPanel pcan = new JPanel();
                JPanel bio = new JPanel();
                pyes.add(csyes);
                pcan.add(cscan);
                bio.setLayout(new GridLayout(1,2));
                bio.add(pyes);
                bio.add(pcan);


                JPanel content = new JPanel();
                content.setLayout(new BorderLayout(5,10));
                content.add(cSeekGUI(),BorderLayout.CENTER);
                content.add(bio,BorderLayout.SOUTH);

                JLabel space0 = new JLabel("                    ");
                JLabel space1 = new JLabel("                    ");
                cs.setLayout(new BorderLayout(5,10));
                cs.add(space0,BorderLayout.WEST);
                cs.add(content,BorderLayout.CENTER);
                cs.add(space1,BorderLayout.EAST);


                cs.setSize(650,350);
                cs.setLocation(300,200);
                cs.setVisible(true);

            } else if (call.isSelected()) {
                try{    //将数据库信息放到JTable中
                    Connection pmdconn = connect();
                    String csql = "SELECT p.ptype,p.pfunction,p.parts, pn.color" +
                            " FROM Product p,productNo pn" +
                            " WHERE p.pianoNo = pn.Product_pianoNo GROUP BY p.ptype,p.pfunction,p.parts, pn.color";
                    PreparedStatement pmdstmt = pmdconn.prepareStatement(csql,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
                    ResultSet pmdres = pmdstmt.executeQuery();

                    cTable.setModel(csetTable(pmdres,pmdconn));

                } catch (SQLException e2) {
                    e2.printStackTrace();
                }

            }
        }

    }
    class cAButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent c){
            if( c.getSource() == cayes ){
                cAdd();
                ca.dispose();
            }else{
                ca.dispose();
            }

        }
    }
    class cMButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent c){
            if( c.getSource() == cmyes ){
                cModify();
                cm.dispose();
            }else{
                cm.dispose();
            }
        }
    }
    class cSButtonListener implements ActionListener {     //订单管理   修改服务的确认取消响应
        public void actionPerformed(ActionEvent c){
            if( c.getSource() == csyes ){
                cSeek();
                cs.dispose();
            }else{
                cs.dispose();
            }

        }
    }

    /**
     * 连接数据库
     * @return
     */
    public Connection connect(){
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException classNotFoundException) {
            System.out.println("Failed to load driver package.");
        }
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/e_piano_2", "root", "Extraord10");
            return conn;
        } catch (SQLException throwables) {
            System.out.println("Failed to connect to database.");
        }
        return conn;
    }
    /**
     * 判断是否含有字母
     * @param str  待检验的字符串
     * @return   返回是否包含
     * true  包含字母
     */
    public boolean judgeContainsStr(String str) {
        String regex=".*[a-zA-Z]+.*";
        Matcher m= Pattern.compile(regex).matcher(str);
        return m.matches();
    }
    /**
     * 判断商品中是否包含这个编号
     * @param str  从对话框中获取的编号字符串
     * @return   返回是否存在
     * true 存在
     */
    public boolean checkPExist(String str){
        boolean flag = false;
        try{
            int pInt = Integer.parseInt(str);
            Connection check = connect();
            String csql = "SELECT * FROM Product WHERE pianoNo = ?";
            PreparedStatement cstate = check.prepareStatement(csql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            cstate.setInt(1,pInt);
            ResultSet crs = cstate.executeQuery();
            if ( ! crs.isBeforeFirst()){
                flag= false;
            }else{
                flag =  true;
            }
        }catch (SQLException c1) {
            c1.printStackTrace();
        }
        return flag;
    }

    /**从数据库获取并初始化
     * type,color,function,parts的数值
     */
    public void Initialize(){
        try{
            typList = new ArrayList<String>();
            colList = new ArrayList<String>();
            funList = new ArrayList<String>();
            parList = new ArrayList<String>();
            typList2 = new ArrayList<String>();
            colList2 = new ArrayList<String>();
            funList2 = new ArrayList<String>();
            parList2 = new ArrayList<String>();
            typList2.add("All");
            colList2.add("All");
            funList2.add("All");
            parList2.add("All");
            //获得数据库中的type
            Connection conn = connect();
            String csql2 = "SELECT color From productNo GROUP BY color";
            PreparedStatement stmt2 = conn.prepareStatement(csql2,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs2 = stmt2.executeQuery();
            String[] typ1 = getTypENUM(1);
            String[] fun1 = getFunENUM(1);
            String[] par1 = getParENUM(1);
            for ( int i=0;i<typ1.length;i++){
                typList.add(typ1[i]);
                typList2.add(typ1[i]);
            }
            for ( int i=0;i<fun1.length;i++){
                funList.add(fun1[i]);
                funList2.add(fun1[i]);
            }
            for ( int i=0;i<par1.length;i++){
                parList.add(par1[i]);
                parList2.add(par1[i]);
            }

            //将结果放到ArrayList中
            //color
            int count2 = 0;
            while (rs2.next()) {
                count2++;
            }
            String comm2[][] = new String[count2][1];
            count2 = 0;
            rs2.beforeFirst();
            while (rs2.next()) {
                comm2[count2][0] = rs2.getString("color");
                colList.add(comm2[count2][0]);
                colList2.add(comm2[count2][0]);
                count2++;
            }


            conn.close();

            update();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void update(){
        typValue = (String[])typList.toArray(new String[typList.size()]) ;
        colValue = (String[])colList.toArray(new String[colList.size()]) ;
        funValue = (String[])funList.toArray(new String[funList.size()]) ;
        parValue = (String[])parList.toArray(new String[parList.size()]) ;
        typValue2 = (String[])typList2.toArray(new String[typList2.size()]) ;
        colValue2 = (String[])colList2.toArray(new String[colList2.size()]) ;
        funValue2 = (String[])funList2.toArray(new String[funList2.size()]) ;
        parValue2 = (String[])parList2.toArray(new String[parList2.size()]) ;

    }

    public String[] getTypENUM( int  num){
        ArrayList<String> typlt = new ArrayList<String>();
        ArrayList<String> typlt2 = new ArrayList<String>();
        typlt2.add("All");
        String[] tValue = null ;
        String[] tValue2 = null;
        String tENUM = " ";
        try{
            Connection conn = connect();
            String s = "SELECT column_type" +
                    " FROM  information_schema. COLUMNS  WHERE" +
                    "        TABLE_SCHEMA = 'e_piano_2'" +
                    "        AND DATA_TYPE = 'enum'" +
                    "        AND table_name='product'" +
                    "        AND column_name='ptype'";
            PreparedStatement st1 = conn.prepareStatement(s,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs1 = st1.executeQuery();
            while (rs1.next()) {
                tENUM = rs1.getString("column_type");
            }
            String test = tENUM.replace(',', ' ');
            String test2 = subString(test,"enum(",")");
            String[] splitStr = test2.split("'");
            for ( int i=0;i<splitStr.length;i++){
                if (splitStr[i]!=null && splitStr[i].trim().length()!=0){
                    typlt.add(splitStr[i]);
                    typlt2.add(splitStr[i]);
                }

            }

            tValue = (String[])typlt.toArray(new String[typlt.size()]) ;
            tValue2 = (String[])typlt2.toArray(new String[typlt2.size()]) ;

            if ( num ==1){
                return tValue;
            }else{
                return tValue2;
            }


        }catch (SQLException e) {
            e.printStackTrace();
        }
        return tValue;

    }
    public String[] getFunENUM( int  num){
        ArrayList<String> funlt = new ArrayList<String>();
        ArrayList<String> funlt2 = new ArrayList<String>();
        funlt2.add("All");
        String[] fValue = null ;
        String[] fValue2 = null;
        String fENUM = " ";
        try{
            Connection conn = connect();
            String s = "SELECT column_type" +
                    " FROM  information_schema. COLUMNS  WHERE" +
                    "        TABLE_SCHEMA = 'e_piano_2'" +
                    "        AND DATA_TYPE = 'enum'" +
                    "        AND table_name='product'" +
                    "        AND column_name='pfunction'";
            PreparedStatement st1 = conn.prepareStatement(s,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs1 = st1.executeQuery();
            while (rs1.next()) {
                fENUM = rs1.getString("column_type");
            }
            String test = fENUM.replace(',', ' ');
            String test2 = subString(test,"enum(",")");
            String[] splitStr = test2.split("'");
            for ( int i=0;i<splitStr.length;i++){
                if (splitStr[i]!=null && splitStr[i].trim().length()!=0){
                    funlt.add(splitStr[i]);
                    funlt2.add(splitStr[i]);
                }

            }

            fValue = (String[])funlt.toArray(new String[funlt.size()]) ;
            fValue2 = (String[])funlt2.toArray(new String[funlt2.size()]) ;

            if ( num ==1){
                return fValue;
            }else{
                return fValue2;
            }


        }catch (SQLException e) {
            e.printStackTrace();
        }
        return fValue;

    }
    public String[] getParENUM( int  num){
        ArrayList<String> parlt = new ArrayList<String>();
        ArrayList<String> parlt2 = new ArrayList<String>();
        parlt2.add("All");
        String[] pValue = null ;
        String[] pValue2 = null;
        String pENUM = " ";
        try{
            Connection conn = connect();
            String s = "SELECT column_type" +
                    " FROM  information_schema. COLUMNS  WHERE" +
                    "        TABLE_SCHEMA = 'e_piano_2'" +
                    "        AND DATA_TYPE = 'enum'" +
                    "        AND table_name='product'" +
                    "        AND column_name='parts'";
            PreparedStatement st1 = conn.prepareStatement(s,ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_READ_ONLY);
            ResultSet rs1 = st1.executeQuery();
            while (rs1.next()) {
                pENUM = rs1.getString("column_type");
            }
            String test = pENUM.replace(',', ' ');
            String test2 = subString(test,"enum(",")");
            String[] splitStr = test2.split("'");
            for ( int i=0;i<splitStr.length;i++){
                if (splitStr[i]!=null && splitStr[i].trim().length()!=0){
                    parlt.add(splitStr[i]);
                    parlt2.add(splitStr[i]);
                }

            }

            pValue = (String[])parlt.toArray(new String[parlt.size()]) ;
            pValue2 = (String[])parlt2.toArray(new String[parlt2.size()]) ;

            if ( num ==1){
                return pValue;
            }else{
                return pValue2;
            }


        }catch (SQLException e) {
            e.printStackTrace();
        }
        return pValue;

    }
    public  String subString(String str, String strStart, String strEnd) {

        int strStartIndex = str.indexOf(strStart);
        int strEndIndex = str.indexOf(strEnd);

        String result = str.substring(strStartIndex, strEndIndex).substring(strStart.length());
        return result;
    }

}
